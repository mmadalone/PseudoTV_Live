#   Copyright (C) 2025 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.
#
# -*- coding: utf-8 -*-

from globals    import *
from library    import Library
from builder    import Builder
from channels   import Channels
from xmltvs     import XMLTVS
from backup     import Backup
from multiroom  import Multiroom
from wizard     import Wizard
from server     import HTTP, Discovery

from context_create import _auto

class Tasks(object):
    citems  = []
    cache   = SETTINGS.cache
    cacheDB = SETTINGS.cacheDB
    
    def __init__(self, service):
        self.service = service       
        self.jsonRPC = service.jsonRPC
        self.player  = service.player
        self.monitor = service.monitor


    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)


    def _client(self):
        self.service._que(self.monitor.chkIdle,1)
        self.service._que(self.chkHTTP        ,1)
        self.service._que(self.chkInstanceID  ,1)
        self.service._que(self.chkPVRBackend  ,1)
        self.service._que(self.chkDebugging   ,1)
        self.log('_initialize, _client...')
        
        
    def _host(self):
        self._client()
        self.service._que(self.chkDirs,1)
        self.service._que(self.chkBackup,1)
        self.service._que(self.chkCrash,1)
        self.log('_initialize, _host...')
    
    
    def chkHTTP(self):
        timerit(HTTP)(0.1,self.service)
        self.log('chkHTTP')
        
        
    def chkInstanceID(self):
        self.log('chkInstanceID')
        PROPERTIES.getInstanceID()
        

    def chkWizard(self):
        self.log('chkWizard')
        if not SETTINGS.hasWizardRun():
            BUILTIN.executescript('special://home/addons/%s/resources/lib/utilities.py, Run_Wizard'%(ADDON_ID))
            

    def chkDebugging(self):
        self.log('chkDebugging')
        if SETTINGS.getSettingBool('Debug_Enable'):
            if DIALOG.yesnoDialog(LANGUAGE(32142),autoclose=4):
                self.log('_chkDebugging, disabling debugging.')
                SETTINGS.setSettingBool('Debug_Enable',False)
                DIALOG.notificationDialog(LANGUAGE(32025))
        #Force enable Kodi Debugging when enabled in PseudoTV via JSONRPC only if Kodi access allowed by user.
        if SETTINGS.getSettingBool('Enable_Kodi_Access'):
            self.jsonRPC.toggleShowLog(SETTINGS.getSettingBool('Debug_Enable'))
                    
             
    def chkDiscovery(self):
        timerit(Discovery)(0.1,*(self.service, Multiroom(service=self.service)))
        self.log('chkDiscovery')
         
         
    def chkBackup(self):
        self.log('chkBackup')
        Backup().hasBackup()


    def chkCrash(self):
        citem = (SETTINGS.getCacheSetting('KODI.CRASH.JSONRPC.CITEM') or {})
        SETTINGS.setCacheSetting('KODI.CRASH.JSONRPC.CITEM',None)
        if citem:
            self.log('chkCrash\n%s'%(citem))
            # with BUILTIN.busy_dialog(), PROPERTIES.suspendActivity():
                # channels = Channels(writable=True)
                # chanLST  = channels.getChannels()
                # idx, channel = channels.findChannel(citem, chanLST)
                # chanLST[idx].update({'enabled':False})
                # if channels.setChannels(chanLST):
                    # DIALOG.okDialog(f'Kodi encountered a fatal crash while parsing a [B]{ADDON_NAME}[\B] channel.\nPlease check the channel configuration for [B]{citem.get('name')}[\B]\n Channel [B]{citem.get('number')}[\B] temporarily disabled!', usethread=False)
                # del channels
  
  
    def chkPVRBackend(self): 
        self.log('chkPVRBackend')
        if SETTINGS.hasAddon(PVR_CLIENT_ID,notify=True):
            if not SETTINGS.hasPVRInstance():
                SETTINGS.setPVRRemote(PROPERTIES.getRemoteHost(), PROPERTIES.getFriendlyName(), cache=False)


    def chkQueTimer(self):
        self.log('chkQueTimer')
        self._chkEpochTimer('chkVersion'      , self.chkVersion       , 43200 , 1)#12HRS
        self._chkEpochTimer('chkKodiSettings' , self.chkKodiSettings  , 10800 , 1)#3HRS
        self._chkEpochTimer('chkDiscovery'    , self.chkDiscovery     , 300   , 1)#5MINS
        self._chkEpochTimer('chkQUES'         , self.chkQUES          , 120   , 1)#2MINS
        
        if not self.service.isClient:
            self._chkEpochTimer('chkFiles'    , self.chkFiles         , 600   , 1)#10MINS
            # 'Library_Walk_Interval' (hours, default 12, range 1-72) controls how often
            # the autotune library types are re-walked. Channel-build still fires immediately
            # via _chkPropTimer('chkUpdate') on user actions, so this only paces background work.
            self._chkEpochTimer('chkLibrary'  , self.chkLibrary       , max(1, SETTINGS.getSettingInt('Library_Walk_Interval') or 12) * 3600 , 2)
            
        #immediate run, bypass schedule
        self._chkPropTimer('chkPVRRefresh'    , self.chkPVRRefresh    , 1) 
        self._chkPropTimer('chkChanged'       , self.chkChanged       , 3)
        
        
    #_chkEpochTimer trigger - Time = 0 == Run
    def _chkEpochTimer(self, key, func, runevery=900, priority=-1, nextrun=None, *args, **kwargs):
        if nextrun is None: nextrun = int(PROPERTIES.getEXTProperty(key,'0')) # nextrun == 0 => force que
        epoch = int(time.time())
        if epoch >= nextrun:
            self.log('_chkEpochTimer, key = %s, last run %s' % (key, epoch - nextrun))
            PROPERTIES.setEXTProperty(key, (epoch + runevery))
            self.service._que(func, priority, *args, **kwargs)


     #_chkPropTimer trigger - True == Run
    def _chkPropTimer(self, key, func, priority=-1, *args, **kwargs):
        if PROPERTIES.getPropTimer(key):
            self.log('_chkPropTimer, key = %s'%(key))
            PROPERTIES.clrEXTProperty(key)
            self.service._que(func, priority, *args, **kwargs)
            

    @cacheit(expiration=datetime.timedelta(minutes=15))
    def getOnlineVersion(self):
        try:    ONLINE_VERSION = re.compile('" version="(.+?)" name="%s"'%(ADDON_NAME)).findall(str(Globals.requestURL(ADDON_URL)))[0]
        except Exception: ONLINE_VERSION = ADDON_VERSION
        self.log('getOnlineVersion, version = %s'%(ONLINE_VERSION))
        return ONLINE_VERSION
        
        
    def chkVersion(self):
        update = False
        ONLINE_VERSION = self.getOnlineVersion()
        if ADDON_VERSION < ONLINE_VERSION: 
            update = True
            DIALOG.notificationDialog(LANGUAGE(30073)%(ONLINE_VERSION))
        elif ADDON_VERSION > (SETTINGS.getCacheSetting('lastVersion', checksum=ADDON_VERSION, revive=True) or '0.0.0'):
            SETTINGS.setCacheSetting('lastVersion',ADDON_VERSION, checksum=ADDON_VERSION)
            BUILTIN.executescript('special://home/addons/%s/resources/lib/utilities.py, Show_Changelog'%(ADDON_ID))
        self.log('chkVersion, update = %s, installed version = %s, online version = %s'%(update,ADDON_VERSION,ONLINE_VERSION))
        SETTINGS.setSetting('Update_Status',{'True':'[COLOR=yellow]%s [B]v.%s[/B][/COLOR]'%(LANGUAGE(32168),ONLINE_VERSION),'False':'None'}[str(update)])


    def chkKodiSettings(self):
        self.log('chkKodiSettings')
        # When 'Decouple_Kodi_PVR' is enabled, the user has opted to make pseudotv's
        # Min_Days, Max_Days, and OSD_Timer authoritative. Skip the auto-sync from
        # Kodi's PVR settings (epg.pastdaystodisplay / epg.futuredaystodisplay /
        # pvrmenu.displaychannelinfo) so the user's values aren't overwritten hourly.
        if SETTINGS.getSettingBool('Decouple_Kodi_PVR'):
            self.log('chkKodiSettings, Decouple_Kodi_PVR enabled; skipping Kodi PVR sync')
            return
        MIN_GUIDEDAYS = SETTINGS.setSettingInt('Min_Days' ,self.jsonRPC.getSettingValue('epg.pastdaystodisplay'     ,default=1))
        MAX_GUIDEDAYS = SETTINGS.setSettingInt('Max_Days' ,self.jsonRPC.getSettingValue('epg.futuredaystodisplay'   ,default=3))
        OSD_TIMER     = SETTINGS.setSettingInt('OSD_Timer',self.jsonRPC.getSettingValue('pvrmenu.displaychannelinfo',default=5))
         

    def chkDirs(self):
        [(self.log('chkDirs, creating [%s]'%(folder)),FileAccess.makedirs(folder)) for folder in [LOGO_LOC,FILLER_LOC,TEMP_LOC,TEMP_IMAGE_LOC] if not FileAccess.exists(os.path.join(folder,''))]


    def chkFiles(self):
        for file in [CHANNELFLEPATH,M3UFLEPATH,XMLTVFLEPATH,GENREFLEPATH]:
            if not FileAccess.exists(file):
                self.log('chkFiles, missing [%s]'%(file))
                return self.service._que(self.chkChannels,3)


    def chkFillers(self, channels=None, silent=None):
        if silent is None: silent = BUILTIN.isPlaying()
        self.log('chkFillers')
        # if channels is None: channels = self.getChannels())))
        # if len(channels) > 0:
            # for fidx, ftype in enumerate(FILLER_TYPES):
                # fpath = os.path.join(FILLER_LOC,ftype.lower(),'')
                # if not FileAccess.exists(fpath): FileAccess.makedirs(fpath)
                
                # for cidx, citem in enumerate(channels):
                    # cpath = os.path.join(fpath, citem.get('name','').lower())
                    # if not FileAccess.exists(cpath): FileAccess.makedirs(cpath)
                    
                    # for gidx, genres in channels()
                    
                    # if not FileAccess.exists(os.path.join(FILLER_LOC,ftype.lower(),genre.lower(),'')):
                        # FileAccess.makedirs(os.path.join(FILLER_LOC,ftype.lower(),''))
                
                # for ftype in FILLER_TYPES[1:]:
                    # for genre in genres:
                        # if not FileAccess.exists(os.path.join(FILLER_LOC,ftype.lower(),genre.lower(),'')):
                            # pDialog = DIALOG.progressBGDialog(int(idx*50//len(channels)), pDialog, message='%s: %s'%(genre,int(idx*100//len(channels)))+'%', header='%s, %s'%(ADDON_NAME,LANGUAGE(32179)))
                            # FileAccess.makedirs(os.path.join(FILLER_LOC,ftype.lower(),genre.lower()))
                    
                    # if not FileAccess.exists(os.path.join(FILLER_LOC,ftype.lower(),citem.get('name','').lower())):
                        # if ftype.lower() == 'adverts': IGNORE = IGNORE_CHTYPE + MOVIE_CHTYPE
                        # else:                          IGNORE = IGNORE_CHTYPE
                        # if citem.get('name') and not citem.get('radio',False) and citem.get('type') not in IGNORE: 
                            # pDialog = DIALOG.progressBGDialog(int(idx*50//len(channels)), pDialog, message='%s: %s'%(citem.get('name'),int(idx*100//len(channels)))+'%', header='%s, %s'%(ADDON_NAME,LANGUAGE(32179)))
                            # FileAccess.makedirs(os.path.join(FILLER_LOC,ftype.lower(),citem['name'].lower()))
            # pDialog = DIALOG.progressBGDialog(100, pDialog, message=LANGUAGE(32025), header='%s, %s'%(ADDON_NAME,LANGUAGE(32179)))
        

    def chkLibrary(self, types=None, silent=None):
        if silent is None: silent = BUILTIN.isPlaying()
        self.log("chkLibrary, types = %s, silent = %s"%(types,silent))
        complete = set()
        library  = Library(service=self.service, writable=True)
        library.searchRecommended()
        if types is None: types = AUTOTUNE_TYPES
        for idx, type in enumerate(types):
            items = library.getLibrary(type)
            if self.service._interrupt() or self.service._suspend():
                self.log("chkLibrary, _interrupt/_suspend")
                return self.service._que(self.chkLibrary,2,*(types[idx:],silent))
            elif items:
                self.log("chkLibrary, %s library found! Setting items (%s), queuing update."%(type,len(items)))
                complete.add(library.setLibrary(type, items))
                self.service._que(library.updateLibrary,-1,*([type],True))
            else:
                self.log("chkLibrary, %s library not found! starting update."%(type))
                complete.add(library.updateLibrary([type],silent))
        del library
        if any(list(complete)): self.service._que(self.chkChannels,3)
        self.log("chkLibrary, complete = %s"%(any(list(complete))))
        

    def chkChanged(self, channels=None, silent=None):
        if silent is None: silent = BUILTIN.isPlaying()
        if channels is None: channels = self.getChannels()
        changes = [channel for channel in channels if channel.get('changed',False)]
        self.log('chkChanged, changes = %s'%(len(changes)))
        for channel in changes:
            self.service._que(Builder(service=self.service).buildChannels,3,*([channel],False,silent))
        
        
    def _filterChannelsNeedingBuild(self, channels):
        # madteevee: read-only pre-filter for chkChannels. Returns subset of
        # channels whose cached EPG warrants a build. Mirrors the gating
        # logic of Builder.buildChannels' __needsUpdate / __hasChanged
        # closures, with two deliberate omissions:
        #   - SETTINGS.getFileCRC() is NOT called here. It has side effects
        #     (updates the cached CRC via setCacheSetting at kodi.py:559),
        #     so calling it from a read-only filter would mask real changes
        #     from the subsequent buildChannels run.
        #   - When Enable_Changed is on, channels are conservatively included
        #     (no CRC detection here; defer to buildChannels' __hasChanged).
        if not channels: return []
        now       = getUTCstamp()
        nstart    = roundTimeDown(now, offset=60)
        fallback  = epochTime(nstart, tz=False).strftime(DTFORMAT)
        threshold = now + ((MAX_GUIDEDAYS * 86400) - 43200)
        detect    = SETTINGS.getSettingBool('Enable_Changed')

        xmltv  = XMLTVS()
        stops  = dict(xmltv.loadStopTimes(channels, fallback=fallback))
        needed = []
        for citem in channels:
            if citem.get('changed', False):
                needed.append(citem); continue
            if stops.get(citem['id'], 0) <= threshold:
                needed.append(citem); continue
            if detect:
                needed.append(citem); continue
        self.log('_filterChannelsNeedingBuild, total = %s, needed = %s'%(len(channels), len(needed)))
        return needed


    def chkChannels(self, channels=None, silent=None):
        if silent is None: silent = BUILTIN.isPlaying()
        if channels is None: channels = self.getChannels()
        if len(channels) > 0:
            self.log('chkChannels, channels = %s'%(len(channels)))
            # madteevee: hoist the freshness check from Builder.buildChannels'
            # inner __needsUpdate so we don't even queue a job for fresh
            # channels. The per-channel guard still runs inside buildChannels
            # for any channel that passes the filter.
            needed = self._filterChannelsNeedingBuild(channels)
            if not needed:
                self.log('chkChannels, all %s channels fresh - skipping buildChannels'%(len(channels)))
                return
            if not PROPERTIES.hasChannels():
                self.service._que(Builder(service=self.service).buildChannels,3,*(needed,False,silent))
            else:
                [self.service._que(Builder(service=self.service).buildChannels,3,*([channel],False,silent)) for channel in needed]
            if SETTINGS.getSettingBool('Build_Filler_Folders'): self._que(self.chkFillers,4,*(needed,silent))
        else:
            self.log('chkChannels, No Channels Configured!')
            if not SETTINGS.hasAutotuned():
                if SETTINGS.setAutotuned(_auto()):
                    if self.service._sleep(5):
                        self.service._que(self.chkChannels,3)
            elif PROPERTIES.hasEnabledServers():
                PROPERTIES.setPropTimer('chkPVRRefresh')#refresh pvr guide


    @debounceit(M3U_REFRESH)
    def chkPVRRefresh(self, brute=SETTINGS.getSettingBool('Enable_PVR_RELOAD')):
        self.log('chkPVRRefresh')
        def __toggle(state=True):
            with BUILTIN.busy_dialog(lock=True):
                self.log('chkPVRRefresh, __toggle = %s'%(state))
                self.service.jsonRPC.sendJSON({"method":"Addons.SetAddonEnabled","params":{"addonid":PVR_CLIENT_ID,"enabled":state}})
            
        if not PROPERTIES.isRunning('Tasks.chkPVRRefresh') and self.service.monitor.isIdle and not PROPERTIES.isRunning('Builder.buildChannels'):
            with PROPERTIES.chkRunning('Tasks.chkPVRRefresh'):
                timerit(PROPERTIES.setEXTProperty)(M3U_REFRESH,*('%s.HTTP.pendingRestart'%(ADDON_ID),True))
                if brute:
                    if not self.service.player.isPlaying() and BUILTIN.getInfoBool('AddonIsEnabled(%s)'%(PVR_CLIENT_ID),'System'):
                        DIALOG.notificationWait('%s: %s'%(PVR_CLIENT_NAME,LANGUAGE(32125)),wait=M3U_REFRESH, usethread=True)
                        BUILTIN.executewindow('ActivateWindow(home)')
                        __toggle(False), timerit(__toggle)(M3U_REFRESH)
                    else:  timerit(PROPERTIES.setPropTimer('chkPVRRefresh'))(M3U_REFRESH)#refresh pvr guide
                self.jsonRPC.PVRScan(self.jsonRPC.getPVRClient(PVR_CLIENT_ID).get('clientid',-1)) #currently not supported by IPTV Simple.
            
            
    def chkSettingsChange(self, settings={}):
        nSettings = SETTINGS.getCurrentSettings()
        for setting, value in list(settings.items()):
            actions = {'User_Folder'  :{'func':self.setUserPath            ,'kwargs':{'old':value,'new':nSettings.get(setting)}},
                       'Debug_Enable' :{'func':self.jsonRPC.toggleShowLog  ,'kwargs':{'state':SETTINGS.getSettingBool('Debug_Enable')}},
                       'TCP_PORT'     :{'func':SETTINGS.setPVRRemote       ,'kwargs':{'host':PROPERTIES.getRemoteHost(),'instance':PROPERTIES.getFriendlyName()}},}
                       
            if nSettings.get(setting) != value and actions.get(setting):
                action = actions.get(setting)
                self.log('chkSettingsChange, detected change in %s: %s => %s\naction = %s'%(setting,value,nSettings.get(setting),action))
                self.service._que(action.get('func'),1,*action.get('args',()),**action.get('kwargs',{}))
        return nSettings


    def chkQUES(self):
        library = Library()
        for i in list(range(QUEUE_CHUNK)):
            if self.service._interrupt() or self.service._suspend():
                self.log("chkQUES, _interrupt/_suspend")
                self.service._que(self.chkQUES,-1)
                break
            else:
                if len(self.service.postQue) > 0:
                    param = self.service.postQue.pop()
                    self.log("chkQUES, queuing = %s\npostQue: %s"%(len(self.service.postQue),param))
                    self.service._que(requestURL,1,*param)
                if len(self.service.jsonQue) > 0:
                    param = self.service.jsonQue.pop()
                    self.log("chkQUES, queuing = %s\njsonQue:%s"%(len(self.service.jsonQue),param))
                    self.service._que(self.jsonRPC.sendJSON,-1,param)
                if len(self.service.logoQue) > 0:
                    chname = FileAccess.loadJSON(self.service.logoQue.pop())
                    self.log("chkQUES, queuing = %s\nlogoQue:%s"%(len(self.service.logoQue),chname))
                    # `chname` is the dict loaded from logoQue (queueLogo stores {'name': ...}).
                    # Nightly upstream referenced `param.get('name')` here, but `param` is only
                    # assigned in the postQue / jsonQue branches above — when the only non-empty
                    # queue is logoQue, that's an UnboundLocalError that aborts chkQUES and stops
                    # logo cache priming, which in turn fails getLogo lookups during channel tune
                    # and the playback chain crashes downstream.
                    self.service._que(library.resources.getLogo,-1,*(chname,library.resources.getCache(chname.get('name')),True))
        del library
        
                
    def setUserPath(self, old, new):
        self.log('setUserPath, old = %s, new = %s'%(old,new))
        dia = DIALOG.progressDialog(message='%s\n%s'%(LANGUAGE(32050),old))
        with PROPERTIES.interruptActivity():
            FileAccess.copyFolder(old, new, dia)
        PROPERTIES.setPendingRestart()
        DIALOG.progressDialog(100, dia)


    def getChannels(self):
        return Channels().getChannels()