#   Copyright (C) 2025 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-

from globals    import *
from multiroom  import Multiroom

#todo create dataclasses for all jsons
# https://pypi.org/project/dataclasses-json/
class Channels(object):
    
    def __init__(self, file=None, writable=False):
        if file is None: file = self._getCHANNELFLE()
        self.writable    = writable
        self.channelFile = file
        self.channelDATA = FileAccess.getJSON(CHANNELFLE_DEFAULT)
        self.channelTEMP = self.channelDATA.get('channels',[{}]).pop(0)
        self.channelRULE = self.channelTEMP.pop('rules')
        self.channelTEMP['rules'] = {}
        self.channelDATA.update(self._load())
        # Refresh Open_Manager count NOW that self.channelDATA has the loaded channels.
        # _load() called _setSetting() before this update — at that point self.channelDATA
        # was still the post-pop empty template, so the setting always wrote "0 Channels"
        # regardless of how many channels the file actually held.
        self._setSetting()
        self.channelDATA_OLD = self.channelDATA.copy()
        
        
    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)


    def _getCHANNELFLE(self):
        if SETTINGS.getSettingBool('Enable_Autotuned_Channels'): return AUTOTUNEFLEPATH
        return CHANNELFLEPATH
        
        
    def _load(self) -> dict:
        channelDATA = FileAccess.getJSON(self.channelFile)
        self.log('_load, file = %s\nchannels = %s'%(self.channelFile,len(channelDATA.get('channels',[]))))
        return channelDATA
    
        
    def _verify(self, channels: list=[]):
        for idx, citem in enumerate(self.channelDATA.get('channels',[])):
            if not citem.get('name') or not citem.get('id') or len(citem.get('path',[])) == 0:
                self.log('_verify, in-valid citem [%s]\n%s'%(citem.get('id'),citem))
                continue
            yield citem
                
                
    def _save(self) -> bool:
        self.log('_save, writable = %s, file = %s\nchannels = %s'%(self.writable,self.channelFile,len(self.channelDATA['channels'])))
        if self.writable:
            with PROPERTIES.interruptActivity():
                if FileAccess.setJSON(self.channelFile,self.channelDATA):
                    self._setSetting()
                    return True
        
        
    def _setSetting(self):
        if self.channelFile == CHANNELFLEPATH:
            SETTINGS.setSetting('Open_Manager','[B]%s[/B] Channels'%(len(self.channelDATA['channels'])))
        
        
    def getTemplate(self) -> dict: 
        return self.channelTEMP.copy()
        
        
    def getChannels(self) -> list:
        return sorted(self.channelDATA['channels'], key=itemgetter('number'))
        
        
    def getChannelbyID(self, id: str) -> list:
        return list([c for c in self.channelDATA['channels'] if c.get('id') == id])
        
        
    def getChannelbyType(self, type: str):
        return list([citem for citem in self.channelDATA['channels'] if citem.get('type') == type])


    def sortChannels(self, channels: list) -> list:
        try:              return sorted(channels, key=itemgetter('number'))
        except Exception: return channels

    
    def setChannels(self, channels=None, modified_ids=None) -> bool:
        if channels is None: channels = self.channelDATA['channels']
        if modified_ids is not None and self.writable:
            # v.43 merge-on-write: Builder.channels is a class-level shared instance loaded
            # once at class-definition time. addChannel() refreshes only the channels the
            # current build batch touched; all other channels carry stale init-time state.
            # A bare _save() would clobber any disk edits to those untouched channels
            # (notably operator-flipped `changed:true` used to force a rebuild). Re-read
            # disk and preserve untouched channels here.
            try:
                disk_channels = {c.get('id'): c for c in (self._load().get('channels',[]) or [])}
                in_memory_ids = {c.get('id') for c in channels}
                merged = []
                for c in channels:
                    cid = c.get('id')
                    if cid in modified_ids or cid not in disk_channels:
                        merged.append(c)              # in-memory authoritative (touched, or new)
                    else:
                        merged.append(disk_channels[cid])  # disk authoritative (untouched)
                for cid, c in disk_channels.items():
                    if cid not in in_memory_ids:
                        merged.append(c)              # disk-only (preserve; Builder doesn't delete)
                channels = merged
            except Exception as e:
                self.log('setChannels, modified_ids merge failed, falling back to direct write: %s'%(e), xbmc.LOGWARNING)
        self.channelDATA['uuid']     = SETTINGS.getMYUUID()
        self.channelDATA['channels'] = self.sortChannels(channels)
        PROPERTIES.setHasChannels(len(channels)>0)
        return self._save()
        

    def getImports(self) -> list:
        return self.channelDATA.get('imports',[])
        
        
    def setImports(self, data: list=[]) -> bool:
        self.channelDATA['imports'] = data
        return self._save()
         
         
    def clrChannels(self):
        self.channelDATA['channels'] = []
        

    def delChannel(self, citem: dict={}) -> bool:
        if isinstance(citem,list): return any([self.delChannel(channel) for channel in citem])
        try: 
            self.channelDATA['channels'].pop(self.findChannel(citem)[0])
            self.log('[%s] delChannel, channel deleted!'%(citem['id']), xbmc.LOGINFO)
            return True
        except Exception: pass
    
    
    def addChannel(self, citem: dict={}) -> bool:
        if isinstance(citem,list): return any([self.addChannel(channel) for channel in citem])
        self.delChannel(citem)
        self.log('addChannel, [%s] adding channel %s'%(citem["id"],citem["name"]), xbmc.LOGINFO)
        self.channelDATA.setdefault('channels',[]).append(Globals._cleanGroups(citem))
        return True
        
        
    def findChannel(self, citem: dict={}, channels=None) -> tuple:
        if channels is None: channels = self.channelDATA['channels']
        if citem.get('id') is None: citem['id'] = getChannelID(citem.get('name'), citem.get('path'), citem.get('number'), uuid=self.channelDATA.get('uuid'))
        return tuple(next(((idx, eitem) for idx, eitem in enumerate(channels) if citem['id'] == eitem.get('id', str(random.random()))), (None,{})))
                    
                    
    def _channelManager(self):
        with FileAccess.stream(MANAGERPATH, "r") as fle:
            html_content = fle.read()
        html_content = html_content.replace("{{ channel_limit }}", str(CHANNEL_LIMIT))
        html_content = html_content.replace("{{ media_loc }}"    , MEDIA_LOC)
        html_content = html_content.replace("{{ remote_host }}"  , PROPERTIES.getRemoteHost())
        return html_content.encode(encoding=DEFAULT_ENCODING)
        