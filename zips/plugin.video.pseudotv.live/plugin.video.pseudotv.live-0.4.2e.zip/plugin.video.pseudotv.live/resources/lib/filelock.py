#   Copyright (C) 2022 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.
#
# -*- coding: utf-8 -*-
import os, time, errno

from constants   import *
from kodi_six    import xbmc, xbmcaddon
from fileaccess  import FileAccess

class FileLockExceptiosn(Exception):
    pass
 
class FileLock(object):
    # https://github.com/dmfrey/FileLock
    """ A file locking mechanism that has context-manager support so 
        you can use it in a with statement. This should be relatively cross
        compatible as it doesn't rely on msvcrt or fcntl for the locking.
    """
 
    def __init__(self, file_name=ADDON_NAME, timeout=10, delay=.05):
        """ Prepare the file locker. Specify the file to lock and optionally
            the maximum timeout and the delay between each attempt to lock.
        """
        if timeout is not None and delay is None:
            raise ValueError("If timeout is not None, then delay must not be None.")
        self.is_locked = False
        self.file_name = 'pseudotv'
        self.lockpath  = self.checkpath()
        self.lockfile  = os.path.join(self.lockpath, "%s.lock" % self.file_name)
        self.timeout   = timeout
        self.delay     = delay
 
 
    def checkpath(self):
        lockpath = os.path.join(REAL_SETTINGS.getSetting('User_Folder'))
        if not FileAccess.exists(lockpath):
            if FileAccess.makedirs(lockpath):
                return lockpath
            else:
                #todo log error with lock path
                lockpath = os.path.join(SETTINGS_LOC,'cache')
                if not FileAccess.exists(lockpath):
                    FileAccess.makedirs(lockpath)
        return lockpath
        
        
    def acquire(self):
        """ Acquire the lock, if possible. If the lock is in use, it check again
            every `wait` seconds. It does this until it either gets the lock or
            exceeds `timeout` number of seconds, in which case it throws 
            an exception.
        """
        start_time = time.time()
        while not xbmc.Monitor().abortRequested():
            try:
                self.fd = FileAccess.open(self.lockfile, 'w')
                self.is_locked = True #moved to ensure tag only when locked
                break;
            except OSError as e:
                if e.errno != errno.EEXIST:
                    raise
                if self.timeout is None:
                    raise FileLockException("Could not acquire lock on {}".format(self.file_name))
                if (time.time() - start_time) >= self.timeout:
                    raise FileLockException("Timeout occured.")
                xbmc.Monitor().waitForAbort(self.delay)
 
 
    def release(self):
        """ Get rid of the lock by deleting the lockfile. 
            When working in a `with` statement, this gets automatically 
            called at the end.
        """
        if self.is_locked:
            self.fd.close()
            self.is_locked = False
 
 
    def __enter__(self):
        """ Activated when used in the with statement. 
            Should automatically acquire a lock to be used in the with block.
        """
        if not self.is_locked:
            self.acquire()
        return self
 
 
    def __exit__(self, type, value, traceback):
        """ Activated at the end of the with statement.
            It automatically releases the lock if it isn't locked.
        """
        if self.is_locked:
            self.release()
 
 
    def __del__(self):
        """ Make sure that the FileLock instance doesn't leave a lockfile
            lying around.
        """
        self.release()
