#   Copyright (C) 2025 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.
#
# -*- coding: utf-8 -*-
from globals    import *
from cqueue     import *
from overlay    import Background, Restart, Overlay, OnNext
from rules      import RulesList
from tasks      import Tasks
from jsonrpc    import JSONRPC

class Player(xbmc.Player):
    pendingItem       = {}
    playingItem       = {}
    background        = None
    restart           = None
    onnext            = None
    overlay           = None
    runActions        = None
    lastSubState      = False
    
    #global rules
    enableOverlay     = SETTINGS.getSettingBool('Overlay_Enable')
    infoOnChange      = SETTINGS.getSettingBool('Enable_OnInfo')
    disableTrakt      = SETTINGS.getSettingBool('Disable_Trakt')
    rollbackPlaycount = SETTINGS.getSettingBool('Rollback_Watched')
    saveDuration      = SETTINGS.getSettingBool('Store_Duration')
    minDuration       = SETTINGS.getSettingInt('Seek_Tolerance')
    maxProgress       = SETTINGS.getSettingInt('Seek_Threshold')
    sleepTime         = SETTINGS.getSettingInt('Idle_Timer')
    runWhilePlaying   = SETTINGS.getSettingBool('Run_While_Playing')
    restartPercentage = SETTINGS.getSettingInt('Restart_Percentage')
    OnNextMode        = SETTINGS.getSettingInt('OnNext_Mode')
    onNextPosition    = SETTINGS.getSetting("OnNext_Position_XY")
    
    """ 
    Player() Trigger Order
    Player: onPlayBackStarted
    Player: onAVChange (if playing)
    Player: onPlayBackEnded (if playing)
    Player: onAVStarted
    Player: onPlayBackSeek (if seek)
    Player: onAVChange (if changed)
    Player: onPlayBackError
    Player: onPlayBackEnded
    Player: onPlayBackStopped
    """
    
    def __init__(self, service=None, monitor=None):
        xbmc.Player.__init__(self)
        self.service   = service
        self.monitor   = monitor
        self.jsonRPC   = service.jsonRPC
        
        
    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)


    def onPlayBackStarted(self):
        self.pendingItem.update({'invoked':time.time(),'pending':True,'playingItem':{}})
        self.log('onPlayBackStarted, pendingItem = %s'%(self.pendingItem))
        

    def onAVChange(self):
        self.log('onAVChange, playingItem = %s'%(self.playingItem))

        
    def onAVStarted(self):
        self.pendingItem.update({'invoked':-1,'pending':False,'playingItem':self.getplayingItem()})
        self.log('onAVStarted, pendingItem = %s'%(self.pendingItem))
        self._onPlay(self.pendingItem.get('playingItem',{}))
        
                
    def onPlayBackSeek(self, seek_time=None, seek_offset=None): #Kodi bug? `OnPlayBackSeek` no longer called by player during seek, issue limited to pvr?
        self.log('onPlayBackSeek, seek_time = %s, seek_offset = %s'%(seek_time,seek_offset))
    
    
    def onPlayBackError(self):
        self.log('onPlayBackError, playingItem = %s'%(self.playingItem))
        self.pendingItem.update({'invoked':-1,'pending':False,'playingItem':{}})
        self._onError(self.playingItem)
        
        
    def onPlayBackEnded(self):
        self.log('onPlayBackEnded, playingItem = %s'%(self.playingItem))
        self.pendingItem.update({'invoked':-1,'pending':False,'playingItem':{}})
        self._onChange(self.playingItem)
        
        
    def onPlayBackStopped(self):
        self.log('onPlayBackStopped, playingItem = %s'%(self.playingItem))
        self.pendingItem.update({'invoked':-1,'pending':False,'playingItem':{}})
        self._onStop(self.playingItem)


    @timeit
    def getplayingItem(self, playingItem={}):
        def __update(id, citem={}): #playingItem from listitem maybe outdated, check with channels.json for fresh citem.
            for item in self.service.channels:
                if item.get('id',random.random()) == id: 
                    return combineDicts(citem,item)
            return citem
            
        playingItem = loadJSON(decodeString(self.getPlayerItem().getProperty('sysInfo')))
        playingItem['isPseudoTV'] = '@%s'%(slugify(ADDON_NAME)) in playingItem.get('chid','')
        playingItem['chfile']     = BUILTIN.getInfoLabel('Filename','Player')
        playingItem['chfolder']   = BUILTIN.getInfoLabel('Folderpath','Player')
        playingItem['chpath']     = BUILTIN.getInfoLabel('Filenameandpath','Player')
        
        if playingItem['isPseudoTV']:
            playingItem.update({'citem':combineDicts(playingItem.get('citem',{}),__update(playingItem.get('citem',{}).get('id'))),'runtime':int(self.getPlayerTime())}) #still needed for adv. rules?
            if not playingItem.get('fitem'):    playingItem.update({'fitem':decodePlot(BUILTIN.getInfoLabel('Plot','VideoPlayer'))})
            if not playingItem.get('nitem'):    playingItem.update({'nitem':decodePlot(BUILTIN.getInfoLabel('NextPlot','VideoPlayer'))})
            PROPERTIES.setEXTProperty('%s.lastPlayed.sysInfo'%(ADDON_ID),encodeString(dumpJSON(playingItem)))
        return playingItem
      
        
    def getPlayerItem(self):
        try: return self.getPlayingItem()
        except:
            self.monitor.waitForAbort(0.1)
            if self.isPlaying(): return self.getPlayerItem()
            else:                return xbmcgui.ListItem()
        
        
    def getPlayerFile(self):
        if self.isPlaying(): return self.getPlayingFile()
        else:                return self.pendingItem.get('playingItem',{}).get('fitem',{}).get('file')


    def getPlayerTime(self):
        if self.isPlaying(): return (self.getTimeLabel('Duration') or self.getTotalTime())
        else:                return (self.pendingItem.get('playingItem',{}).get('fitem',{}).get('runtime') or -1)
            
       
    def getPlayedTime(self):
        if self.isPlaying(): return (self.getTimeLabel('Time') or self.getTime()) #getTime retrieves Guide times not actual media time.
        else:                return -1
       
            
    def getRemainingTime(self):
        if self.isPlaying(): return self.getPlayerTime() - self.getPlayedTime()
        else:                return self.getTimeLabel('TimeRemaining')


    def getPlayerProgress(self):
        if self.isPlaying(): return abs(int((self.getRemainingTime() / self.getPlayerTime()) * 100) - 100)
        else:                return int((BUILTIN.getInfoLabel('Progress','Player') or '-1'))


    def getTimeLabel(self, prop: str='TimeRemaining') -> int and float: #prop='EpgEventElapsedTime'
        if self.isPlaying(): return timeString2Seconds(BUILTIN.getInfoLabel('%s(hh:mm:ss)'%(prop),'Player'))
        else:                return -1


    def isPlayingFiller(self):
        if self.isPlaying(): return isFiller({'genres':BUILTIN.getInfoLabel('Genre(comma)','VideoPlayer').split(',')})
        else:                return True
        
        
    def isNextFiller(self):
        if self.isPlaying(): return isFiller({'genres':BUILTIN.getInfoLabel('NextGenre(comma)','VideoPlayer').split(',')})
        else:                return True


    def isPseudoTV(self):
        if self.isPlaying(): return self.getplayingItem().get('isPseudoTV')
        else:                return (self.pendingItem.get('playingItem',{}).get('isPseudoTV') or self.playingItem.get('isPseudoTV') or False)


    def isPlayingPseudoTV(self):
        return (self.isPlaying() & self.isPseudoTV())


    def setSubtitles(self, state: bool=True):
        hasSubtitle = BUILTIN.hasSubtitle()
        self.log('setSubtitles, show subtitles = %s, hasSubtitle = %s'%(state,hasSubtitle))
        if not hasSubtitle: state = False
        self.showSubtitles(state)


    def _onPlay(self, playingItem={}):
        self.toggleBackground(False)
        self.toggleOverlay(False)
        self.toggleRestart(False)
        self.toggleOnNext(False)
        self.toggleInfo(False)
        self.lastSubState = BUILTIN.isSubtitle()
        if self.isPlayingPseudoTV():
            oldInfo = self.playingItem
            newChan = oldInfo.get('chid',random.random()) != playingItem.get('chid')
            self.log('_onPlay, [%s], mode = %s, isPlaylist = %s, new channel = %s'%(playingItem.get('citem',{}).get('id'), playingItem.get('mode'), playingItem.get('isPlaylist',False), newChan))
            if newChan: #New channel
                self.runActions = RulesList([playingItem.get('citem',{})]).runActions
                self.playingItem = self._runActions(RULES_ACTION_PLAYER_START, playingItem.get('citem',{}), playingItem, inherited=self)
                self.toggleRestart(bool(self.restartPercentage))
                PROPERTIES.setTrakt(self.disableTrakt)
                self.setSubtitles(self.lastSubState) #todo allow rules to set sub preference per channel.
            else: #New Program/Same Channel
                self.playingItem = playingItem
                if playingItem.get('radio',False): 
                    BUILTIN.executebuiltin('Action(back)')
                    BUILTIN.executewindow('ReplaceWindow(visualisation)')
                elif playingItem.get('isPlaylist',False): 
                    BUILTIN.executewindow('ReplaceWindow(fullscreenvideo)')
                self.toggleInfo(self.infoOnChange)
            self.jsonRPC.quePlaycount(oldInfo.get('fitem',{}),self.rollbackPlaycount)
            self.jsonRPC._setRuntime(playingItem.get('fitem',{}),playingItem.get('runtime'),self.saveDuration)

            
    def _onChange(self, playingItem={}):
        self.toggleOverlay(False)
        self.toggleRestart(False)
        self.toggleOnNext(False)
        self.toggleInfo(False)
        if playingItem:
            if not playingItem.get('isPlaylist',False):
                self.toggleBackground(self.enableOverlay)
                threadit(BUILTIN.executebuiltin)('PlayMedia(%s)'%(playingItem.get('callback')))
                self.log('_onChange, [%s], isPlaylist = %s, callback = %s'%(playingItem.get('citem',{}).get('id'),playingItem.get('isPlaylist',False),playingItem.get('callback')))
            self._runActions(RULES_ACTION_PLAYER_CHANGE, playingItem.get('citem',{}), playingItem, inherited=self)
        else:
            self.toggleBackground(False)
        
        
    def _onStop(self, playingItem={}):
        self.log('_onStop, id = %s'%(playingItem.get('citem',{}).get('id')))
        self.toggleInfo(False)
        self.toggleOnNext(False)
        self.toggleRestart(False)
        self.toggleOverlay(False)
        self.toggleBackground(False)
        if playingItem:
            PROPERTIES.setTrakt(False)
            self.jsonRPC.quePlaycount(playingItem.get('fitem',{}),self.rollbackPlaycount)
            if playingItem.get('isPlaylist',False): xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
            self._runActions(RULES_ACTION_PLAYER_STOP, playingItem.get('citem',{}), playingItem, inherited=self)
        

    def _onError(self, playingItem={}): #todo evaluate potential for error handling.
        self.log('_onError, playing file = %s'%(self.getPlayerFile()))
        if self.isPseudoTV() and SETTINGS.getSettingBool('Debug_Enable'):
            DIALOG.notificationDialog(LANGUAGE(32000))
            self._onStop(playingItem)
            
            
    def _runActions(self, action, citem={}, parameter=None, inherited=None):
        if self.runActions: return self.runActions(action, citem, parameter, inherited)
        else:               return parameter


    def _onSleep(self):
        self.log('_onSleep')
        sec = 0
        cnx = False
        inc = int(100/FIFTEEN)
        xbmc.playSFX(NOTE_WAV)
        dia = DIALOG.progressDialog(message=LANGUAGE(30078))
        while not self.abortRequested() and (sec < FIFTEEN):
            sec += 1
            msg = '%s\n%s'%(LANGUAGE(32039),LANGUAGE(32040)%(FIFTEEN-sec))
            dia = DIALOG.progressDialog((inc*sec),dia, msg)
            if self.service._shutdown(1.0) or dia is None:
                cnx = True
                break
        DIALOG.progressDialog(100,dia)
        return not bool(cnx)


    @timeit
    def _onIdle(self):
        self.log('_onIdle')
        def __chkPlayback():
            if self.pendingItem.get('invoked',-1) > 0:
                if not BUILTIN.isBusyDialog() and (time.time() - self.pendingItem.get('invoked',-1)) > 60:
                    self.onPlayBackError()

        def __chkBackground():
            remaining = floor(self.getRemainingTime())
            if floor(remaining) <= (OSD_TIMER*2):
                self.log('__chkBackground, remaining = %s'%(remaining))
                self.toggleBackground(self.enableOverlay)

        def __chkCallback():
            if not self.playingItem.get('callback'):
                self.playingItem['callback'] = self.jsonRPC.getCallback(self.playingItem)
                self.log('__chkCallback, callback = %s'%(self.playingItem['callback']))
                PROPERTIES.setEXTProperty('%s.lastPlayed.sysInfo'%(ADDON_ID),encodeString(dumpJSON(self.playingItem)))

        def __chkResumeTime():
            if not self.isPlayingFiller() and self.playingItem.get('isPlaylist',False):
                if self.playingItem.get('fitem',{}).get('file') == self.getPlayingFile():
                    resume = {"position":self.getPlayedTime(),
                              "total":   self.getPlayerTime(),
                              "file" :   self.playingItem.get('fitem',{}).get('file'),
                              "updated":{'instance':PROPERTIES.getFriendlyName(),'time':getUTCstamp()}}
                    self.playingItem.setdefault('resume',{}).update(resume)
                    self.log('__chkResumeTime, resume = %s'%(self.playingItem.get('resume')))

        def __chkOverlay():
            played = ceil(self.getPlayedTime())
            if not self.isPlayingFiller() and played > self.minDuration: 
                self.log('__chkOverlay, played = %s'%(played))
                self.toggleOverlay(self.enableOverlay)

        def __chkOnNext():
            played    = ceil(self.getPlayedTime())
            remaining = floor(self.getRemainingTime())
            totalTime = int(self.getPlayerTime() * (self.maxProgress / 100))
            threshold = abs((totalTime - (totalTime * .75)) - (ONNEXT_TIMER*3))
            intTime   = roundupDIV(threshold,3)
            if not self.isPlayingFiller() and played > self.minDuration and (remaining <= threshold and remaining >= intTime) and self.background is None: 
                self.log('__chkOnNext, played = %s, remaining = %s'%(played,remaining))
                self.toggleOnNext(bool(self.OnNextMode))
                
        def __chkSleep():
            if self.sleepTime > 0 and (self.idleTime > (self.sleepTime * 10800)):
                if not PROPERTIES.isRunning('Player.__chkSleep'):
                    with PROPERTIES.chkRunning('Player.__chkSleep'):
                        if self._onSleep(): self.stop()
                        
        if not PROPERTIES.isRunning('Player._onIdle'):
            with PROPERTIES.chkRunning('Player._onIdle'):
                __chkPlayback()
                __chkBackground()
                __chkResumeTime()
                __chkCallback()
                __chkOverlay()
                __chkOnNext()
                __chkSleep()
            
                
    def toggleBackground(self, state: bool=SETTINGS.getSettingBool('Overlay_Enable')):
        if state and self.background is None and self.monitor.isIdle:
            BUILTIN.executebuiltin('Dialog.Close(all)')
            self.background = Background(BACKGROUND_XML, ADDON_PATH, "default", player=self)
            self.background.show()
        elif not state and hasattr(self.background,'close'):
            self.background = self.background.close()
        else: return
        self.log("toggleBackground, state = %s, background = %s"%(state,self.background))


    def toggleOverlay(self, state: bool=SETTINGS.getSettingBool('Overlay_Enable')):
        if state and self.overlay is None and not self.isPlayingFiller():
            self.overlay = Overlay(player=self)
            self.overlay.open()
        elif not state and hasattr(self.overlay,'close'):
            self.overlay = self.overlay.close()
        else: return
        self.log("toggleOverlay, state = %s, overlay = %s"%(state, self.overlay))


    def toggleRestart(self, state: bool=bool(SETTINGS.getSettingInt('Restart_Percentage'))):
        if state and self.restart is None and not self.isPlayingFiller():
            self.restart = Restart(RESTART_XML, ADDON_PATH, "default", "1080i", player=self)
        elif not state and hasattr(self.restart,'onClose'):
            self.restart = self.restart.onClose()
        else: return
        self.log("toggleRestart, state = %s, restart = %s"%(state,self.restart))
        
        
    def toggleOnNext(self, state: bool=bool(SETTINGS.getSettingInt('OnNext_Mode'))):
        if state and self.onnext is None and not self.isPlayingFiller():
            self.onnext = OnNext(ONNEXT_XML, ADDON_PATH, "default", "1080i", player=self, mode=self.OnNextMode, position=self.onNextPosition, next=self.jsonRPC.getNextItem(self.playingItem.get('citem',{}),self.playingItem.get('nitem')))
        elif hasattr(self.onnext,'onClose'):
            self.onnext = self.onnext.onClose()
        else:
            self.onnext = None
        self.log("toggleOnNext, state = %s, onnext = %s"%(state,self.onnext))
    
        
    def toggleInfo(self, state: bool=SETTINGS.getSettingBool('Enable_OnInfo')):
        if state and not self.isPlayingFiller():
            BUILTIN.executewindow('ActivateWindow(fullscreeninfo)')
            timerit(self.toggleInfo)(float(OSD_TIMER),[False])
        elif not state and BUILTIN.getInfoBool('IsVisible(fullscreeninfo)','Window'):
            BUILTIN.executebuiltin('Action(back)')
            BUILTIN.executebuiltin('Dialog.Close(fullscreeninfo)')
        else: return
        self.log('toggleInfo, state = %s'%(state))


class Monitor(xbmc.Monitor):
    idleTime  = 0
    isIdle    = False
    isRunning = False

    def __init__(self, service=None):
        self.log('__init__')
        xbmc.Monitor.__init__(self)
        self.service    = service
        self.jsonRPC    = service.jsonRPC
        self.player     = Player(service,self)
        self.FIFOQUE    = CustomQueue(fifo=True, service=service)
        self.idleThread = Thread(target=self._start)
        self.idleThread.daemon = True
        
        
    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)

        
    def _que(self, func, delay=0, timer=0, *args, **kwargs):
        self.FIFOQUE._push((func, args, kwargs), 0, delay, timer)
        

    def _start(self):
        self.log('_start') 
        if not self.isRunning:
            self.isRunning = True
            while not self.abortRequested():
                if   self.service._shutdown(0.5): break
                elif self.player.isPlayingPseudoTV(): self._chkIdle()
            self.isRunning = False
            
        
    def _chkIdle(self):
        self.idleTime = BUILTIN.getIdle()
        self.isIdle   = bool(self.idleTime) | self.idleTime > OSD_TIMER
        self.log('_chkIdle, isIdle = %s, idleTime = %s'%(self.isIdle, self.idleTime))
        if self.isIdle: self.player._onIdle()
            
            
    def _onSettingsChanged(self):
        self.log('_onSettingsChanged') 
        self._que(self._updatePlayerSettings)
        self._que(self._updateServiceSettings)
        
        
    def onNotification(self, sender, method, data):
        self.log("onNotification, sender %s - method: %s  - data: %s" % (sender, method, data))
            

    def onSettingsChanged(self):
        self.log('onSettingsChanged')
        timerit(self._onSettingsChanged)(FIFTEEN)
        
            
    def _updateServiceSettings(self):
        self.log('_updateServiceSettings')
        self.service.channels = self.service.tasks.getVerifiedChannels()
        self.service.settings = self.service.tasks.chkSettingsChange(self.service.settings) #check for settings change, take action if needed
        
        
    def _updatePlayerSettings(self):
        self.log('_updatePlayerSettings')
        self.player.enableOverlay     = SETTINGS.getSettingBool('Overlay_Enable')
        self.player.infoOnChange      = SETTINGS.getSettingBool('Enable_OnInfo')
        self.player.disableTrakt      = SETTINGS.getSettingBool('Disable_Trakt')
        self.player.rollbackPlaycount = SETTINGS.getSettingBool('Rollback_Watched')
        self.player.saveDuration      = SETTINGS.getSettingBool('Store_Duration')
        self.player.minDuration       = SETTINGS.getSettingInt('Seek_Tolerance')
        self.player.maxProgress       = SETTINGS.getSettingInt('Seek_Threshold')
        self.player.sleepTime         = SETTINGS.getSettingInt('Idle_Timer')
        self.player.runWhilePlaying   = SETTINGS.getSettingBool('Run_While_Playing')
        self.player.restartPercentage = SETTINGS.getSettingInt('Restart_Percentage')
        self.player.OnNextMode        = SETTINGS.getSettingInt('OnNext_Mode')
        self.player.onNextPosition    = SETTINGS.getSetting("OnNext_Position_XY")
        
        
class Service():
    channels         = []
    isClient         = SETTINGS.getSettingBool('Enable_Client')
    pendingSuspend   = PROPERTIES.setPendingSuspend(False)
    pendingInterrupt = PROPERTIES.setPendingInterrupt(False)
    pendingShutdown  = PROPERTIES.setPendingShutdown(False)
    pendingRestart   = PROPERTIES.setPendingRestart(False)
    

    def __init__(self):
        self.log('__init__')        
        self.jsonRPC     = JSONRPC(service=self)
        self.monitor     = Monitor(service=self)
        self.player      = self.monitor.player
        self.tasks       = Tasks(service=self)
        self.settings    = SETTINGS.getCurrentSettings()
        self.isClient    = SETTINGS.getSettingBool('Enable_Client')
        self.priorityQUE = CustomQueue(priority=True, service=self)
        
        
    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)


    def _que(self, func, priority=-1, *args, **kwargs):# priority -1 autostack (FIFO), 1 Highest, 5 Lowest
        self.priorityQUE._push((func, args, kwargs), priority)


    def _playing(self) -> bool: #assert background service during playback
        if (self.player.isPlaying() or BUILTIN.isPaused()) and not self.player.runWhilePlaying: return True
        return False
    
        
    def _tasks(self):
        self._que(self.tasks._chkEpochTimer,-1,*('chkQueTimer', self.tasks.chkQueTimer, FIFTEEN)) #keep que alive after interrupt.
        
    
    def _shutdown(self, wait=1.0) -> bool: #service break
        pendingShutdown = (self.monitor.waitForAbort(wait) | PROPERTIES.isPendingShutdown())
        if self.pendingShutdown != pendingShutdown:
            self.pendingShutdown = pendingShutdown
            self.log('_shutdown, pendingShutdown = %s, wait = %s'%(self.pendingShutdown,wait))
        return self.pendingShutdown
    
    
    def _restart(self) -> bool: #service resetart
        pendingRestart = (self.pendingRestart | PROPERTIES.isPendingRestart())
        if self.pendingRestart != pendingRestart:
            self.pendingRestart = pendingRestart
            self.log('_restart, pendingRestart = %s'%(self.pendingRestart))
        return self.pendingRestart
         
        
    def _interrupt(self) -> bool: #task que break
        pendingInterrupt = (self.pendingShutdown | self.pendingRestart | self._playing() | PROPERTIES.isInterruptActivity() | BUILTIN.isScanning())
        if pendingInterrupt != self.pendingInterrupt:
            self.pendingInterrupt = PROPERTIES.setPendingInterrupt(pendingInterrupt)
            self.log('_interrupt, pendingInterrupt = %s'%(self.pendingInterrupt))
        return self.pendingInterrupt
    

    def _suspend(self) -> bool: #task que continue
        pendingSuspend = (PROPERTIES.isSuspendActivity() | BUILTIN.isSettingsOpened())
        if pendingSuspend != self.pendingSuspend:
            self.pendingSuspend = PROPERTIES.setPendingSuspend(pendingSuspend)
            self.log('_suspend, pendingSuspend = %s'%(self.pendingSuspend))
        return self.pendingSuspend
        

    def _initialize(self):
        self.monitor.idleThread.start()
        if self.isClient: self._que(self.tasks._client,1)
        else:             self._que(self.tasks._host,1)


    def _start(self):
        self.log('_start')
        self._initialize()
        if DIALOG.notificationWait('%s...'%(LANGUAGE(32054)),wait=OSD_TIMER):
            if self.player.isPlayingPseudoTV(): self.player.onAVStarted()
            while not self.monitor.abortRequested():
                if    self._shutdown(): break
                elif  self._restart():  break
                else: self._tasks()
            return self._stop(self.pendingRestart)


    def _stop(self, pendingRestart: bool=False):
        if self.player.isPlayingPseudoTV(): self.player.onPlayBackStopped()
        with PROPERTIES.interruptActivity():
            for thread in thread_enumerate():
                if thread.name != "MainThread" and thread.is_alive():
                    if hasattr(thread, 'cancel'): thread.cancel()
                    try: thread.join(1.0)
                    except: pass
                    self.log('_stop, closing %s...'%(thread.name))
        return pendingRestart