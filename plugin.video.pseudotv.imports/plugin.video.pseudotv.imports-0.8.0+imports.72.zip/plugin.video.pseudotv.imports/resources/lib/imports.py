#   Copyright (C) 2025 Lunatixz, mmadalone (madteevee fork)
#
# This file is part of PseudoTV Live (madteevee imports fork).
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# -*- coding: utf-8 -*-
"""
Live import support for PseudoTV (madteevee imports fork).

Pulls external M3U + XMLTV sources (local files or HTTP URLs) and surfaces
them as first-class channels in PseudoTV's `channels.json`, fully editable
through Channel Manager. Replaces the multi-instance IPTV Simple
configuration pattern where each upstream source needed its own PVR client.

Step 2 deliverable: parsers + skeleton. Sync orchestration lands in step 3,
UI in step 4. See plan history for full spec.

Module layout:
- module-level helpers — URL/scheme validation, ID generation, encoding sniff
- Imports class       — instance state + sync orchestration (stubs in step 2)

Threading note: instances live for one Builder.buildChannels cycle. Long-lived
state (cache validators, tombstones) is persisted in `channels.json` not on
the instance.
"""

import copy               # madteevee (imports fork, imports.69): syncAll's start snapshot (deep copies)
import hashlib
import json
import os
import random
import time
import urllib.parse

from globals     import *
from m3u         import M3U
from logo_links  import own_logo_basename, port_set
from xmltv       import parseExternalSource as _parse_xmltv_stream
import replay_helpers
import picture_helpers
import importcfg_helpers  # madteevee (imports fork, imports.69): import-entry fingerprints and the sync commit's merge
from kick_helpers import RENDER_ONLY_KICK  # imports.69: defined there; re-exported here (server.py, tests)


# madteevee (imports fork, imports.66): the User-Agent this add-on sends to
# picture hosts -- channel logos (Imports._fetchLogo) and the show-picture
# check (Imports._pictureFingerprint). Wikimedia (upload.wikimedia.org) and a
# few other providers block the default `python-requests/X.Y.Z` User-Agent;
# an identifying one follows the Wikimedia UA policy
# (https://meta.wikimedia.org/wiki/User-Agent_policy). Same value _fetchLogo
# has always sent.
_HTTP_USER_AGENT = 'PseudoTV-imports/%s (Kodi addon; https://github.com/mmadalone/PseudoTV_Live)' % ADDON_VERSION


# Allowlist for source URL schemes (plan H2 — basic SSRF/path-traversal mitigation).
# `special://` resolves via xbmcvfs.translatePath to addon_data paths; safe.
# `file://` is intentionally NOT included by default.
ALLOWED_M3U_SCHEMES = frozenset({'http', 'https', 'special'})
ALLOWED_EPG_SCHEMES = frozenset({'http', 'https', 'special'})


# imports.28: failure-aware retry / exponential backoff for the per-import
# refresh-interval gate. When an import enters last_status='failed', the
# gate normally waits the full refresh_interval_min before retrying — far
# too long for transient outages on operators with rim=600m (10h). The
# curves below define alternative retry cadences while the import is in
# a consecutive-failure run. `disabled` preserves pre-.28 behavior.
#
# Each curve is a list of seconds-until-next-retry indexed by fail_count.
# After the curve is exhausted (fail_count > len(curve)), delay doubles
# from the last entry. Always capped at refresh_interval_min so the
# operator-set ceiling is never exceeded.
RETRY_CURVES = {
    'aggressive': [60, 300, 900, 3600],   # 60s, 5m, 15m, 1h, then 2x to cap
    'slower':     [300, 1800, 7200],       # 5m, 30m, 2h, then 2x to cap
    'fixed':      [300],                   # always 5m (capped at rim)
}

# Cap on persisted fail_count. Backoff is bounded by refresh_interval_min
# anyway, so further growth is cosmetic — bounding the integer keeps
# tests/dashboard predictable and the channels.json record clean.
FAIL_COUNT_CAP = 20

# madteevee (imports fork, imports.59): bump when the fields we derive from a
# playlist change. An import whose stored `playlist_rev` is older reads its
# playlist in full once (validators ignored), so its channel records pick up
# the new fields even while the source answers "unchanged" (304), which
# would otherwise reuse the stored records. Rev 1: the playlist's own
# catch-up values (the Movistar+ catch-up row is gone) and `source_name`.
PLAYLIST_REREAD_REV = 1


def _playlistRev(import_cfg):
    """imports.59: the import's stored `playlist_rev` (0 when missing or not
    a number)."""
    try:
        return int(import_cfg.get('playlist_rev') or 0)
    except (TypeError, ValueError):
        return 0

# Mapping from settings.xml integer codes to curve names. settings.xml uses
# type="integer" with int-keyed <option> values (consistent with the
# imports.23 Imports_Sync_Interval_Minutes pattern; the spinner format
# resolves the labels via strings.po). Unknown codes fall back to
# 'aggressive' (the default).
RETRY_CURVE_BY_CODE = {
    0: 'disabled',
    1: 'aggressive',
    2: 'slower',
    3: 'fixed',
}


def computeRetryDelay(curve, fail_count, refresh_interval_sec):
    """Seconds until next retry for a failing import.

    Returns refresh_interval_sec when curve='disabled' or fail_count<=0
    (preserves pre-imports.28 behavior). For active curves, walks the
    curve indices; past the end, doubles from the last entry. Jitters
    ±12.5% to avoid a thundering herd if many imports fail in the same
    cycle (e.g., LAN outage). Always capped at refresh_interval_sec
    (operator-set ceiling).
    """
    if curve == 'disabled' or fail_count <= 0:
        return refresh_interval_sec
    if curve == 'fixed':
        return min(RETRY_CURVES['fixed'][0], refresh_interval_sec)
    arr = RETRY_CURVES.get(curve, RETRY_CURVES['aggressive'])
    n = min(fail_count, FAIL_COUNT_CAP)
    if n <= len(arr):
        delay = arr[n - 1]
    else:
        delay = arr[-1] * (2 ** (n - len(arr)))
    # Jitter ±12.5% — symmetric bound (Python's floor division on negative
    # values would make `-delay // 8` one larger than `delay // 8` in
    # magnitude, e.g. -60//8 = -8 vs 60//8 = 7; using the same positive
    # bound on both sides keeps the band actually symmetric).
    jitter_bound = delay // 8
    jitter = random.randint(-jitter_bound, jitter_bound) if jitter_bound > 0 else 0
    return max(1, min(delay + jitter, refresh_interval_sec))

# Maximum cascade scan steps before giving up (plan H5).
# 9999 + a small margin lets cascade exhaust the full namespace before
# marking a channel `unallocated`.
CASCADE_OVERFLOW_LIMIT = CHANNEL_LIMIT + 1


# madteevee (imports fork, imports.43): LiveTV-first availability hardening.
# Operator-flagged 2026-05-15 — imports should be visible to iptvsimple
# immediately at Kodi boot, not after Builder finishes rebuilding the
# Custom queue (~30 min wait with 20+ Custom channels). The pain manifests
# specifically in the post-cleanup + first-boot cases where the on-disk M3U
# is missing/empty AND the per-import `refresh_interval_min` gate keeps
# syncAll from re-fetching for hours.
#
# Two settings (resources/settings.xml `Imports_Boot_Strategy` +
# `Imports_Disk_Presence_Scope`, both `type="integer"` mirroring the
# imports.28 RETRY_CURVE_BY_CODE pattern) drive three behavior dimensions.
# The maps below decode the int-stored settings to string identifiers used
# throughout the code paths — cleaner than naked ints, idiomatic with
# imports.28.

# Imports_Boot_Strategy — what happens at service boot+5s
# (tasks.py:_startImportsThread._loop after the existing 5s delay).
BOOT_STRATEGY_BY_CODE = {
    0: 'disk_presence',   # default — no boot action; gate handles missing data on first cycle
    1: 'eager_render',    # render channels.json's existing import records to disk (no HTTP)
    2: 'force_sync',      # first chkImports call carries force_scope='all' (HTTP at every boot)
}

# Imports_Disk_Presence_Scope — what counts as "missing" for the gate's
# disk-presence check. See _isDiskMissing below.
DISK_PRESENCE_SCOPE_BY_CODE = {
    0: 'main_m3u',         # default — only check pseudotv.m3u; missing/empty forces ALL imports
    1: 'per_import_epg',   # check cache/epg_<id>.xml per-import; missing forces just that one
    2: 'both',             # either condition triggers (defense in depth)
}

# imports.43: stub-sized thresholds for the disk-presence check. 200 bytes
# is comfortably above the M3U header-only stub (`#EXTM3U ...\n` is ~107 B,
# the corruption shape past empty-write incidents have produced) and below
# any legitimate single-channel payload (one EXTINF + URL line is ~300 B).
# 100 bytes is above the self-closing `<tv/>` XML root (~50 B) that
# `render_xmltv`'s refuse-empty guard exists to prevent.
_DISK_PRESENCE_M3U_MIN_BYTES = 200
_DISK_PRESENCE_EPG_MIN_BYTES = 100


def _isDiskMissing(import_id, scope):
    """Return True when the on-disk artifact required by `scope` is missing
    or stub-sized for the given import. Caller treats True as "force-sync
    this import despite the refresh_interval_min gate."

    Scopes:
      'main_m3u'        — only check pseudotv.m3u (the merged file).
                          Triggers for ALL imports on a single positive
                          check (the main M3U is shared).
      'per_import_epg'  — check cache/epg_<import_id>.xml per-import.
                          Naming mirrors imports.py:_epgCachePath.
      'both'            — either condition triggers (defense in depth).

    Filesystem errors (rare: OSError from os.path.exists / getsize on a
    permission glitch or stat race) are treated as "missing" — fail-safe
    behavior so we force-sync rather than silently skip when we can't
    tell. Same rationale as the refuse-empty guard's bias toward "preserve
    disk content" — better to do an extra sync than to miss a real
    corruption.
    """
    if scope in ('main_m3u', 'both'):
        try:
            real = FileAccess.translatePath(M3UFLEPATH)
            if not os.path.exists(real) or os.path.getsize(real) < _DISK_PRESENCE_M3U_MIN_BYTES:
                return True
        except OSError:
            return True

    if scope in ('per_import_epg', 'both'):
        try:
            # Mirror imports.py:_epgCachePath naming. Function-local to
            # avoid forward-reference (_epgCachePath is an Imports method,
            # not module-level — this helper is module-level so we build
            # the path here directly).
            epg_path = FileAccess.translatePath(
                'special://profile/addon_data/%s/cache/epg_%s.xml' % (ADDON_ID, import_id),
            )
            if not os.path.exists(epg_path) or os.path.getsize(epg_path) < _DISK_PRESENCE_EPG_MIN_BYTES:
                return True
        except OSError:
            return True

    return False


# madteevee (imports fork, imports.56): RENDER_ONLY_KICK ('__render__') is the
# kick value that runs a normal, gated chkImports cycle right away -- no gate
# bypass, so no forced downloads. syncAll treats it exactly like
# force_scope=None. imports.69 moved it to kick_helpers (with the kick merge
# rules every setter now shares); the import at the top of this module keeps
# `from imports import RENDER_ONLY_KICK` working.

# imports.56: guide self-heal. An enabled import that has had a guide before
# (its per-import EPG cache exists) but has NO programmes in the guide data
# about to be written gets a forced sync instead of waiting out
# refresh_interval_min (10 h on madteevee). If that sync can't bring the
# guide back — e.g. nothing in the source matches the channels — don't keep
# re-forcing more often than this. Per process: a Kodi restart re-arms it.
GUIDE_SELFHEAL_MIN_INTERVAL_SEC = 3 * 3600
_GUIDE_SELFHEAL_LAST = {}  # {import_id: epoch of the last self-heal sync}

# madteevee (imports fork, imports.59, S12): dashboard messages for an import
# whose replay needs per-show links from its playlist add-on's guide export
# (replay_helpers.KNOWN_EXPORTERS). `name` is the exporter's name. Shown as
# last_error only while there is no other error; last_status and the failure
# counters are never touched. imports.70 (c): from
# replay_helpers.LINKS_STALE_AFTER_S (36 h) the export is too old to trust for
# shows that haven't started (the stale-export guard); LINKS_MSG_STALE says so.
LINKS_MSG_UNREADABLE = ("%(name)s guide file can't be read (%(reason)s). "
                        "Replay keeps using the links already saved. Restart Kodi or press "
                        "Export channels and EPG now in %(name)s settings, and check %(name)s is still logged in.")
LINKS_MSG_NO_LINKS   = "%(name)s guide file has no replay links, so replay is off."
LINKS_MSG_OUTDATED   = ("%(name)s guide file is out of date, so replay is paused. Restart Kodi or press "
                        "Export channels and EPG now in %(name)s settings, and check %(name)s is still logged in.")
LINKS_MSG_STALE      = ("%(name)s guide file is %(age)s old. Upcoming shows follow your guide where it "
                        "lists them, and keep replay only where both list them the same. Restart Kodi or "
                        "press Export channels and EPG now in %(name)s settings, and check %(name)s is "
                        "still logged in.")
LINKS_MSG_DECLARED   = ("%(name)s changed how it declares replay; replay may misbehave until this "
                        "add-on is updated.")
# imports.59 (S12/S17): Movistar+ writes its guide export in place with one
# write(), and Linux sets the mtime when that write starts. A stable read
# that can't be parsed, of a file modified less than this many seconds
# before the read, may have caught a writer that stalled mid-write: it is
# retried at the next cycle instead of being recorded as damaged.
LINKS_SETTLE_SECS = 120
# imports.70 (c), the user's choice of 2026-11-14: while the replay-links file
# is stale (replay_helpers.stale_after), a link-replay import is synced at
# every imports cycle once its last sync is at least this old
# (Imports._linksWentStale), so each channel's replay on/off (S9) follows the
# show on air within about an hour. Under an hour, so a cycle that starts a
# little early still syncs, and a shorter auto-sync interval
# (Imports_Sync_Interval_Minutes, 5 by default) doesn't sync it more often
# than about hourly. The check runs only when a cycle runs: with a longer
# interval at each cycle (every 2, 4 or 8 hours), and with automatic syncs
# off (0) only when a dashboard Refresh or Save starts one.
LINKS_STALE_RESYNC_SECS = 50 * 60


def _ofImport(value, suffix):
    """imports.59: True when `value` is a namespaced id ending in `suffix`
    ('@<import id>') -- the same test the XML branch's slice helpers use."""
    return isinstance(value, str) and value.endswith(suffix)


def _ageText(age_s):
    """imports.70: '40 hours' below two days, else '3 days' (whole units, rounded down)."""
    if age_s < 48 * 3600:
        return '%d hours' % (age_s // 3600)
    return '%d days' % (age_s // 86400)


def validate_source_url(url, allowed=ALLOWED_M3U_SCHEMES):
    """
    Allowlist scheme check for import source URLs.

    Returns the URL unchanged on success; raises ValueError on bad scheme.
    Per plan H2: minimal SSRF mitigation — operator pasting `file:///etc/passwd`
    or `http://localhost:8443/admin` should be refused at save time.

    Empty scheme (= bare absolute or relative local path like `/tmp/x.m3u`)
    is accepted — Kodi's xbmcvfs handles these uniformly.
    """
    if not url:
        raise ValueError('source URL is empty')
    parsed = urllib.parse.urlparse(url)
    scheme = (parsed.scheme or '').lower()
    if scheme == '':
        # Local path (no scheme). Accept; xbmcvfs handles relative/absolute paths.
        return url
    if scheme not in allowed:
        raise ValueError(
            "unsupported scheme '%s' (allowed: %s)" % (scheme, ', '.join(sorted(allowed)))
        )
    if scheme == 'special' and not url.startswith('special://'):
        raise ValueError("special:// URLs must use the 'special://' prefix form")
    return url


def fallback_channel_id(source_url):
    """
    Stable fallback channel id for sources without `tvg-id` (plan H7).

    Returns first 12 hex chars of MD5(url). MD5 used for non-cryptographic
    naming only; cryptographic strength not required.
    """
    if not source_url:
        return ''
    return hashlib.md5(source_url.encode('utf-8')).hexdigest()[:12]


def namespaced_channel_id(source_tvg_id, import_id, source_url=None):
    """
    Construct the PseudoTV channel ID for an imported channel.

    Format: `<source_tvg_id_or_urlhash>@<import_id>` (plan §2 channel ID format).
    Source tvg-id preferred for stability; URL hash fallback when source omits it.
    Both halves are sanitized to safe chars (alnum + `_-.`).
    """
    if not import_id:
        raise ValueError('import_id is required')
    head = (source_tvg_id or '').strip() or fallback_channel_id(source_url)
    if not head:
        raise ValueError('cannot derive channel id without tvg-id or source_url')
    # Sanitize both halves: keep alnum + `_-.`; replace anything else with `_`.
    head = re.sub(r'[^A-Za-z0-9_.\-]', '_', head)
    tail = re.sub(r'[^A-Za-z0-9_.\-]', '_', import_id)
    return '%s@%s' % (head, tail)


def is_remote_url(url_or_path):
    """True if the source string is a remote URL (http/https), False for local paths."""
    if not url_or_path:
        return False
    parsed = urllib.parse.urlparse(url_or_path)
    return (parsed.scheme or '').lower() in {'http', 'https'}


# madteevee (imports fork, imports.58): cached logo file names. A downloaded
# logo is saved as `<channel_id>~<version>.<ext>`, <version> being the first
# LOGO_VERSION_LEN hex chars of the MD5 of the picture (naming only, as in
# fallback_channel_id). A changed picture gets a new file name and so a new
# /images/ link: Kodi never re-checks a web image it has already cached
# (TextureCacheJob treats http(s) images as not updateable), so rewriting the
# file in place left Kodi on the old picture. `~` never occurs in a channel id
# (namespaced_channel_id keeps alnum + `_-.` around the `@`), so the id splits
# back off unambiguously. Pre-imports.58 files are `<channel_id>.<ext>`; they
# stay in use until their picture or address changes.
LOGO_VERSION_SEP = '~'
LOGO_VERSION_LEN = 8


def logo_file_channel_id(name):
    """Channel id a cache/logos/ file name belongs to — `<id>~<version>.<ext>`
    (imports.58) or the pre-imports.58 `<id>.<ext>`."""
    if LOGO_VERSION_SEP in name:
        return name.split(LOGO_VERSION_SEP, 1)[0]
    return name.rsplit('.', 1)[0]


# madteevee (imports fork, imports.66): show pictures in the guide. The
# placeholder-picture check's results ("verdicts") live in their own file in
# the cache folder (picture_helpers.VERDICTS_FILE; the format is described
# there), not in the channel records: machine-made state stays out of
# channels.json, as with the imports.58 logo bookkeeping. One writer,
# Imports.syncAll (_savePictureVerdicts); two readers, syncAll and server.py
# (GET /imports.json), both through loadPictureVerdicts.

def _pictureVerdictsPath():
    """imports.66: the verdicts file as a real filesystem path -- the same
    translation as Imports._epgCachePath. CACHE_LOC is read on every call,
    so tests can point it at a temporary folder."""
    return FileAccess.translatePath(os.path.join(CACHE_LOC, picture_helpers.VERDICTS_FILE))


def loadPictureVerdicts():
    """imports.66: the usable entries of the verdicts file, {channel id:
    verdict}, through picture_helpers.valid_verdicts. A missing, unreadable
    or damaged file gives {} -- "not checked yet", so every channel keeps
    its pictures until a check says otherwise. Never raises.

    FileAccess.getJSON takes no lock. That is safe here: the only writer
    replaces the file in one step (FileAccess.setJSON writes a temp file and
    os.replace's it, imports.59 S3), so a reader gets the old file or the
    new one, never half of one."""
    path = None
    try:
        path = _pictureVerdictsPath()
        return picture_helpers.valid_verdicts(FileAccess.getJSON(path))
    except Exception as e:
        log('Imports: loadPictureVerdicts, could not read %s: %s' % (path, e), xbmc.LOGWARNING)
        return {}


# --------------------------------------------------------------------------
# Imports class
# --------------------------------------------------------------------------

class Imports(object):
    """
    Orchestrator for live channel imports.

    Construction is cheap; heavy work happens inside `syncAll()`. Instances
    are typically created per-Builder-cycle by `Builder.buildChannels` (step 3
    integration) and discarded after `syncAll()` returns.

    Args:
        channels: `Channels` instance (writable) — mutated to add/refresh imported channels
        m3u:      `M3U` instance — `addStation()` invoked for each imported channel
        xmltv:    `XMLTVS` instance — `addChannel()`/`addProgramme()` invoked for EPG
        service:  `Service` instance for `_interrupt()`/`_suspend()` polling

    All four collaborators are optional at construction time so the class
    can be unit-tested in isolation (parsers don't need them).
    """

    def __init__(self, channels=None, m3u=None, xmltv=None, service=None):
        self.channels = channels
        self.m3u      = m3u
        self.xmltv    = xmltv
        self.service  = service

    def log(self, msg, level=None):
        # Default to LOGDEBUG; matches existing class pattern (m3u.py:82, channels.py).
        try:
            return log('%s: %s' % (self.__class__.__name__, msg),
                       level if level is not None else xbmc.LOGDEBUG)
        except NameError:
            # `log` not yet bound during unit-test import-time when globals are
            # stubbed; degrade silently.
            pass

    # ------------------------------------------------------------------
    # imports.43: LiveTV-first availability — boot-time render-from-persisted
    # ------------------------------------------------------------------

    def renderFromPersistedState(self):
        """Render the existing import-channel state from channels.json to disk
        (pseudotv.m3u) WITHOUT a fresh HTTP fetch.

        Called from `tasks.py:_startImportsThread._loop` at boot+5s when
        `Imports_Boot_Strategy` is set to `eager_render` (code 1). Operator-
        flagged 2026-05-15: with 20+ Custom channels building serially at
        ~90s each, imports stay invisible to iptvsimple for ~30 min on boot
        if the on-disk M3U is empty/missing. This method makes the LAST-
        KNOWN persisted import state visible immediately by rendering the
        type='import' enabled channels straight from channels.json into
        the in-memory M3UDATA + calling m3u._save (which triggers the
        renderers.render_m3u + write_atomic path imports.42 plumbs
        channel_count through).

        Guarded by `_isDiskMissing(scope='main_m3u')` — fires only when
        the on-disk M3U is missing or stub-sized (header-only). Healthy
        M3U → no-op return 0 (don't clobber existing data). This means
        the eager_render strategy is safe to leave enabled across reboots:
        normal boots with intact M3U skip this entirely, only post-cleanup
        or first-ever boots see the eager render fire.

        EPG content is NOT rendered here. Channels alone are enough for
        iptvsimple to load + let the operator tune them; EPG fills in on
        the natural chkImports cycle (≤5 min for autosync operators).
        Adding EPG would require parsing each `cache/epg_<id>.xml` per-
        import and merging into XMLTVDATA — meaningful complexity for
        marginal benefit. Defer to imports.44 if operators report long
        EPG-empty windows post-eager-render.

        Returns the count of imports rendered (excluding disabled), or 0
        if the on-disk M3U is already healthy / no imports are configured.
        Caller logs the result at INFO.

        Requires `self.channels` and `self.m3u` to be set (writable). When
        either is None (test/standalone construction) returns 0 silently.
        Idempotent — the imports.42 writer_lock + atomic-rename in
        `write_atomic` prevents torn writes if multiple boot-render calls
        race (shouldn't happen in practice — `_startImportsThread` is
        single-threaded — but defensive).
        """
        if self.channels is None or self.m3u is None:
            return 0
        # Guard: only fire when on-disk M3U is actually missing/stub.
        # Re-uses the same helper the gate disk-presence check uses, so
        # the trigger semantics are consistent across both paths.
        if not _isDiskMissing(import_id='__bootcheck__', scope='main_m3u'):
            return 0
        # Pull all enabled import-typed channels from channels.json. The
        # records carry full M3U EXTINF state (id, name, url, group, logo,
        # catchup, etc) — verified in the imports.43 planning phase via
        # Phase 1 exploration of the live channels.json shape. No HTTP
        # fetch, no re-parse — just the persisted state Builder/syncAll
        # produced on a prior cycle.
        try:
            all_channels = self.channels.getChannels() or []
        except Exception as e:
            self.log('renderFromPersistedState, channels.getChannels() failed: %s' % (e,),
                     level=xbmc.LOGWARNING)
            return 0
        # imports.69 (switching an import off): its records stay in
        # channels.json with their settings, but its channels leave the TV --
        # M3U.cleanSelf drops a switched-off import's stations at every load,
        # so this boot render must not publish them either. Records of an
        # import that is not listed at all are kept, as before.
        try:
            switched_off = {i.get('id') for i in (self.channels.getImports() or [])
                            if isinstance(i, dict) and i.get('id') and not i.get('enabled', True)}
        except Exception as e:
            self.log('renderFromPersistedState, channels.getImports() failed: %s' % (e,),
                     level=xbmc.LOGWARNING)
            switched_off = set()
        import_channels = [c for c in importcfg_helpers.without_import_records(all_channels, switched_off)
                           if c.get('type') == 'import' and c.get('enabled', True)]
        if not import_channels:
            return 0
        # imports.59 (S9): the same replay rule as syncAll, decided from the
        # guide _eagerImportsRender loaded into self.xmltv: a link-replay
        # channel whose show on air has no link is published without
        # catch-up. Applied to copies -- the records keep their values.
        offers = self._replayOffers(import_channels)
        stations = []
        for rec in import_channels:
            if offers.get(rec.get('id')) is False:
                rec = dict(rec)
                rec['catchup'] = ''
                rec['catchup-source'] = ''
                rec['catchup-days'] = ''
            stations.append(rec)
        # Direct stations-list assignment matches the shape M3U._save
        # expects (M3UDATA dict with 'stations' + 'recordings' keys per
        # m3u.py:75). Builder.__setStation does the same kind of mutation
        # per-channel; we just do it bulk for imports. Recordings stay
        # untouched (they're a different concept — DVR-style local
        # recordings, not live imports).
        self.m3u.M3UDATA['stations'] = stations
        saved = self.m3u._save()   # imports.42 plumbs channel_count for breaker + INFO log
        if saved:
            return len(import_channels)
        return 0

    # ------------------------------------------------------------------
    # Parsers — implemented in step 2
    # ------------------------------------------------------------------

    def parseM3U(self, content, import_id):
        """
        Parse external M3U bytes into a list of imported-channel dicts.

        Each dict carries:
        - `id`              — namespaced PseudoTV channel ID (`<tvg_id>@<import_id>`)
        - `epg_id`          — original source `tvg-id` (for XMLTV match in step 3)
        - `import_source`   — `import_id` argument
        - `source_tvg_chno` — original source channel number (int) or None
        - `source_url`      — playable URL from the M3U URL line
        - all standard EXTINF attrs preserved verbatim (group, logo, catchup-source, etc.)

        Caller (`syncOne` in step 3) is responsible for cascade allocation,
        operator-override application, tombstone filtering, and the final
        write into `pseudotv.m3u`. This method does no I/O and no mutation.
        """
        raw = M3U.parseExternalSource(content, log_callback=lambda m: self.log(m))
        out = []
        for entry in raw:
            src_tvg_id = entry.get('id') or ''
            cid = namespaced_channel_id(src_tvg_id, import_id, source_url=entry.get('url'))
            chno = entry.get('number')
            out.append({
                # PseudoTV-side identity
                'id'            : cid,
                'import_source' : import_id,
                'epg_id'        : src_tvg_id,            # original; matches XMLTV
                'source_tvg_chno': int(chno) if isinstance(chno, int) else None,
                'source_url'    : entry.get('url', ''),
                # Source-side fields preserved verbatim (caller may override)
                'name'          : entry.get('name', ''),
                # imports.59 (S18): the playlist's own name, refreshed on every
                # full read even when the operator renamed the channel ('name'
                # in operator_overrides). syncAll's guide matcher also tries it,
                # so a renamed channel keeps matching a guide whose channel ids
                # are display names (davidmuma) on an unchanged (304) sync.
                # render_m3u emits only M3U_TEMP keys, so it never reaches
                # pseudotv.m3u.
                'source_name'   : entry.get('name', ''),
                'logo'          : entry.get('logo', ''),
                'group'         : list(entry.get('group', [])),
                'catchup'       : entry.get('catchup', ''),
                'catchup-source': entry.get('catchup-source', ''),
                'catchup-days'  : entry.get('catchup-days', ''),
                'catchup-correction': entry.get('catchup-correction', ''),
                'radio'         : bool(entry.get('radio', False)),
                'realtime'      : bool(entry.get('realtime', False)),
                'media'         : bool(entry.get('media', False)),
                'media-dir'     : entry.get('media-dir', ''),
                'media-size'    : entry.get('media-size', ''),
                'tvg-shift'     : entry.get('tvg-shift', ''),
                'provider'      : entry.get('provider', ''),
                'provider-type' : entry.get('provider-type', ''),
                'provider-logo' : entry.get('provider-logo', ''),
                'kodiprops'     : list(entry.get('kodiprops', [])),
                'extvlcopt'     : list(entry.get('extvlcopt', [])),
                'webprops'      : list(entry.get('webprops', [])),
                'x-playlist-type': entry.get('x-playlist-type', ''),
            })
        return out

    def parseXMLTV(self, source, channel_id_filter=None, strict=False):
        """
        Yield (kind, dict) tuples from an external XMLTV source.

        Wraps `xmltv.parseExternalSource` (auto gzip detection, streaming via
        iterparse + element clear). `channel_id_filter` is an optional iterable
        of source-side XMLTV channel ids; programmes whose `channel=` attr is
        not in the filter are skipped (saves memory when most of the source's
        channels aren't needed by this import).

        imports.59: `strict` is passed through. False (default) keeps the
        lenient behaviour every guide source uses; True raises on an empty or
        truncated document (the replay-links read, see _readLinks).

        Note: yielded dicts contain SOURCE-SIDE channel ids. Caller (step 3)
        is responsible for rewriting `id` / `channel` to the namespaced form
        (`<source_id>@<import_id>`) before writing to `pseudotv.xml`. This
        rewrite is what prevents IPTV Simple's tvg-id dedup from silently
        dropping channels with same source-side tvg-id (plan G1).
        """
        return _parse_xmltv_stream(
            source,
            channel_id_filter=channel_id_filter,
            log_callback=lambda m: self.log(m),
            strict=strict,
        )

    # ------------------------------------------------------------------
    # Sync orchestration — stubs; implementation lands in step 3
    # ------------------------------------------------------------------

    def syncOne(self, import_cfg, existing_channels, full_read=False):
        """
        Sync a single import: fetch (conditional) + parse + reconcile.

        Does NOT write to channels.json or M3U/XMLTV — returns a delta
        for the caller (syncAll) to merge after running cascadeAllocate
        across all imports.

        imports.69: `full_read=True` (syncAll: the import's settings changed
        since its last sync) reads the playlist in full once, without its
        download markers, so the new settings go through reconcile even
        when the source is unchanged. Download markers are only ever sent
        to the address they came from (m3u_source_key / epg_source_key).

        Returns dict:
        {
            'import_id'   : str,
            'status'      : str,            # 'ok' | 'unchanged' | 'failed' | 'disabled'
                                            # | 'warning' (imports.70: a playlist with
                                            # no channels; the import's channels kept)
            'updated_cfg' : dict,           # import_cfg with refreshed etag/last_modified/last_*
            'parsed'      : list,           # parseM3U output (namespaced channels)
            'new'         : list,           # channels not yet in existing
            'refreshed'   : list,           # (existing, parsed) pairs
            'orphans'     : list,           # existing channels missing from source
            'epg_pairs'   : list,           # (kind, dict) tuples from XMLTV parse
                                            # — caller rewrites channel ids before pushing
            'epg_id_map'  : dict,           # {source_tvg_id: namespaced_id} for EPG rewrite
            'error'       : str or None,
            # imports.69, present only when set (readers use .get()):
            'rediscovered'      : list,     # tombstoned ids re-created (Re-discover ticked)
            'epg_cache_written' : True,     # this sync replaced cache/epg_<id>.xml
            # imports.70, per-sync only, never stored:
            'epg_source_changed': True,     # a parsed download from another guide
                                            # address than the cached one's
            'epg_cache_mtime'   : float,    # the saved guide's mtime, taken before the
                                            # download-failed fallback read it (or None)
        }
        """
        result = {
            'import_id'  : import_cfg.get('id', ''),
            'status'     : 'failed',
            'updated_cfg': dict(import_cfg),
            'parsed'     : [],
            'new'        : [],
            'refreshed'  : [],
            'orphans'    : [],
            'epg_pairs'  : [],
            'epg_id_map' : {},
            'error'      : None,
        }
        import_id = import_cfg.get('id', '')

        if not import_cfg.get('enabled', True):
            result['status'] = 'disabled'
            return result
        if not import_id:
            result['error'] = 'import has no id'
            return result

        # ---- M3U fetch + parse ----
        m3u_source = import_cfg.get('m3u_url') or import_cfg.get('m3u_path')
        if m3u_source:
            # imports.59 (S8): an import whose playlist_rev predates
            # PLAYLIST_REREAD_REV reads its playlist in full once (no
            # validators, so no 304). The rev is stored only after that read
            # parses into channels (200 branch below); a failed or empty read
            # tries again next sync.
            reread = _playlistRev(import_cfg) < PLAYLIST_REREAD_REV
            if reread:
                self.log('[%s] syncOne, reading the playlist in full once (playlist_rev %d < %d)'
                         % (import_id, _playlistRev(import_cfg), PLAYLIST_REREAD_REV), level=xbmc.LOGINFO)
            # imports.69: download markers (etag / last_modified) are sent only
            # to the address they came from -- the logo cache's rule
            # (_cacheLogo). m3u_source_key fingerprints that address; it is
            # stored where the markers are confirmed (a 304, or a 200 that
            # parsed into channels). Markers of another address are dropped
            # and the playlist is read in full. An entry from before
            # imports.69 has no key: its markers can only be the current
            # address's (every address change went through a Save that wiped
            # them), so they are still sent.
            m3u_key = importcfg_helpers.source_key(m3u_source)
            if importcfg_helpers.source_changed(import_cfg.get('m3u_source_key'), m3u_key):
                result['updated_cfg'].pop('etag', None)
                result['updated_cfg'].pop('last_modified', None)
                reread = True
                self.log('[%s] syncOne, playlist address changed since its saved validators -- reading it in full'
                         % (import_id,), level=xbmc.LOGINFO)
            elif full_read and not reread:
                # imports.69: the import's settings changed since its last sync
                # (syncAll's config_key gate). A "304 unchanged" would hand only
                # the stored records to reconcile, so a ticked Re-discover could
                # not bring a deleted channel back: read in full once.
                reread = True
                self.log('[%s] syncOne, settings changed -- reading the playlist in full once' % (import_id,),
                         level=xbmc.LOGINFO)
            fetched = self.fetchSource(
                m3u_source,
                etag=None if reread else result['updated_cfg'].get('etag'),
                last_modified=None if reread else result['updated_cfg'].get('last_modified'),
            )
            if fetched['status'] == 304:
                # Source unchanged — but we still need to know what's there
                # to allow cascade allocation. Re-parse from operator's
                # cached/known set: skip the parse step and use existing
                # channels for this import as the "parsed" list.
                self.log('[%s] syncOne, source unchanged (304); preserving channels' % import_id)
                result['status'] = 'unchanged'
                # imports.57: a 304 means the source is identical to the last
                # full read — the read that marked any orphans — so those are
                # still absent and must not be handed to reconcile as "parsed".
                # Pre-imports.57 every stored record (orphans included) went
                # through as parsed, applyRefresh cleared is_orphan, and the
                # channels the source had dropped came back on the next
                # routine sync: live, 11 Movistar+ channels (outside the
                # account's package, or gone from the catalogue) flipped in
                # and out of the channel list. A channel the source lists
                # again still returns through the next full (200) read.
                result['parsed'] = [
                    c for c in existing_channels
                    if c.get('import_source') == import_id
                    and not c.get('is_orphan')
                ]
                # epg_id_map for unchanged path
                result['epg_id_map'] = {
                    c.get('epg_id'): c.get('id')
                    for c in result['parsed']
                    if c.get('epg_id') and c.get('id')
                }
                # No reconcile when nothing's parsed-fresh — just no-op
                result['updated_cfg']['last_status'] = 'unchanged'
                result['updated_cfg']['last_error']  = None
                # imports.25: update last_sync_at on EVERY attempt outcome, not just
                # 200. Semantics shift: "time of last sync attempt", not "time of
                # last successful content fetch". Required by the per-import
                # refresh_interval_min gate in syncAll (~line 486), which keys on
                # `now - last_sync_at < interval * 60`. If last_sync_at didn't
                # advance on 304s, a 304-returning source would always look due,
                # and refresh_interval_min would have no effect. The display side
                # (manager.html "last sync N ago") is more honest under the new
                # semantic too — a 304 IS a successful poll.
                result['updated_cfg']['last_sync_at'] = int(time.time())
                # DO refresh etag/last_modified in case server rotated them
                if fetched.get('etag'):          result['updated_cfg']['etag']          = fetched['etag']
                if fetched.get('last_modified'): result['updated_cfg']['last_modified'] = fetched['last_modified']
                # imports.69: the markers are confirmed for this address.
                result['updated_cfg']['m3u_source_key'] = m3u_key
                # Skip to EPG fetch (still try; might have its own cadence)
            elif fetched['status'] != 200:
                result['error'] = fetched.get('error') or ('M3U fetch status %s' % fetched['status'])
                result['updated_cfg']['last_status'] = 'failed'
                result['updated_cfg']['last_error']  = result['error']
                # imports.25: record the attempt (see 304-path comment above for rationale)
                result['updated_cfg']['last_sync_at'] = int(time.time())
                self.log('[%s] syncOne, M3U fetch failed: %s' % (import_id, result['error']),
                         level=xbmc.LOGWARNING)
                return result
            else:
                # status == 200 — fresh content
                try:
                    parsed = self.parseM3U(fetched['content'], import_id)
                except ValueError as e:
                    result['error'] = 'M3U parse failed: %s' % e
                    result['updated_cfg']['last_status'] = 'failed'
                    result['updated_cfg']['last_error']  = result['error']
                    # imports.25: record the attempt (see 304-path comment for rationale)
                    result['updated_cfg']['last_sync_at'] = int(time.time())
                    self.log('[%s] syncOne, %s' % (import_id, result['error']),
                             level=xbmc.LOGWARNING)
                    return result
                if not parsed:
                    # Empty parsed list — defensive: don't mass-orphan (G24).
                    # imports.70: the result says 'warning' too, as stored.
                    # It stayed 'failed', so syncAll counted an empty
                    # playlist as a failure (fail_count, failed_since:
                    # backoff and abandon) against imports.28's rule that a
                    # warning leaves them alone. Like 'failed', 'warning' is
                    # not 'ok'/'unchanged': the import stays out of this
                    # cycle's allocation, links read and guide merge, and its
                    # channels keep their records, numbers, playlist entries
                    # and guide as they are.
                    result['status'] = 'warning'
                    result['error'] = 'M3U parse yielded zero channels (kept previous)'
                    result['updated_cfg']['last_status'] = 'warning'
                    result['updated_cfg']['last_error']  = result['error']
                    result['parsed'] = [
                        c for c in existing_channels
                        if c.get('import_source') == import_id
                    ]
                    # imports.25: record the attempt (see 304-path comment for rationale)
                    result['updated_cfg']['last_sync_at'] = int(time.time())
                    self.log('[%s] syncOne, %s' % (import_id, result['error']),
                             level=xbmc.LOGWARNING)
                    return result
                result['parsed'] = parsed
                result['epg_id_map'] = {
                    c['epg_id']: c['id']
                    for c in parsed if c.get('epg_id')
                }
                if fetched.get('etag'):          result['updated_cfg']['etag']          = fetched['etag']
                if fetched.get('last_modified'): result['updated_cfg']['last_modified'] = fetched['last_modified']
                # imports.59 (S8): a full read parsed into channels -- the records
                # now carry every field derived at this rev.
                result['updated_cfg']['playlist_rev'] = PLAYLIST_REREAD_REV
                # imports.69: the markers stored above came from this address.
                result['updated_cfg']['m3u_source_key'] = m3u_key

        # If neither m3u_url nor m3u_path: this is an EPG-only import
        # (plan G7). Caller's existing channels with epg_id set are the
        # match candidates. Skip the parse step.
        else:
            result['parsed'] = []
            self.log('[%s] syncOne, EPG-only import' % import_id)

        # ---- Reconcile against existing channels ----
        existing_for_this_import = [
            c for c in existing_channels
            if c.get('import_source') == import_id
        ]
        new_channels, refreshed_pairs, orphans = self.reconcile(
            result['parsed'], existing_for_this_import, import_cfg
        )
        result['new']       = new_channels
        result['refreshed'] = refreshed_pairs
        result['orphans']   = orphans

        # imports.69: Re-discover. With the box ticked, reconcile hands every
        # tombstoned id the source lists again back as a NEW channel, so these
        # are exactly the deleted channels this sync re-creates. The sync's
        # commit keeps them only while the box is still ticked on disk, and
        # removes them from the tombstones in the same write
        # (importcfg_helpers.apply_sync_results).
        tombstones = import_cfg.get('tombstones') or []
        if import_cfg.get('rediscover_deleted') and tombstones:
            result['rediscovered'] = sorted(set(tombstones).intersection(
                c.get('id') for c in new_channels if c.get('id')))

        # Apply field merging to refreshed channels in place
        for existing, parsed in refreshed_pairs:
            self.applyRefresh(existing, parsed)

        # Mark orphans
        for orphan in orphans:
            orphan['is_orphan'] = True

        # ---- EPG fetch + parse ----
        epg_source = import_cfg.get('epg_url') or import_cfg.get('epg_path')
        if epg_source:
            # Conditional GET against the per-import EPG cache file at
            # CACHE_LOC/epg_<import_id>.xml. On 200 we (re)parse + (re)write
            # the cache; on 304 we hydrate epg_pairs from the cache so the
            # `XMLTVS._load.cleanSelf` slug-strip on startup doesn't cost us
            # this import's EPG. If the cache is missing/corrupt on a 304,
            # we clear the validators in updated_cfg so the next cycle
            # force-fetches (one-cycle self-heal).
            #
            # imports.69: as for the playlist, the guide's markers go only to
            # the address they came from. epg_source_key names the address
            # whose download is in cache/epg_<id>.xml and whose markers are
            # stored; it is set where this sync replaces that file (the
            # cached_ok branch below, with result['epg_cache_written']), so a
            # 304 can never load another address's guide as this one's. The
            # sync's commit keeps file and key together when two syncs overlap
            # or the address changes while this one runs (apply_sync_results).
            epg_key = importcfg_helpers.source_key(epg_source)
            if importcfg_helpers.source_changed(import_cfg.get('epg_source_key'), epg_key):
                result['updated_cfg'].pop('epg_etag', None)
                result['updated_cfg'].pop('epg_last_modified', None)
                self.log('[%s] syncOne, guide address changed since its saved validators -- full download'
                         % (import_id,), level=xbmc.LOGINFO)
            epg_fetched = self.fetchSource(
                epg_source,
                etag=result['updated_cfg'].get('epg_etag'),
                last_modified=result['updated_cfg'].get('epg_last_modified'),
            )
            # imports.56: `epg_error` records why this cycle produced no usable
            # guide (download failed, unparseable or empty body, or a 304 with
            # no readable cache). Pre-imports.56 each of those left
            # epg_pairs=[] while epg_id_map was populated, and syncAll's XML
            # branch then pruned this import's whole guide and appended
            # nothing. Movistar+ (local M3U, guide from GitHub) lost its entire
            # guide every time the internet dropped during a sync, and the
            # refresh_interval_min gate then kept it gone for up to 10 h.
            epg_error = None
            if epg_fetched['status'] == 200:
                # Don't filter at parse time — many EPG sources (davidmuma EPG_dobleM,
                # other regional EPGs) use human-readable display names as channel
                # attributes on <programme> too, not just on <channel>. A tvg-id-only
                # filter drops those programmes silently. syncAll's _match function
                # handles both id-exact AND normalized-name fallback per channel,
                # so filtering there gets the correct set.
                # Memory cost is bounded by iterparse + elem.clear() — even a 50MB
                # EPG processes in <100MB RSS regardless of total programme count.
                epg_pairs = None
                try:
                    epg_pairs = list(self.parseXMLTV(epg_fetched['content']))
                except Exception as e:
                    epg_error = 'guide parse failed: %s' % (e,)
                if epg_pairs:
                    result['epg_pairs'] = epg_pairs
                    self.log('[%s] syncOne, parsed EPG: %d items' % (import_id, len(epg_pairs)))
                    # imports.70 (a): a parsed guide from another address than the one
                    # whose guide is cached (imports.69's epg_source_key) -- the XML
                    # branch gives upcoming shows the new guide's details. Only here:
                    # the cache fallback below still holds the OLD address's guide, and
                    # a 304 has nothing new. Independent of the cache write: if that
                    # fails, the key stays and the next download re-describes again
                    # (idempotent). No flag for an entry without a key (legacy).
                    if importcfg_helpers.source_changed(import_cfg.get('epg_source_key'), epg_key):
                        result['epg_source_changed'] = True
                        self.log('[%s] syncOne, new guide address -- upcoming shows take its details'
                                 % import_id, level=xbmc.LOGINFO)
                    # Persist the fetched bytes to per-import cache BEFORE updating
                    # validators in updated_cfg — if the write fails we keep
                    # validators at their previous (now-mismatched) state so the
                    # next cycle force-fetches.
                    # imports.56: only a body that parsed into a usable guide may
                    # replace the cache. The cache is the fallback below, so an
                    # error page or a truncated download must never overwrite the
                    # last good copy.
                    cached_ok = self._epgCacheWrite(import_id, epg_fetched['content'])
                    if cached_ok:
                        if epg_fetched.get('etag'):          result['updated_cfg']['epg_etag']          = epg_fetched['etag']
                        if epg_fetched.get('last_modified'): result['updated_cfg']['epg_last_modified'] = epg_fetched['last_modified']
                        # imports.69: the cache file now holds this address's
                        # download. The flag is a result key, never stored.
                        result['updated_cfg']['epg_source_key'] = epg_key
                        result['epg_cache_written'] = True
                elif epg_error is None:
                    epg_error = 'guide download contained no guide data'
            elif epg_fetched['status'] == 304:
                cached_pairs = self._epgCacheRead(import_id)
                if cached_pairs is not None:
                    result['epg_pairs'] = cached_pairs
                    self.log('[%s] syncOne, EPG 304 hydrated from cache (%d items)'
                             % (import_id, len(cached_pairs)),
                             level=xbmc.LOGINFO)
                    # imports.69 (step 2's request R4): an entry from before
                    # imports.69 has no epg_source_key. Its markers can only be
                    # this address's (every address change went through a Save
                    # that dropped them) and this 304 just loaded the cached
                    # guide they describe, so the key is recorded here; a guide
                    # that always answers "unchanged" would otherwise never get
                    # one. A key already stored is never touched on a 304.
                    if not import_cfg.get('epg_source_key'):
                        result['updated_cfg']['epg_source_key'] = epg_key
                else:
                    # Cache missing or corrupt — clear validators so next cycle
                    # force-fetches a fresh copy and rebuilds the cache file.
                    result['updated_cfg']['epg_etag']          = None
                    result['updated_cfg']['epg_last_modified'] = None
                    epg_error = 'guide unchanged upstream but the cached copy is missing or unreadable'
            else:
                epg_error = 'guide download failed: %s' % (
                    epg_fetched.get('error') or 'status %s' % (epg_fetched.get('status'),))

            if epg_error:
                # imports.56: fall back to the last good cached guide (the 304
                # branch already tried it). With no usable cache, flag the
                # result so syncAll's XML branch keeps this import's previous
                # guide instead of pruning it.
                cached_pairs = None
                if epg_fetched['status'] != 304:
                    # imports.70 (c): the time of the saved guide this sync falls back
                    # to, taken BEFORE reading it: a file replaced in between can only
                    # be newer than recorded, which keeps the stale-export guard off
                    # (_staleCut), today's behaviour. Per-sync result, never stored.
                    try:
                        result['epg_cache_mtime'] = os.stat(self._epgCachePath(import_id)).st_mtime
                    except (OSError, ValueError):
                        result['epg_cache_mtime'] = None
                    cached_pairs = self._epgCacheRead(import_id)
                if cached_pairs:
                    result['epg_pairs'] = cached_pairs
                    result['epg_fallback'] = 'using the cached guide'
                else:
                    result['epg_keep_previous'] = True
                    result['epg_fallback'] = 'kept the previous guide'
                result['epg_error'] = epg_error
                self.log('[%s] syncOne, %s — %s' % (import_id, epg_error, result['epg_fallback']),
                         level=xbmc.LOGWARNING)

        # Success
        if result['status'] == 'failed':
            result['status'] = 'ok'
        result['updated_cfg']['last_status']  = result['status']
        result['updated_cfg']['last_error']   = None
        result['updated_cfg']['last_sync_at'] = int(time.time())
        # imports.56: a guide failure leaves `status` alone — 'ok'/'unchanged'
        # keeps the import in cascade allocation and resets the M3U failure
        # counter — but shows on the dashboard via last_error and drives the
        # gate's failure-retry curve through its own counter, so the guide is
        # retried soon instead of after refresh_interval_min.
        if result.get('epg_error'):
            try:
                prev_efc = int(import_cfg.get('epg_fail_count') or 0)
            except (TypeError, ValueError):
                prev_efc = 0
            result['updated_cfg']['epg_fail_count'] = min(prev_efc + 1, FAIL_COUNT_CAP)
            err = result['epg_error']
            result['updated_cfg']['last_error'] = '%s%s (%s)' % (err[:1].upper(), err[1:], result['epg_fallback'])
        elif import_cfg.get('epg_fail_count'):
            result['updated_cfg']['epg_fail_count'] = 0
        return result

    def _readLinks(self, import_id, exporter, updated_cfg, tvg_ids):
        """imports.59 (S10.2/S12): read the exporter add-on's guide export --
        the replay links -- for an import that uses link-based replay.

        `exporter` is replay_helpers.exporter_for's (addon id, spec, links
        path); `tvg_ids` the source ids of the import's link-replay channels
        (only their programmes are parsed). Returns {'pairs', 'warning'}:
        the parsed (kind, dict) pairs (source-side ids) and the dashboard
        message for the state of the file, or None.

        A full read every sync (fetchSource with no validators: the safe
        local read of _fetchLocal) and a strict parse, so an empty, cut-off
        or broken file is rejected as a whole: no links from it, and the
        links already in the guide stay. There is no cache file -- the export
        is local and stays on disk, and the published guide keeps the links
        when it can't be read.

        updated_cfg['links_mtime_ns'] records the file's st_mtime_ns after
        every read during which the file did not change, parsed or not, so
        the new-links trigger (_linksChanged) forces a sync only for a NEW
        file and a damaged one isn't re-read every hour. It is stored as a
        decimal string: the number is above JavaScript's 2^53, and the
        dashboard posts the import list back after an edit, rounded. A
        stored value means "this file was read", not "its links reached the
        guide": if the merge then fails (logged as an error), the trigger
        doesn't force a re-read; the import's next sync (at most its
        refresh interval), a dashboard Refresh or a new export reads and
        merges the file again. The links already in the guide cover the
        coming days, and a repeating error must not force a sync every
        hour.

        Nothing is stored and nothing shown (the trigger retries) for a read
        during which the file changed, and for a stable read that can't be
        parsed of a file modified less than LINKS_SETTLE_SECS before: the
        exporter may still be writing it. imports.70: such a read also
        returns 'retry': True, so that sync doesn't run the stale-export
        guard on the stored (old) file time with no listing to judge by
        (_mergeReplayLinks): the links already in the guide stay.
        """
        addon_id, spec, path = exporter
        name = spec.get('name') or addon_id
        out = {'pairs': [], 'warning': None}
        fetched = self.fetchSource(path)
        if fetched.get('transient'):
            self.log('[%s] syncAll, replay links file changed while reading; will retry' % (import_id,),
                     level=xbmc.LOGINFO)
            out['retry'] = True
            return out
        mtime_ns = fetched.get('mtime_ns')
        reason = detail = None
        if fetched.get('status') != 200:
            reason = 'missing' if mtime_ns is None else 'unreadable'
            detail = fetched.get('error')
        else:
            try:
                out['pairs'] = list(self.parseXMLTV(fetched.get('content'),
                                                    channel_id_filter=tvg_ids, strict=True))
            except Exception as e:
                out['pairs'] = []
                reason = 'damaged' if fetched.get('content') else 'empty file'
                detail = str(e) or e.__class__.__name__
        if reason in ('damaged', 'empty file') and isinstance(mtime_ns, int):
            # imports.59 (S12/S17): Linux sets the mtime when the exporter's
            # single write() starts, so a stable but cut-off read of a file
            # this young may be a stalled writer; its final mtime wouldn't
            # change again. Retried like a read the file changed during. A
            # future mtime (clock change) proves nothing and is recorded.
            age_s = time.time() - mtime_ns / 1e9
            if 0 <= age_s < LINKS_SETTLE_SECS:
                self.log('[%s] syncAll, replay links file %s, modified %.0fs ago -- may still be being written; will retry'
                         % (import_id, reason, age_s), level=xbmc.LOGINFO)
                out['retry'] = True
                return out
        if isinstance(mtime_ns, int):
            updated_cfg['links_mtime_ns'] = str(mtime_ns)
        if reason is not None:
            self.log("[%s] syncAll, replay links file can't be used (%s): %s -- the links already in the guide stay"
                     % (import_id, reason, detail), level=xbmc.LOGWARNING)
            out['warning'] = LINKS_MSG_UNREADABLE % {'name': name, 'reason': reason}
            return out

        now = time.time()
        stops = []
        for kind, item in out['pairs']:
            if kind != 'programme':
                continue
            link = item.get('catchup-id')
            if isinstance(link, str) and link.strip():
                stop = replay_helpers.xmltv_to_epoch(item.get('stop'))
                if stop is not None:
                    stops.append(stop)
        if not stops:
            out['warning'] = LINKS_MSG_NO_LINKS % {'name': name}
        elif max(stops) <= now:
            out['warning'] = LINKS_MSG_OUTDATED % {'name': name}
        elif replay_helpers.stale_after(mtime_ns, now) is not None:
            # imports.70 (c): from 36 h (before: 4 days), when the stale-export
            # guard takes over the upcoming shows. stale_after parsed mtime_ns
            # as a whole number (an int, or the decimal text links_mtime_ns is
            # stored as), so int() is safe here.
            out['warning'] = LINKS_MSG_STALE % {'name': name, 'age': _ageText(now - int(mtime_ns) / 1e9)}
        self.log('[%s] syncAll, replay links file read: %d links%s'
                 % (import_id, len(stops), (' (%s)' % out['warning']) if out['warning'] else ''),
                 level=xbmc.LOGINFO if out['warning'] else xbmc.LOGDEBUG)
        return out

    @staticmethod
    def _declaredReplayWarning(exporter, link_records):
        """imports.59 (S12): the dashboard message when the import's
        link-replay channels (as just merged) declare catch-up differently
        from the exporter's verified form (KNOWN_EXPORTERS 'catchup'), else
        None. Only link-based records count, so a non-link catch-up (e.g. the
        old Movistar+ row restored) never triggers it."""
        addon_id, spec = exporter[0], exporter[1]
        want = spec.get('catchup')
        declared = {(c.get('catchup') or '', c.get('catchup-source') or '') for c in link_records or ()}
        if want and declared and declared != {tuple(want)}:
            return LINKS_MSG_DECLARED % {'name': spec.get('name') or addon_id}
        return None


    def syncAll(self, force_scope=None):
        """
        Sync every enabled import; cascade-allocate; merge into channels.json
        and push to in-memory M3U/XMLTV.

        Requires self.channels (writable), self.m3u, self.xmltv to be set.
        Builder.buildChannels (step 3 hook) is the canonical caller — it
        holds the build lock so concurrent operator edits via Channel
        Manager are safely merged via setChannels' merge-on-write.

        imports.27: `force_scope` controls per-import gate bypass:
          - None (default) — no force; every import honors its
            refresh_interval_min gate. Used by natural daemon cycles and
            by any caller that doesn't want to bypass (Builder step-3
            hook, tests).
          - 'all' — bypass the gate for every import in this cycle. Used
            by global kicks (batch operator edits, disable, cleanup, the
            'Refresh all' button when no specific id is targeted).
          - '<import_id>' — bypass the gate ONLY for the specified import;
            others still honor their interval. Used by single-import kicks
            (Renumber, Orphans, Refresh on a single import row).
          - '<unknown_id>' — no match; all imports gate normally. A debug
            log line surfaces typos.

        The kick value written to chkImports.kick (server.py:982/1022/
        1227/1299/1442/1472 + utilities.py:164) is the source of this
        parameter — the daemon reads the value verbatim and threads it
        through chkImports → syncAll without interpretation.

        Pre-imports.27 this was a boolean `force=False/True`; the rename
        carries scope information so a kick targeting one import doesn't
        force-refresh the unrelated others. See plan at
        /home/madalone/.claude/plans/dig-into-c-do-typed-kettle.md.

        imports.69: the results are saved by ONE commit,
        self.channels.commitSync (the import entries' sync fields as a change
        list onto channels.json as it is then, plus the channel records), so
        a Save, Add, Delete or Orphans made while the sync runs is kept. An
        import whose settings changed since its last sync (config_key) is
        synced in this cycle whatever its gates say.

        Returns dict {import_id: per-import-result}.
        """
        if self.channels is None:
            raise RuntimeError('syncAll() requires self.channels to be set')

        imports = list(self.channels.getImports() or [])
        if not imports:
            self.log('syncAll, no imports configured; skipping')
            return {}

        # imports.69: what this sync read, per import (deep copies, as the
        # entries are the store's own dicts). The commit applies exactly the
        # change between this copy and each result (importcfg_helpers.
        # sync_delta) onto the entry as it is on disk then, never the whole
        # result, which carries the settings and tombstones as they were here.
        start_by_id = {ic['id']: copy.deepcopy(ic) for ic in imports if isinstance(ic, dict) and ic.get('id')}

        # imports.27: surface typos in force_scope (debug-only). If the
        # operator's kick value doesn't match 'all' OR any known import
        # id, the gate falls through to normal gating (no bypass) — the
        # operator sees "Refresh did nothing" which is the same UX as a
        # deferred kick. The debug log line makes the typo visible without
        # spamming for the common cases (None, 'all', valid id).
        # imports.56: RENDER_ONLY_KICK is a deliberate no-bypass value, not a typo.
        if force_scope is not None and force_scope not in ('all', RENDER_ONLY_KICK):
            known_ids = {imp.get('id') for imp in imports if imp.get('id')}
            if force_scope not in known_ids:
                self.log("syncAll, force_scope=%r doesn't match any known import id (typo? known: %s)"
                         % (force_scope, sorted(known_ids)), level=xbmc.LOGDEBUG)

        # Snapshot existing channels (operator-built + imported)
        existing_channels = list(self.channels.getChannels() or [])

        # Drive syncOne in priority order (top of list = highest priority)
        per_import_results = {}
        parsed_imports_for_cascade = []  # [(import_cfg, list_of_parsed_channels)]

        for import_cfg in imports:
            iid = import_cfg.get('id') or ''
            if self.service is not None and hasattr(self.service, '_interrupt'):
                if self.service._interrupt():
                    self.log('syncAll, interrupted before [%s]' % iid)
                    break

            # imports.25 / .27: per-import refresh-interval gate. Honors the
            # operator-facing `refresh_interval_min` setting (saved by the
            # dashboard's edit-import dialog at manager.html:1678). Skip this
            # import when: enabled AND no force-bypass active AND interval > 0
            # AND less time elapsed than interval.
            #
            # imports.27: `force_active` is per-import — set True only when
            # `force_scope` matches THIS import's id specifically OR is 'all'.
            # Pre-imports.27 a single-import kick (Renumber on import X, say)
            # would bypass the gate for EVERY import in the cycle because
            # `force` was a boolean stripped of scope info. The kick property
            # already encoded scope (see server.py:1227/1299/1472 + the 4
            # 'all' setters); now the gate uses it. Disabled imports fall
            # through to syncOne, which already returns status='disabled'
            # (preserves existing per_import_results shape for that case).
            #
            # Operator edits to imported channels (rename / logo / number /
            # enabled / favorite / group / tombstoned) are preserved across
            # syncs by the existing imports.20 `operator_overrides` mechanism
            # in `_mergeChannel` and `cascadeAllocate` — imports.25 + .27 do
            # NOT weaken that guarantee. Skipped imports trivially preserve
            # (no merge runs); non-skipped imports go through the same merge
            # that respected operator_overrides before. See plan in
            # /home/madalone/.claude/plans/dig-into-c-do-typed-kettle.md.
            force_active = (force_scope == 'all'
                            or (force_scope is not None
                                and force_scope == import_cfg.get('id')))

            # imports.69: the settings gate (Kubernetes generation /
            # observedGeneration). A dashboard change stores
            # config_key='pending', and every sync attempt records the
            # fingerprint of the settings it acted on, so an import whose
            # settings changed since its last attempt -- a Save, also one made
            # while a sync ran, or a hand edit -- syncs now, with one full read
            # of its playlist. It goes through the force path, so the abandon
            # check and the interval and retry gates don't hold it (like a
            # Refresh). A missing config_key (entries from before imports.69)
            # counts as unchanged; a switched-off import is not forced
            # (syncOne returns 'disabled' for it anyway).
            cfg_changed = bool(import_cfg.get('enabled', True)) and importcfg_helpers.config_changed(import_cfg)
            if cfg_changed and not force_active:
                force_active = True
                self.log('[%s] syncAll, settings changed since its last sync -- syncing it now' % (iid,),
                         level=xbmc.LOGINFO)

            # imports.43: disk-presence check. When the configured scope
            # detects missing/stub on-disk M3U or per-import EPG cache,
            # force-sync THIS import regardless of refresh_interval_min.
            # Integrates with the existing force_active mechanism so all
            # downstream gate logic (abandon check at the next block, normal
            # gate at the elapsed-time check) automatically honors disk-
            # missing as a force-sync trigger — zero new branching needed.
            # Skipped when force_active is already True (no point double-
            # forcing) or when the import is disabled / lacks an id (the
            # next block handles that). Setting reads use the same defensive
            # try/except + fallback pattern as the imports.28 retry curve
            # reads two blocks down — settings.xml edge cases (corrupt,
            # missing) don't break the gate.
            if not force_active and import_cfg.get('enabled', True) and import_cfg.get('id'):
                try:
                    scope = DISK_PRESENCE_SCOPE_BY_CODE.get(
                        int(SETTINGS.getSettingInt('Imports_Disk_Presence_Scope') or 0),
                        'main_m3u',
                    )
                except Exception:
                    scope = 'main_m3u'
                if _isDiskMissing(import_cfg.get('id'), scope):
                    force_active = True
                    self.log('[%s] syncAll, disk-presence: forcing sync (scope=%s, file missing/stub)'
                             % (import_cfg.get('id'), scope), level=xbmc.LOGINFO)

            # imports.56: guide self-heal — an import whose guide is missing
            # from the guide data being written gets synced now rather than
            # after refresh_interval_min. With syncOne's cache fallback this
            # restores the guide even while the source is unreachable.
            if not force_active and self._guideNeedsSelfHeal(import_cfg, existing_channels):
                force_active = True
                self.log('[%s] syncAll, guide missing from %s — forcing a sync (self-heal)'
                         % (iid, XMLTVFLE), level=xbmc.LOGWARNING)

            # imports.59 (S17): the playlist add-on wrote a new guide export
            # (the replay links) since the one last read -- sync now, so the
            # new links reach the guide within the hour instead of after
            # refresh_interval_min (10 h on madteevee). Same force pattern as
            # the two checks above, so the abandon check and the failure
            # backoff below still rule a failing import.
            if (not force_active and import_cfg.get('enabled', True)
                    and import_cfg.get('last_status') != 'failed'
                    and self._linksChanged(import_cfg, existing_channels)):
                force_active = True
                self.log('[%s] syncAll, new replay links file — forcing a sync' % (iid,),
                         level=xbmc.LOGINFO)

            # imports.70 (c): the replay-links file is too old to trust
            # (replay_helpers.LINKS_STALE_AFTER_S): sync when it became stale
            # after this import's last sync, so upcoming shows follow the guide
            # at the next imports cycle instead of after refresh_interval_min,
            # and again at every cycle while it stays stale once the last sync
            # is LINKS_STALE_RESYNC_SECS old (the user's choice of 2026-11-14:
            # about hourly with a cycle of an hour or less), so each channel's
            # replay on/off (S9) follows the show on air. Same force pattern as
            # S17: never for a switched-off or failing import, so the abandon
            # check and the failure backoff below still rule those.
            if (not force_active and import_cfg.get('enabled', True)
                    and import_cfg.get('last_status') != 'failed'
                    and self._linksWentStale(import_cfg, existing_channels)):
                force_active = True
                self.log('[%s] syncAll, replay links file is stale — forcing a sync' % (iid,),
                         level=xbmc.LOGINFO)

            if (import_cfg.get('enabled', True)
                and import_cfg.get('id')):
                try:
                    rim = int(import_cfg.get('refresh_interval_min') or 0)
                except (TypeError, ValueError):
                    rim = 0
                try:
                    last = int(import_cfg.get('last_sync_at') or 0)
                except (TypeError, ValueError):
                    last = 0

                # imports.28: failure-aware retry / abandon gating.
                #
                # Read curve + abandon-hours from settings ONCE per cycle (cheap
                # cached reads, but doing it inside the loop keeps the test
                # mocks deterministic). `disabled` curve preserves pre-.28
                # behavior exactly — gate fires at rim*60 regardless of
                # last_status. Abandon-hours=0 means "never abandon" (default).
                # imports.56: no `or 1` — it turned the 'Disabled' option
                # (code 0) into 'aggressive', so Disabled never took effect.
                # A failed read still falls back to 'aggressive' (the default).
                try:
                    curve = RETRY_CURVE_BY_CODE.get(
                        int(SETTINGS.getSettingInt('Imports_Failure_Retry_Curve')),
                        'aggressive',
                    )
                except Exception:
                    curve = 'aggressive'
                try:
                    abandon_hours = int(SETTINGS.getSettingInt('Imports_Failure_Abandon_Hours') or 0)
                except Exception:
                    abandon_hours = 0

                try:
                    fail_count = int(import_cfg.get('fail_count') or 0)
                except (TypeError, ValueError):
                    fail_count = 0
                try:
                    failed_since = int(import_cfg.get('failed_since') or 0) or None
                except (TypeError, ValueError):
                    failed_since = None
                last_status = import_cfg.get('last_status')
                # imports.56: consecutive guide-only failures (see syncOne).
                try:
                    epg_fail_count = int(import_cfg.get('epg_fail_count') or 0)
                except (TypeError, ValueError):
                    epg_fail_count = 0

                now = int(time.time())

                # 1) Abandon check FIRST (precedes normal gate). When an import
                # has been failing for >= abandon_hours, status flips to
                # 'abandoned' and the gate skips unconditionally — operator
                # must hit Refresh (force_scope match) to wake it back up.
                # Bypass-on-force keeps a manual Refresh actually meaningful;
                # without it, abandon would be a one-way trap.
                is_abandoned = (
                    abandon_hours > 0
                    and failed_since
                    and last_status == 'failed'
                    and (now - failed_since) >= abandon_hours * 3600
                )
                if is_abandoned and not force_active:
                    self.log('[%s] syncAll, abandoned: failing %ds >= %dh (force Refresh to retry)'
                             % (iid, now - failed_since, abandon_hours), level=xbmc.LOGINFO)
                    # 'abandoned' is a DERIVED status emitted in this result
                    # only. We deliberately do NOT write last_status='abandoned'
                    # into updated_cfg — storage keeps last_status='failed'
                    # (which is still the true storage state), and the next
                    # cycle's abandon check re-evaluates from failed_since +
                    # the current Imports_Failure_Abandon_Hours setting.
                    # server.py mirrors this derivation when serving the
                    # imports list so the dashboard sees the abandoned state.
                    per_import_results[iid] = {
                        'import_id'  : iid,
                        'status'     : 'abandoned',
                        'updated_cfg': dict(import_cfg),
                        'parsed'     : [],
                        'new'        : [],
                        'refreshed'  : [],
                        'orphans'    : [],
                        'epg_pairs' : [],
                        'epg_id_map': {},
                        'error'      : None,
                    }
                    continue

                # 2) Normal gate (with failure-aware effective interval).
                # When the import is in a consecutive-failure run, derive a
                # shorter retry interval from the configured curve. Capped at
                # rim*60 so operator's ceiling is honored.
                if not force_active and rim > 0 and last > 0:
                    effective_gate_sec = rim * 60
                    if last_status == 'failed' and fail_count > 0:
                        effective_gate_sec = computeRetryDelay(curve, fail_count, rim * 60)
                    elif epg_fail_count > 0:
                        # imports.56: the guide failed last time while the
                        # channel list was fine — retry on the same curve.
                        effective_gate_sec = computeRetryDelay(curve, epg_fail_count, rim * 60)
                    elapsed = now - last
                    # Defensive: 0 <= elapsed guards against negative values from
                    # clock skew (NTP step backwards, system time set manually,
                    # etc.) — never block a sync because of a misbehaving clock.
                    if 0 <= elapsed < effective_gate_sec:
                        if last_status == 'failed' and fail_count > 0:
                            self.log('[%s] syncAll, retry gate: skipped (elapsed %ds < %ds backoff, fail_count=%d, curve=%s)'
                                     % (iid, elapsed, effective_gate_sec, fail_count, curve), level=xbmc.LOGINFO)
                        elif epg_fail_count > 0:
                            self.log('[%s] syncAll, guide retry gate: skipped (elapsed %ds < %ds backoff, epg_fail_count=%d, curve=%s)'
                                     % (iid, elapsed, effective_gate_sec, epg_fail_count, curve), level=xbmc.LOGINFO)
                        else:
                            self.log('[%s] syncAll, refresh-interval gate: skipped (elapsed %ds < %dm)'
                                     % (iid, elapsed, rim), level=xbmc.LOGINFO)
                        per_import_results[iid] = {
                            'import_id'  : iid,
                            'status'     : 'skipped',
                            'updated_cfg': dict(import_cfg),
                            'parsed'     : [],
                            'new'        : [],
                            'refreshed'  : [],
                            'orphans'    : [],
                            'epg_pairs' : [],
                            'epg_id_map': {},
                            'error'      : None,
                        }
                        continue

            res = self.syncOne(import_cfg, existing_channels, full_read=cfg_changed)
            # imports.69: record which settings this attempt acted on, for
            # every outcome that reached syncOne (ok, unchanged, failed,
            # warning, disabled): a failing source then keeps its normal
            # backoff, and a switch back on is seen. A Save made while this
            # sync runs leaves a mismatch, so the next cycle syncs again. A
            # gate-skipped or abandoned result never gets here, so the commit
            # keeps a 'pending' a Save stored meanwhile.
            res['updated_cfg']['config_key'] = importcfg_helpers.config_fingerprint(import_cfg)

            # imports.28: maintain fail_count + failed_since on the resulting
            # updated_cfg. Centralized here (not in syncOne) so all status
            # branches converge on one tracking rule. `warning` (empty M3U
            # with channels-kept) deliberately doesn't touch the fields —
            # operator's channels are intact and we want normal cadence to
            # pick up fresh content. Only `failed` (hard fetch/parse error)
            # triggers backoff. imports.70: syncOne now returns 'warning' for
            # that case; it returned 'failed', so an empty playlist counted.
            new_status = res.get('status')
            if new_status in ('ok', 'unchanged'):
                res['updated_cfg']['fail_count']   = 0
                res['updated_cfg']['failed_since'] = None
            elif new_status == 'failed':
                try:
                    prev_fc = int(import_cfg.get('fail_count') or 0)
                except (TypeError, ValueError):
                    prev_fc = 0
                res['updated_cfg']['fail_count'] = min(prev_fc + 1, FAIL_COUNT_CAP)
                if not import_cfg.get('failed_since'):
                    res['updated_cfg']['failed_since'] = int(time.time())
                else:
                    # Preserve the original failure-run start (don't reset on
                    # subsequent failures). The agent-validated rule: the
                    # timer reflects how long the SOURCE has been broken,
                    # not how recently a retry attempt failed. Operator
                    # force-Refresh that fails again does NOT restart the
                    # abandon clock.
                    res['updated_cfg']['failed_since'] = int(import_cfg.get('failed_since'))

            per_import_results[iid] = res
            if res['status'] in ('ok', 'unchanged'):
                parsed_imports_for_cascade.append((res['updated_cfg'], res['parsed']))

        # Cascade-allocate channel numbers across all parsed imports
        # plus existing channels (for hard pins + sticky)
        allocations = self.cascadeAllocate(parsed_imports_for_cascade, existing_channels)

        # madteevee (imports fork): per-import-config lookup so the all_imported_now
        # loop below has the right import_cfg for each iid. Previously the loop
        # referenced `import_cfg` which dangled from the cascade-build loop above
        # (latent bug — line 520 always pulled the LAST import's name for every
        # channel's group fallback).
        import_cfg_by_id = {ic.get('id'): ic for ic in (imports or []) if ic.get('id')}

        # madteevee (imports fork): catchup attribute derivation per import.
        # Operator can set `catchup_mode` + `catchup_query_format` + `catchup_days`
        # per import in channels.json's `imports` array (via the import-config
        # edit endpoint). When unset, a host listed in KNOWN_CATCHUP_DEFAULTS
        # supplies them; any other channel keeps the catch-up its playlist
        # declares (parseM3U stores it, applyRefresh refreshes it). The data
        # flow is: import config → _resolveCatchup → per-channel `catchup` +
        # `catchup-source` fields, which get emitted into pseudotv.m3u and
        # pvr.iptvsimple uses them to offer "Play programme" + invoke the
        # source plugin directly. Live playback still routes through
        # pseudotv.imports' plugin handler; only catchup bypasses us.
        KNOWN_CATCHUP_DEFAULTS = {
            # source_url prefix → (catchup_mode, catchup_query_format, catchup_days)
            # for a host whose playlist doesn't declare usable catch-up itself.
            #
            # imports.59: the 'plugin://plugin.video.movistarplus/' row
            # ('default', '&start_time={utc}&end_time={utcend}', 5) is gone.
            # Movistar+ 0.11.9 declares catchup="default"
            # catchup-source="{catchup-id}" catchup-days="7" on every playlist
            # line. In default mode IPTV Simple uses a non-empty catchup-source
            # as the full replay address (its README: "Use catchup source as
            # the full catchup URL, if there is no catchup source use Append
            # mode") -- here each show's own link, the guide's catchup-id. The
            # row blanked that source, so IPTV Simple appended the instance's
            # query format to the live address instead and every past show
            # played live. Movistar+ channels now keep the playlist's values.
        }
        def _resolveCatchup(import_cfg, source_url):
            """Return (catchup_mode, catchup_source_url, catchup_days) for a single channel.
            Empty mode means the channel has no catchup; caller should emit catchup="".
            """
            cfg_mode = import_cfg.get('catchup_mode')
            cfg_qf   = import_cfg.get('catchup_query_format')
            cfg_days = import_cfg.get('catchup_days')
            if cfg_mode is None or cfg_qf is None or cfg_days is None:
                for prefix, (dm, dqf, dd) in KNOWN_CATCHUP_DEFAULTS.items():
                    if (source_url or '').startswith(prefix):
                        if cfg_mode is None: cfg_mode = dm
                        if cfg_qf   is None: cfg_qf   = dqf
                        if cfg_days is None: cfg_days = dd
                        break
            cfg_mode = cfg_mode or ''
            cfg_qf   = cfg_qf or ''
            if not cfg_mode or not cfg_qf or not source_url:
                return ('', '', cfg_days or 0)
            return (cfg_mode, source_url + cfg_qf, cfg_days or 0)

        # Merge allocations into channels list:
        #  - For new channels: assign number + assigned_number, type='import', enabled=True, etc.
        #  - For refreshed channels: update assigned_number; if not operator-pinned, sync number too
        #  - For orphans: keep in list with is_orphan=True
        all_imported_now = {}  # {channel_id: full channel record}
        for iid, res in per_import_results.items():
            import_cfg = import_cfg_by_id.get(iid) or {}
            for new in res['new']:
                cid = new['id']
                n   = allocations.get(cid)
                if n is None:
                    new['unallocated'] = True
                    new['enabled']     = False
                else:
                    new['number']           = n
                    new['assigned_number']  = n
                    new['enabled']          = True
                    new['unallocated']      = False
                new['type']                = 'import'
                new['changed']             = True
                new['favorite']            = new.get('favorite', False)
                new['operator_overrides']  = []
                new['is_orphan']           = False
                new.setdefault('logo', '')
                new['url']                 = new.get('source_url', '')
                # Preserve group as a list (already from parser)
                new['group']               = new.get('group') or [import_cfg.get('name', iid) or iid]
                # Apply catchup attrs (per-import config + known-host defaults)
                _cm, _cs, _cd = _resolveCatchup(import_cfg, new.get('source_url', ''))
                if _cm:
                    new['catchup']        = _cm
                    # madteevee (imports fork): for a configured "default"
                    # catchup mode, CLEAR catchup-source. In default mode
                    # pvr.iptvsimple uses a non-empty catchup-source as the
                    # full replay address; with an empty one it appends the
                    # instance-level catchupQueryFormat (with {utc}/{utcend}
                    # substituted from the clicked guide entry) to the
                    # channel URL -- what a configured query format relies
                    # on. (imports.59: the earlier note here, "any non-empty
                    # catchup-source means VOD mode", was wrong.) For
                    # "vod"/"shift"/"fs"/"xc" modes we still emit the
                    # per-channel catchup-source so iptvsimple uses it directly.
                    if _cm == 'default':
                        new['catchup-source'] = ''
                    else:
                        new['catchup-source'] = _cs
                    if _cd: new['catchup-days'] = str(_cd)
                # Persist into per-channel record
                all_imported_now[cid] = new
            for existing, _parsed in res['refreshed']:
                cid = existing['id']
                n   = allocations.get(cid)
                if n is not None:
                    existing['assigned_number'] = n
                    if 'number' not in (existing.get('operator_overrides') or []):
                        existing['number'] = n
                # Keep URL synced from source unless operator overrode it
                if 'url' not in (existing.get('operator_overrides') or []):
                    existing['url'] = existing.get('source_url') or existing.get('url', '')
                # Refresh catchup attrs unless operator overrode them
                overrides = existing.get('operator_overrides') or []
                _cm, _cs, _cd = _resolveCatchup(import_cfg, existing.get('source_url', ''))
                if _cm and 'catchup' not in overrides:
                    existing['catchup']        = _cm
                    # Same default-mode catchup-source clearing as the
                    # new-channel arm (configured mode only; a playlist's own
                    # catch-up, refreshed by applyRefresh, is left as declared)
                    if _cm == 'default':
                        existing['catchup-source'] = ''
                    else:
                        existing['catchup-source'] = _cs
                    if _cd: existing['catchup-days'] = str(_cd)
                all_imported_now[cid] = existing
            for orphan in res['orphans']:
                cid = orphan['id']
                # Preserve orphan record; cascade may have assigned it a bucket
                # number (9000+) if disabled — apply that here so UI sort places
                # disabled channels at the bottom.
                if cid not in all_imported_now:
                    orphan['is_orphan'] = True
                    n = allocations.get(cid)
                    if isinstance(n, int):
                        orphan['assigned_number'] = n
                        if 'number' not in (orphan.get('operator_overrides') or []):
                            orphan['number'] = n
                    all_imported_now[cid] = orphan

        # imports.59 (S10.2/S12): replay links. An import whose playlist is a
        # known exporter's own file (replay_helpers.exporter_for) and whose
        # live channels -- as just merged, every catch-up setting applied --
        # use link-based replay reads that add-on's guide export: in full on
        # every sync of the import, through the same safe local read as the
        # playlist. The XML branch below merges the links. Read before the
        # commit (imports.69: commitSync; setImports before), so
        # links_mtime_ns and any dashboard message are saved with this sync's
        # results. Without guide data (self.xmltv) there is
        # nothing to merge into, so the file isn't read (or recorded) at
        # all. A stored links_mtime_ns means the file was read for a merge;
        # if that merge fails, its links wait for the import's next sync or
        # a new export (see _readLinks).
        for iid, res in per_import_results.items():
            if self.xmltv is None or res.get('status') not in ('ok', 'unchanged'):
                continue
            exporter = replay_helpers.exporter_for(import_cfg_by_id.get(iid))
            if exporter is None:
                continue
            records = [c for c in all_imported_now.values() if c.get('import_source') == iid]
            link_days = replay_helpers.link_replay_days(records)
            if not link_days:
                continue
            link_records = [c for c in records if c.get('id') in link_days]
            tvg_ids = {c.get('epg_id') for c in link_records if c.get('epg_id')}
            try:
                res['links'] = self._readLinks(iid, exporter, res['updated_cfg'], tvg_ids)
            except Exception as e:
                # Still merge, with no new links: the merge is what keeps the
                # linked history (the fresh path's prune would drop it).
                # imports.70: 'retry' -- no listing this sync, so no
                # stale-export guard either (_mergeReplayLinks).
                self.log('[%s] syncAll, replay links read failed: %s' % (iid, e), level=xbmc.LOGERROR)
                res['links'] = {'pairs': [], 'warning': None, 'retry': True}
            warning = res['links'].get('warning') or self._declaredReplayWarning(exporter, link_records)
            # Shown only while there is no other error to show; last_status
            # and the failure counters stay as they are (a 'warning' status
            # would drop the import from allocation).
            if warning and not res['updated_cfg'].get('last_error'):
                res['updated_cfg']['last_error'] = warning

        # Build merged channel list: keep all non-import channels as-is,
        # replace/add imported channels.
        merged_channels = [c for c in existing_channels if c.get('type') != 'import']
        merged_channels.extend(all_imported_now.values())

        # madteevee (imports fork): union of all tombstones across all imports.
        # These are channel ids the operator explicitly tombstoned (via the
        # "🗑 Orphans" endpoint). Without passing them as `deleted_ids` to
        # setChannels, the merge-on-write preserve loop resurrected them from
        # disk on every syncAll cycle — operator's delete looked like a no-op.
        # imports.69: commitSync deletes every tombstone on disk at commit
        # time, and only those, so an id a newer overlapping sync re-discovered
        # meanwhile is not deleted (importcfg_helpers.plan_sync_commit).
        deleted_ids = set()
        for ic in imports:
            for cid in (ic.get('tombstones') or []):
                deleted_ids.add(cid)

        # Persist channels.json (merge-on-write protects operator edits)
        modified_ids = set(all_imported_now.keys())
        # imports.69: ONE commit for the whole sync (before: setChannels, then
        # setImports with the whole import list as this sync read it -- which
        # undid a Save made meanwhile and wiped its last-sync time). Under the
        # channels.json lock, on the file as it is now, commitSync applies
        # each import's own change list of sync fields (gate-skipped and
        # abandoned results apply nothing), drops the results of an import
        # deleted, moved or re-synced by a newer sync meanwhile, takes every
        # tombstone on disk as a delete (an Orphans made meanwhile stays) and
        # merges the channel records. It is the only persistence path; the
        # tests' in-memory stores get the same planner from a shared helper.
        # A failed commit never stops this cycle's guide and playlist
        # rendering (as a failed setImports didn't).
        # One ERROR line per failed commit: an exception is logged inside its
        # except (so the line carries its traceback), any other outcome below.
        raised = False
        try:
            saved = self.channels.commitSync(start_by_id, per_import_results, merged_channels,
                                             modified_ids, deleted_ids)
        except Exception as e:
            raised, saved = True, {'status': 'failed'}
            self.log("syncAll, saving this sync's results raised: %s -- nothing was saved; the next sync redoes them"
                     % (e,), level=xbmc.LOGERROR)
        if not isinstance(saved, dict):
            saved = {'status': 'failed'}
        written = saved.get('status') == 'written'
        if not written and not raised:
            self.log("syncAll, this sync's results were not saved (%s); the next sync redoes them"
                     % (saved.get('status'),), level=xbmc.LOGERROR)
        # imports.69: the PVR-refresh signal below counts only deletes that
        # removed a record in this write (before: any tombstone at all, so a
        # kept tombstone signalled every cycle).
        applied_deleted_ids = set(saved.get('applied_deletes') or ()) if written else set()
        for iid in sorted(saved.get('gone') or (), key=str):
            self.log('syncAll, [%s] was deleted during this sync -- its results are dropped' % (iid,),
                     level=xbmc.LOGINFO)
        for iid in sorted(saved.get('playlist_moved') or (), key=str):
            self.log('syncAll, [%s] playlist address changed during this sync -- its channel changes are dropped; '
                     'the next sync reads the new address' % (iid,), level=xbmc.LOGINFO)
        for iid in sorted(saved.get('superseded') or (), key=str):
            self.log('syncAll, [%s] a newer sync saved this import while this one ran -- its older results '
                     'are dropped' % (iid,), level=xbmc.LOGINFO)
        for iid in sorted(saved.get('guide_moved') or (), key=str):
            self.log('syncAll, [%s] guide address changed during this sync -- its guide results are dropped; '
                     'the next sync downloads the new address' % (iid,), level=xbmc.LOGINFO)
        if written:
            for iid, ids in sorted((saved.get('kept') or {}).items(), key=lambda kv: str(kv[0])):
                self.log('syncAll, [%s] re-discovered %d deleted channel(s): %s' % (iid, len(ids), sorted(ids)),
                         level=xbmc.LOGINFO)
        # imports.69: never publish what the commit dropped. Records of an
        # import deleted, moved or superseded during the sync, and dropped
        # re-discoveries, are not pushed to the playlist or the guide; an
        # empty epg_id_map makes the XML branch keep that import's previous
        # guide (`if not id_map: continue`), also when only its guide address
        # moved (its download describes the old address).
        drop_imports = set(saved.get('drop_imports') or ())
        dropped_ids = set(saved.get('dropped_ids') or ())
        if drop_imports or dropped_ids:
            for cid in [cid for cid, ch in all_imported_now.items()
                        if cid in dropped_ids or ch.get('import_source') in drop_imports]:
                del all_imported_now[cid]
        for iid in drop_imports.union(saved.get('guide_moved') or ()):
            dropped_res = per_import_results.get(iid)
            if dropped_res is not None:
                dropped_res['epg_id_map'] = {}
                dropped_res['epg_pairs'] = []

        # Per-channel logo cache (Imports_Cache_Logos toggle).
        # Publishes the cached copy of each channel's remote logo
        # (`_portableLogoURL`) so IPTV Simple/Kodi PVR loads logos from us
        # instead of re-fetching from upstream every refresh. Walk runs
        # BEFORE the M3U push and the XML branch below so both publish the
        # cached copy. Failures fall back to the original URL — no
        # regression vs the no-cache path.
        #
        # imports.58: the published address goes into `published_logos`, not
        # into the channel record. Pre-imports.58 this step overwrote
        # ch['logo'] in place — the same dicts the channels store holds — so
        # the addon's own /images/ link could be saved into channels.json
        # (seen live on five records). For a logo the operator set, that
        # would have replaced their address with a link to the old picture
        # for good. Records now keep only what the operator or the source
        # chose.
        published_logos = {}  # {channel_id: address to publish this cycle}
        cache_logos = False
        try:
            cache_logos = SETTINGS.getSettingBool('Imports_Cache_Logos')
        except Exception:
            cache_logos = False
        if cache_logos:
            try:
                refresh_mode = int(SETTINGS.getSettingInt('Imports_Logo_Refresh') or 0)
            except Exception:
                refresh_mode = 0
            validators = self._logoLoadValidators()
            cached_count = 0
            for ch in all_imported_now.values():
                if ch.get('is_orphan') or ch.get('unallocated') or not ch.get('enabled', True):
                    continue
                cid = ch.get('id')
                src = ch.get('logo') or ''
                if not cid or not src:
                    continue
                local = self._cacheLogo(cid, src, refresh_mode, validators)
                if local:
                    # imports.44: portable URL wrap — see _portableLogoURL.
                    published_logos[cid] = self._portableLogoURL(local)
                    cached_count += 1
            self._logoSaveValidators(validators)
            # Evict logos for channels no longer present
            # imports.56: "present" means every channel known at the start of
            # this cycle plus anything it added — not just the channels synced
            # in it. A gated (skipped) import's channels are absent from
            # all_imported_now, so every routine cycle used to evict their
            # cached logos and the next full sync re-downloaded them: the
            # playlist's /images/ links pointed at missing files most of the
            # time. Channels removed from channels.json still get evicted.
            present_ids = {ch.get('id') for ch in existing_channels if ch.get('id')}
            present_ids |= {ch.get('id') for ch in all_imported_now.values() if ch.get('id')}
            self._evictOrphanLogos(present_ids)
            self.log('syncAll, logo cache: publishing %d channel logos from the cache (mode=%d)'
                     % (cached_count, refresh_mode), level=xbmc.LOGINFO)

        # Push imported channels into in-memory XMLTV (the M3U push follows
        # the XML branch -- imports.59, see there)
        if self.xmltv is not None:
            # Per-import EPG: rewrite source-side IDs to namespaced before adding.
            # Match strategy mirrors IPTV Simple's documented chain:
            #   1. XMLTV `id` attr      vs M3U `tvg-id`            (exact)
            #   2. XMLTV `id` attr      vs M3U `tvg-name` / name   (normalized fallback)
            #   3. XMLTV `display-name` vs M3U `tvg-name` / name   (normalized fallback)
            # Normalization: lowercase + strip ' hd'/' sd' suffix + collapse whitespace.
            # Without this fallback, EPG sources that use human-readable display names
            # as channel ids (davidmuma EPG_dobleM, many regional EPGs) silently fail
            # to match M3U sources that use short codes (MovistarPlus, IPTV-org).
            def _norm(s):
                if not s: return ''
                s = s.lower().strip()
                # strip common quality suffixes
                for sfx in (' hd', ' sd', ' fhd', ' uhd', ' 4k'):
                    if s.endswith(sfx): s = s[:-len(sfx)]
                # collapse whitespace
                s = re.sub(r'\s+', ' ', s).strip()
                return s

            # madteevee (imports fork): build the SAME enabled-channel filter
            # the M3U branch applies at line 630, but apply it on the XML side
            # too. Without this, the XML branch happily appends programmes for
            # disabled/orphan/unallocated channels — they go into pseudotv.xml
            # and stay there forever (cleanSelf only drops channels for imports
            # that are entirely removed, not channels disabled within a still-
            # registered import). Empirical measurement 2026-05-11: 22 MB of
            # the 85 MB pseudotv.xml (26%) was programme data for 25 disabled
            # movistar+ channels. pvr.iptvsimple parses + indexes the whole
            # file on every reload, so this is real I/O + memory cost. Also,
            # if a disabled channel later gets re-enabled, its stale EPG (now
            # hours-to-days old) would be served from disk until the next
            # syncAll refreshes it.
            enabled_ids = {
                ch.get('id') for ch in all_imported_now.values()
                if ch.get('id')
                and ch.get('enabled', True)
                and not ch.get('is_orphan')
                and not ch.get('unallocated')
            }

            def _pruneSlice(suffix, dead_only):
                """Remove this import's entries (ids ending in `suffix`) from
                XMLTVDATA. dead_only=True removes only entries whose channel
                is no longer live (not in enabled_ids) and keeps the rest."""
                xtv_c = self.xmltv.XMLTVDATA.setdefault('channels', [])
                xtv_p = self.xmltv.XMLTVDATA.setdefault('programmes', [])
                def _drop(cid):
                    return (isinstance(cid, str) and cid.endswith(suffix)
                            and (not dead_only or cid not in enabled_ids))
                n_c, n_p = len(xtv_c), len(xtv_p)
                xtv_c[:] = [c for c in xtv_c if not _drop(c.get('id'))]
                xtv_p[:] = [p for p in xtv_p if not _drop(p.get('channel'))]
                return n_c - len(xtv_c), n_p - len(xtv_p)

            def _applyGuideIcons(suffix):
                """imports.58: apply the `_guideIcon` rule to this import's
                entries that are kept from a previous cycle (guide
                unavailable, or nothing matched), so a logo set while the
                guide is down still reaches Kodi."""
                for c in self.xmltv.XMLTVDATA.setdefault('channels', []):
                    cid = c.get('id')
                    if isinstance(cid, str) and cid.endswith(suffix):
                        icon = self._guideIcon(all_imported_now.get(cid), published_logos.get(cid))
                        if icon:
                            c['icon'] = [{'src': icon}]

            # imports.66: show pictures. The check results are loaded once per
            # sync; the fresh-guide path in the loop below adds new ones and
            # the choke point after the loop applies them. records_by_id is
            # every imported channel's record: the ones known when this sync
            # started (imports skipped by their refresh interval included),
            # overlaid by the records this sync merged.
            verdicts = loadPictureVerdicts()
            verdicts_changed = False
            pic_now = int(time.time())
            records_by_id = {c.get('id'): c for c in existing_channels
                             if c.get('type') == 'import' and c.get('id')}
            records_by_id.update(all_imported_now)

            for iid, res in per_import_results.items():
                id_map = res['epg_id_map']
                if not id_map:
                    continue
                import_ns_suffix = '@%s' % iid

                # imports.56: this cycle produced no usable guide and there is
                # no cached copy (see syncOne) — keep this import's previous
                # guide instead of pruning it to nothing. Entries for channels
                # that are no longer live still go.
                if res.get('epg_keep_previous'):
                    pruned_chan, pruned_prog = _pruneSlice(import_ns_suffix, dead_only=True)
                    # imports.59 (S10.3): this sync's replay links still reach
                    # the kept guide (it serves as the details source).
                    self._mergeLinksIntoKept(iid, res, all_imported_now, published_logos)
                    _applyGuideIcons(import_ns_suffix)
                    self.log('syncAll, [%s] guide unavailable (%s) — keeping the previous guide (dropped %d channels + %d programmes no longer live)'
                             % (iid, res.get('epg_error'), pruned_chan, pruned_prog), level=xbmc.LOGWARNING)
                    continue

                # Build per-import name_map for fallback. Look up by normalized
                # name → namespaced id. Includes both source name and tvg-id-as-name
                # since some imports (epg.best) use short codes for both.
                name_map = {}
                for ch in (res['parsed'] or []):
                    cid = ch.get('id')
                    if not cid: continue
                    for cand in (ch.get('name'), ch.get('epg_id')):
                        n = _norm(cand)
                        if n and n not in name_map:
                            name_map[n] = cid
                # imports.59 (S18): then each channel's playlist name
                # (`source_name`), for names no channel claimed above. On an
                # unchanged (304) sync `parsed` holds the stored records, whose
                # `name` is the operator's after a rename, so the channel lost
                # its guide wherever the guide's ids are display names
                # (davidmuma). A second pass keeps every match made today --
                # operator names and tvg-ids first -- and only fills gaps.
                for ch in (res['parsed'] or []):
                    cid = ch.get('id')
                    src_name = ch.get('source_name')
                    n = _norm(src_name) if isinstance(src_name, str) else ''
                    if cid and n and n not in name_map:
                        name_map[n] = cid
                self.log('syncAll, [%s] EPG matcher built id_map=%d name_map=%d (sample names: %s)'
                         % (iid, len(id_map), len(name_map), list(name_map.keys())[:5]),
                         level=xbmc.LOGINFO)

                def _match(src_id, item):
                    """Resolve namespaced id from source-side XMLTV id + element attrs."""
                    # 1. Exact tvg-id
                    if src_id in id_map: return id_map[src_id]
                    # 2. Normalized id-as-name
                    n = _norm(src_id)
                    if n in name_map: return name_map[n]
                    # 3. Normalized display-name (only available on `channel` elements;
                    #    elem_to_channel returns display-name as a list of (text, lang) tuples)
                    for dn in (item.get('display-name') or []):
                        text = dn[0] if isinstance(dn, (list, tuple)) and dn else dn
                        n = _norm(text)
                        if n in name_map: return name_map[n]
                    return None

                # Bypass XMLTVS.addChannel / addProgram (which expect PseudoTV's
                # internal scheduling format with categories/thumb/length etc.).
                # The xmltv.parseExternalSource yields XMLTV-format dicts —
                # the SAME shape XMLTVDATA stores natively (xmltvs.py:78-81 _save
                # passes them directly to xmltv.Writer.addChannel/addProgramme).
                # Direct append to XMLTVDATA preserves the format end-to-end.
                xtv_channels   = self.xmltv.XMLTVDATA.setdefault('channels', [])
                xtv_programmes = self.xmltv.XMLTVDATA.setdefault('programmes', [])

                # imports.56: match into fresh lists FIRST, decide what to do
                # with the existing slice afterwards. Pre-imports.56 the prune
                # ran before matching, so a cycle that matched nothing left
                # the import with no guide at all.
                new_chans, new_progs = [], []
                matched_chan = matched_prog = skipped = 0
                skipped_disabled = 0
                for kind, item in res['epg_pairs']:
                    if kind == 'channel':
                        src_id = item.get('id')
                        ns_id  = _match(src_id, item)
                        if not ns_id:
                            skipped += 1; continue
                        # madteevee: drop EPG for disabled/orphan/unallocated
                        # channels — symmetric with the M3U branch's delStation
                        # filter at line 630. Without this, pseudotv.xml carries
                        # ~26% bookkeeping bloat for channels the M3U never
                        # exposes (pvr.iptvsimple has nothing to match the EPG
                        # to). See measurement note in enabled_ids comment.
                        if ns_id not in enabled_ids:
                            skipped_disabled += 1; continue
                        item['id'] = ns_id
                        # Logo reach into XMLTV: Kodi's EPG-guide view loads
                        # icons from XMLTV separately from the M3U
                        # tvg-logo, and upstream URLs (e.g. Wikimedia)
                        # often fail under Kodi's default UA. imports.58:
                        # the rule lives in _guideIcon (operator-set logos
                        # always win; local logos as before).
                        icon = self._guideIcon(all_imported_now.get(ns_id), published_logos.get(ns_id))
                        if icon:
                            item['icon'] = [{'src': icon}]
                        new_chans.append(item)
                        matched_chan += 1
                    elif kind == 'programme':
                        src_id = item.get('channel')
                        ns_id  = _match(src_id, item)
                        if not ns_id:
                            skipped += 1; continue
                        # Same disabled-filter as the channel arm above
                        if ns_id not in enabled_ids:
                            skipped_disabled += 1; continue
                        item['channel'] = ns_id
                        new_progs.append(item)
                        matched_prog += 1
                self.log('syncAll, [%s] EPG match: channels=%d programmes=%d skipped=%d skipped-disabled=%d'
                         % (iid, matched_chan, matched_prog, skipped, skipped_disabled),
                         level=xbmc.LOGINFO)

                # imports.56: nothing matched — and not because the channels
                # are disabled, which must still prune — while the import does
                # have a guide source: keep the previous guide rather than
                # replacing it with nothing (e.g. the source briefly publishes
                # a file with unusable ids). Entries for channels that are no
                # longer live still go. An import whose guide source was
                # REMOVED falls through to the full prune below, as before.
                epg_configured = bool(res['updated_cfg'].get('epg_url')
                                      or res['updated_cfg'].get('epg_path'))
                if epg_configured and matched_chan == 0 and matched_prog == 0 and skipped_disabled == 0:
                    pruned_chan, pruned_prog = _pruneSlice(import_ns_suffix, dead_only=True)
                    # imports.59 (S10.3): as on the guide-unavailable path.
                    self._mergeLinksIntoKept(iid, res, all_imported_now, published_logos)
                    _applyGuideIcons(import_ns_suffix)
                    self.log('syncAll, [%s] no guide entries matched — keeping the previous guide (dropped %d channels + %d programmes no longer live)'
                             % (iid, pruned_chan, pruned_prog), level=xbmc.LOGWARNING)
                    continue

                # imports.59 (S10.3): merge this sync's replay links into the
                # fresh guide, with the replay history kept from the guide data
                # as loaded (pseudotv.xml) -- read before the prune below, which
                # removes it. The export starts at its own day's 00:00, so older
                # linked shows exist only there. If the merge fails, this
                # import keeps its previous guide (as when the guide is
                # unavailable) rather than lose that history; this file's
                # links then wait for the import's next sync or a new export
                # (links_mtime_ns is already recorded, see _readLinks).
                # imports.70: only here (fresh_path) does a new guide address
                # re-describe upcoming shows, (a), and a stale export give way
                # to the guide, (c); an error in either keeps the previous
                # guide like any merge error.
                if res.get('links') is not None:
                    try:
                        merged = self._mergeReplayLinks(iid, res, all_imported_now, published_logos,
                                                        new_chans, new_progs, fresh_path=True)
                    except Exception as e:
                        pruned_chan, pruned_prog = _pruneSlice(import_ns_suffix, dead_only=True)
                        _applyGuideIcons(import_ns_suffix)
                        self.log('syncAll, [%s] replay links merge failed (%s) — keeping the previous guide (dropped %d channels + %d programmes no longer live)'
                                 % (iid, e, pruned_chan, pruned_prog), level=xbmc.LOGERROR)
                        continue
                    if merged is not None:
                        new_chans, new_progs = merged

                # imports.66: check this import's show pictures against its
                # fresh guide. Only here: the three keep-previous paths above
                # (guide unavailable, nothing matched, links merge failed)
                # `continue` before this point -- they have no fresh data, so
                # the saved check results apply as they are. The check only
                # records results; pictures are removed at the choke point
                # after this loop. A failed check must never cost the import
                # its guide, so it is caught here, and whatever it recorded
                # before failing is still saved.
                try:
                    summary = self._checkShowPictures(iid, res['updated_cfg'], new_progs,
                                                      records_by_id, verdicts, pic_now)
                    verdicts_changed = verdicts_changed or summary['changed']
                except Exception as e:
                    verdicts_changed = True
                    self.log('syncAll, [%s] show pictures check failed: %s' % (iid, e),
                             level=xbmc.LOGERROR)

                # madteevee (imports fork): drop ALL stale entries for this
                # import's namespace before appending the freshly-matched ones.
                # Without this, the existing entries (loaded from disk by
                # XMLTVS.__init__) for channels that got disabled since the last
                # cycle would survive forever — the match loop only filters NEW
                # matches against enabled_ids. Stripping by namespace suffix
                # leaves all OTHER imports' entries untouched.
                pruned_chan, pruned_prog = _pruneSlice(import_ns_suffix, dead_only=False)
                if pruned_chan or pruned_prog:
                    self.log('syncAll, [%s] pruned %d channels + %d programmes from prior cycle (will re-append fresh matches honoring enabled-state)'
                             % (iid, pruned_chan, pruned_prog), level=xbmc.LOGINFO)
                xtv_channels.extend(new_chans)
                xtv_programmes.extend(new_progs)

            # imports.66: show pictures -- one choke point, on the guide about
            # to be published. Here it covers the fresh path, the three
            # keep-previous paths and imports skipped by their refresh
            # interval (their shows were loaded from disk), and running it
            # again changes nothing. A channel's own show pictures are removed
            # when its setting is Hide, or Auto while its import's check is on
            # and its last result says placeholder (picture_helpers.
            # pictures_hidden); Kodi then shows the channel logo for those
            # shows (CFileItem, xbmc/FileItem.cpp). import_cfg_by_id is the
            # import list loaded at the top of syncAll; a channel whose import
            # is no longer listed counts as having the check off.
            # Results of channels that no longer exist are dropped (the logo
            # cache's "present" rule, imports.56), but never on an empty
            # channel list -- a failed read must not wipe every result. The
            # file is saved once, only when something changed. Never fatal:
            # the guide is published either way.
            try:
                hidden_ids = set()
                for cid, rec in records_by_id.items():
                    cfg = import_cfg_by_id.get(rec.get('import_source'))
                    detect_on = picture_helpers.detect_enabled(cfg) if cfg is not None else False
                    if picture_helpers.pictures_hidden(rec, verdicts.get(cid), detect_on):
                        hidden_ids.add(cid)
                if hidden_ids:
                    stripped = picture_helpers.strip_pictures(self.xmltv.XMLTVDATA.get('programmes') or [],
                                                              hidden_ids)
                    self.log('syncAll, show pictures hidden on %d channel(s) (%d programmes)'
                             % (len(hidden_ids), stripped), level=xbmc.LOGINFO)
                pic_present = {c.get('id') for c in existing_channels if c.get('id')}
                pic_present |= {c.get('id') for c in all_imported_now.values() if c.get('id')}
                gone = [cid for cid in verdicts if cid not in pic_present] if pic_present else []
                for cid in gone:
                    del verdicts[cid]
                if gone:
                    verdicts_changed = True
                    self.log('syncAll, show pictures: dropped the check results of %d channel(s) no longer present'
                             % (len(gone),))
                if verdicts_changed:
                    self._savePictureVerdicts(verdicts)
            except Exception as e:
                self.log('syncAll, show pictures step failed: %s' % (e,), level=xbmc.LOGERROR)

        # imports.59 (S9): a channel whose replay needs per-show links offers
        # replay only while the show on air in the guide about to be
        # published carries one. IPTV Simple offers every started show within
        # catchup-days without checking for a link, and plays an unfilled
        # '{catchup-id}' ("Playback failed") when there is none. Decided here,
        # after the XML branch, so it sees the final guide (keep-previous
        # paths included). The record keeps the playlist's values, so replay
        # comes back by itself once links return.
        replay_links = self._replayOffers(all_imported_now.values())

        # Push imported channels into in-memory M3U. imports.59: moved after
        # the XML branch for the rule above; the XML branch never reads
        # M3UDATA, and the M3U force-flush below runs after this, as before.
        if self.m3u is not None:
            for ch in all_imported_now.values():
                # madteevee (imports fork): disabled / orphan / unallocated
                # channels must be EXPLICITLY removed from M3UDATA, not just
                # skipped. Skipping leaves stale entries (e.g., a channel
                # disabled in channels.json with number=9036 keeps its old
                # live-range #57 entry in pseudotv.m3u indefinitely, and
                # Kodi PVR keeps showing it). delStation removes by id.
                if ch.get('is_orphan') or ch.get('unallocated') or not ch.get('enabled', True):
                    try: self.m3u.delStation(ch)
                    except Exception: pass
                    continue
                station = self._channelToStation(ch, logo=published_logos.get(ch.get('id')),
                                                 replay_links=replay_links.get(ch.get('id')))
                try: self.m3u.addStation(station)
                except Exception as e:
                    self.log('syncAll, addStation [%s] failed: %s' % (ch.get('id'), e),
                             level=xbmc.LOGWARNING)

        # Force-flush merged XMLTVDATA when running under a writable XMLTVS
        # (Builder.buildChannels path). Builder's per-channel addProgramme
        # calls trigger debounced _save's that fire BEFORE this syncAll
        # finishes — so disk has the post-cleanSelf, pre-syncAll-merge state
        # (imports' EPG stripped). After our merge appends to XMLTVDATA the
        # debounce isn't kicked again (we mutate the lists directly, not via
        # addProgramme), so without this flush Builder leaves disk in the
        # imports-stripped state until the next chkImports cycle ~5 min later
        # — visible as the EPG oscillating in/out of Kodi PVR.
        # chkImports uses writable=False + its own _writeAtomic, so this branch
        # short-circuits there.
        if (self.xmltv is not None
            and getattr(self.xmltv, 'writable', False)
            and self.service is not None
            and hasattr(self.service, 'tasks')):
            try:
                # madteevee (imports fork): before flushing, merge in any
                # `@PseudoTV_Live` channels/programmes that Builder may have
                # written via `__setStation`'s `_writeAtomic` in parallel
                # to this syncAll. Without this merge, syncAll's
                # XMLTVDATA (which only holds imports) overwrites Builder's
                # Custom-channel programmes — Saturday Morning TV's 500
                # programmes vanished from pseudotv.xml within seconds of
                # being written. Read disk fresh, extract Custom-suffix
                # items, append the ones we don't already have.
                try:
                    from xmltvs import XMLTVS as _Xdisk
                    disk = _Xdisk(writable=False)
                    pseudo_slug = '@PseudoTV_Live'
                    existing_ch_ids = {c.get('id') for c in self.xmltv.XMLTVDATA.get('channels', []) if c.get('id')}
                    existing_prog_keys = {(p.get('channel'), p.get('start'))
                                          for p in self.xmltv.XMLTVDATA.get('programmes', [])}
                    added_chans = 0
                    added_progs = 0
                    for ch in (disk.XMLTVDATA.get('channels') or []):
                        cid = ch.get('id') or ''
                        if cid.endswith(pseudo_slug) and cid not in existing_ch_ids:
                            self.xmltv.XMLTVDATA.setdefault('channels', []).append(ch)
                            existing_ch_ids.add(cid)
                            added_chans += 1
                    for prog in (disk.XMLTVDATA.get('programmes') or []):
                        pcid = prog.get('channel') or ''
                        if pcid.endswith(pseudo_slug):
                            key = (pcid, prog.get('start'))
                            if key not in existing_prog_keys:
                                self.xmltv.XMLTVDATA.setdefault('programmes', []).append(prog)
                                existing_prog_keys.add(key)
                                added_progs += 1
                    if added_chans or added_progs:
                        self.log('syncAll, merged %d Custom channels + %d programmes from disk before flush'
                                 % (added_chans, added_progs), level=xbmc.LOGINFO)
                    del disk
                except Exception as e:
                    self.log('syncAll, Custom-merge from disk failed (force-flush will proceed without it): %s'
                             % e, level=xbmc.LOGWARNING)

                # imports.13 / C#10 Follow-up A: renderers + write_atomic
                # moved to module-level resources/lib/renderers.py (used to
                # be self.service.tasks._renderXMLTV / _writeAtomic).
                from renderers import render_xmltv, write_atomic
                rendered = render_xmltv(self.xmltv.XMLTVDATA)
                if rendered is None:
                    # Empty-data guard fired in render_xmltv; skip write
                    # so we don't overwrite disk with the self-closing
                    # `<tv/>` corruption shape. imports.59: render_xmltv also
                    # returns None when the render itself fails.
                    self.log('syncAll, force-flush skipped (empty XMLTVDATA or render failed); disk content preserved',
                             level=xbmc.LOGWARNING)
                else:
                    # imports.42: pass channel_count for write_atomic's
                    # circuit-breaker + LOGINFO size message.
                    channel_count = (len(self.xmltv.XMLTVDATA.get('channels')   or [])
                                   + len(self.xmltv.XMLTVDATA.get('recordings') or []))
                    write_atomic(XMLTVFLEPATH, rendered, channel_count=channel_count)
                    self.log('syncAll, force-flushed merged XMLTVDATA to disk (%d bytes)'
                             % len(rendered), level=xbmc.LOGINFO)
            except Exception as e:
                self.log('syncAll, force-flush failed: %s' % e, level=xbmc.LOGWARNING)

        # Symmetric force-flush for M3U. Same race as XML above:
        # Builder's per-channel addStation calls fire debounced M3U._save's
        # during the build loop; once syncAll's addStation calls finish,
        # the debounce may have already fired or may not re-fire before the
        # XMLTVS instance is GC'd. End result: pseudotv.m3u on disk misses
        # either the just-built PseudoTV channels (if first save was empty)
        # OR the imports (if second save loaded a stale snapshot). Writing
        # atomically here, after both PseudoTV-built channels and import
        # stations have been pushed into M3UDATA, ensures the file matches
        # the final merged state.
        if (self.m3u is not None
            and getattr(self.m3u, 'writable', False)):
            # imports.13 / C#10 Follow-up A: renderers moved to module-level.
            # The `self.service.tasks` precondition (was needed when renderers
            # lived on Tasks) is no longer required — render_m3u + write_atomic
            # are callable from any context.
            try:
                from renderers import render_m3u, write_atomic
                rendered = render_m3u(self.m3u.M3UDATA)
                # rendered=None means refuse-empty-write guard fired; skip
                # to preserve disk content rather than wipe to header-only.
                if rendered is not None:
                    # imports.42: pass channel_count for write_atomic's
                    # circuit-breaker + LOGINFO size message.
                    station_count = (len(self.m3u.M3UDATA.get('stations')   or [])
                                   + len(self.m3u.M3UDATA.get('recordings') or []))
                    write_atomic(M3UFLEPATH, rendered, channel_count=station_count)
                    self.log('syncAll, force-flushed merged M3UDATA to disk (%d bytes)'
                             % len(rendered), level=xbmc.LOGINFO)
                else:
                    self.log('syncAll, skipped M3U force-flush — empty M3UDATA (would wipe disk M3U)', level=xbmc.LOGWARNING)
            except Exception as e:
                self.log('syncAll, M3U force-flush failed: %s' % e, level=xbmc.LOGWARNING)

        # imports.22: only signal chkPVRRefresh when this syncAll cycle actually
        # changed disk state. Three change-signals jointly describe "bytes on disk
        # differ from before this cycle":
        #   (a) any syncOne returned status='ok' — a fresh HTTP 200 was fetched +
        #       parsed. Content MAY still be byte-identical to the prior cycle (server
        #       didn't honour ETag/If-Modified-Since) but cheap to over-signal vs.
        #       byte-comparing multi-MB M3U/XMLTV bodies.
        #   (b) a delete was applied — imports.69: `applied_deleted_ids` (from
        #       commitSync) are the deletes (tombstones and explicit deletes) that
        #       removed a record that was on disk or in this sync's list, in a
        #       commit that was written. Before imports.69 this was
        #       bool(deleted_ids), the union of every import's tombstones, so a
        #       kept tombstone whose record was long gone signalled every cycle.
        #   (c) any reconcile observed orphans — `res['orphans']` is the diff between
        #       parsed-now and existing channels for an import; non-empty means
        #       is_orphan=True got written to channels.json.
        # All-'unchanged'/'disabled' AND no deletes applied AND no orphans is the genuine
        # no-op cycle: every import returned HTTP 304, no operator deletion, nothing
        # fell out of source. Skipping setPropTimer here is correctness-safe because:
        #   - chkImports already runs every 5 min on its own daemon;
        #   - iptvsimple polls m3uUrl every m3uRefreshIntervalMins (default 15)
        #     regardless of whether we signal it;
        #   - this signal's only consumer (tasks.py:802 chkPVRRefresh) calls PVRScan
        #     (no-op against iptvsimple) and, until imports.22, bounced our HTTP
        #     server (also no-op against iptvsimple).
        # Reduces _chkPropTimer ticks, downstream queue churn, and the PVRScan
        # JSON-RPC round-trip on every cycle. Genuine state-change callers of
        # setPropTimer('chkPVRRefresh') outside syncAll (builder.py:477,
        # manager.py:1045, context_record.py:58/76, multiroom.py:165, kodi.py:519,
        # default.py:64, tasks.py:798) are NOT changed — they fire from paths that
        # always mutate state, so their unconditional signal is correct.
        changed = (
            any(r.get('status') == 'ok' for r in per_import_results.values())
            or bool(applied_deleted_ids)   # imports.69: a delete was applied
            or any(r.get('orphans') for r in per_import_results.values())
        )
        if changed:
            try: PROPERTIES.setPropTimer('chkPVRRefresh')
            except Exception: pass
        else:
            self.log('syncAll, no disk change this cycle — skipping chkPVRRefresh signal '
                     '(all imports status=unchanged/disabled, no deletes applied, no orphans)',
                     level=xbmc.LOGINFO)

        # Summary log
        for iid, res in per_import_results.items():
            self.log('syncAll, [%s] status=%s new=%d refreshed=%d orphan=%d epg=%d'
                     % (iid, res['status'], len(res['new']), len(res['refreshed']),
                        len(res['orphans']), len(res['epg_pairs'])),
                     level=xbmc.LOGINFO)

        return per_import_results


    def _replayOffers(self, records):
        """imports.59 (S9): {channel id: bool} for the live records whose
        replay needs per-show links (replay_helpers.link_replay_days): True
        while the guide data in self.xmltv carries a link for the show on
        air -- with none on air, the latest show that has started -- else
        False (replay_helpers.channels_with_links). Other records are absent
        (their catch-up is published as recorded). {} without guide data."""
        if self.xmltv is None:
            return {}
        link_ids = set(replay_helpers.link_replay_days(records))
        if not link_ids:
            return {}
        return replay_helpers.channels_with_links(self.xmltv.XMLTVDATA.get('programmes') or [],
                                                  link_ids, int(time.time()))

    def _channelToStation(self, ch, logo=None, replay_links=None):
        """Map an imported channel record → M3U station dict for `m3u.addStation`.

        Mirrors the M3U_TEMP shape (m3u.py:26) plus `url` and `label`.
        Imported channels' `tvg-id` in the output M3U is the namespaced form
        (`<source_tvg_id>@<import_id>`) — this prevents IPTV Simple's tvg-id
        dedup from silently dropping channels with same source-side tvg-id
        across multiple imports (plan G1).

        imports.58: `logo` — the address to publish when it differs from the
        record's own (the cached copy's link, see syncAll's logo cache step);
        the record itself is never rewritten.

        imports.59 (S9): `replay_links` — for a channel whose replay needs
        per-show links, whether the show on air in the guide carries one
        (`_replayOffers`). False publishes catchup="" and no catchup-source /
        catchup-days, so IPTV Simple offers no replay; None (any other
        channel) publishes the record's values. The record is never changed.

        CRITICAL — bool/empty-string semantics:
        M3U._save's optional-attrs loop (m3u.py:226-232) emits ANY key with
        a truthy `str(value)`. `str(False)` is `"False"` (TRUTHY string) → if
        we set `media: False`, output gets `media="False"` → IPTV Simple
        treats the channel as a media item (VOD/recording), NOT a live channel
        (verified empirically: 91 channels misclassified as 91 media items).
        Solution: pass empty strings instead of `False` for the OPTIONAL
        attrs (`media`, `media-dir`, `media-size`, `realtime`, `favorite`,
        `provider-*`, etc.) — they only emit when source actually provides
        a non-empty value. Required attrs (`radio`, `catchup`) stay bool
        because m3u.py's hardcoded line template at m3u.py:218 always
        substitutes them via positional %s.
        """
        def _opt_bool(k):
            """For OPTIONAL bool attrs: empty str when False (don't serialize); the actual bool when True."""
            v = ch.get(k)
            return v if v else ''
        def _opt_str(k):
            v = ch.get(k)
            return v if v else ''
        replay_off = replay_links is False
        return {
            'id'                : ch.get('id', ''),  # NAMESPACED — already from parseM3U
            'number'            : ch.get('number', 0),
            'name'              : ch.get('name', ''),
            'logo'              : logo or ch.get('logo', ''),
            'group'             : list(ch.get('group') or []),
            # `radio` and `catchup` are positional in m3u.py:218 line template; always emitted.
            'radio'             : bool(ch.get('radio', False)),
            'catchup'           : '' if replay_off else ch.get('catchup', ''),
            'label'             : ch.get('name', ''),
            'url'               : ch.get('source_url', '') or ch.get('url', ''),
            # OPTIONAL attrs — empty-string when missing/False so M3U._save's
            # truthy-str check doesn't emit them with literal "False" values.
            'favorite'          : _opt_bool('favorite'),
            'realtime'          : _opt_bool('realtime'),
            'media'             : _opt_bool('media'),
            'media-dir'         : _opt_str('media-dir'),
            'media-size'        : _opt_str('media-size'),
            'tvg-shift'         : _opt_str('tvg-shift'),
            'catchup-source'    : '' if replay_off else _opt_str('catchup-source'),
            'catchup-days'      : '' if replay_off else _opt_str('catchup-days'),
            'catchup-correction': _opt_str('catchup-correction'),
            'provider'          : _opt_str('provider'),
            'provider-type'     : _opt_str('provider-type'),
            'provider-logo'     : _opt_str('provider-logo'),
            'provider-countries': _opt_str('provider-countries'),
            'provider-languages': _opt_str('provider-languages'),
            'x-playlist-type'   : _opt_str('x-playlist-type'),
            'kodiprops'         : list(ch.get('kodiprops') or []),
            'extvlcopt'         : list(ch.get('extvlcopt') or []),
            'webprops'          : list(ch.get('webprops') or []),
        }

    def fetchSource(self, url_or_path, etag=None, last_modified=None,
                    timeout=15, chunk_size=65536):
        """
        Conditional fetch — local file or remote URL.

        Returns: dict {
            'status'       : int,           # 200 ok, 304 unchanged, 4xx/5xx fail, 0 local-error
            'content'      : bytes or None, # None for 304 / failure
            'etag'         : str or None,   # remote only; pass back next call
            'last_modified': str or None,   # remote: HTTP header value
                                            # local:  str(stat.st_mtime)
            'error'        : str or None,   # populated on failure
            # local only (imports.59, see _fetchLocal):
            'mtime_ns'     : int or None,   # st_mtime_ns of a stable read
            'transient'    : True,          # only on a read the file changed during
        }

        Local file (`special://`, absolute path): stat mtime; if mtime <=
        `last_modified` (epoch float as string), returns 304 with content=None.
        Otherwise returns full bytes + new mtime as last_modified.

        Remote URL (http/https): conditional GET via `If-None-Match` /
        `If-Modified-Since`. Chunked download with `_interrupt()` polling
        every chunk so Kodi shutdown can interrupt long fetches (plan G15).
        Backoff/retry handled by `requests.adapters.HTTPAdapter` with `Retry`.
        """
        # Validate URL scheme upfront
        try:
            validate_source_url(url_or_path)
        except ValueError as e:
            return {'status': 0, 'content': None, 'etag': None,
                    'last_modified': None, 'error': str(e)}

        if is_remote_url(url_or_path):
            return self._fetchRemote(url_or_path, etag, last_modified, timeout, chunk_size)
        else:
            return self._fetchLocal(url_or_path, last_modified)

    @staticmethod
    def _localRealPath(path):
        """imports.59 (S4): the real filesystem path of a local source, or None
        when it doesn't translate to a local file (Kodi's VFS reads those).
        special:// paths are translated; any other path is used as given, as
        _fetchLocal always did (FileAccess.translatePath would cut a plain
        path at an '@')."""
        if not isinstance(path, str) or not path:
            return None
        real_path = FileAccess.translatePath(path) if path.startswith('special://') else path
        if not isinstance(real_path, str) or not real_path or '://' in real_path:
            return None
        return real_path

    @staticmethod
    def _localFileState(path):
        """imports.59 (S4/S17): (size, mtime_ns) of a local file -- os.stat on
        the translated path, never xbmcvfs.Stat -- or None when it can't be
        stat'ed (missing, inaccessible, or not a local file). The local read
        (_fetchLocal) and the new-links trigger (_linksChanged) both use it,
        so the stored links_mtime_ns and the value compared with it are the
        same unit."""
        real_path = Imports._localRealPath(path)
        if real_path is None:
            return None
        try:
            st = os.stat(real_path)
        except (OSError, ValueError):
            return None
        return (st.st_size, st.st_mtime_ns)

    def _fetchLocal(self, path, last_modified):
        """Read a local file; honor mtime for conditional fetch.

        imports.59 (S4): a path that translates to a local file is read with
        plain Python file I/O -- _localFileState (os.stat) before and after,
        open(..., 'rb') in between -- never through xbmcvfs.Stat, which once
        wedged the imports thread on another add-on's special:// file during
        playback (tasks.py chkImports note). Kodi's VFS reads only a path
        that doesn't translate to a local file (_fetchLocalVFS, as before).
          - The validator stays str(st_mtime), now with sub-second precision
            (xbmcvfs.Stat gave whole seconds), so each local source is read
            in full once after this update.
          - The result also carries 'mtime_ns', the file's st_mtime_ns.
          - Movistar+ rewrites its playlist and guide export in place. When
            the size or mtime_ns changed during the read, the result is a
            failure marked 'transient' with no content: nothing is parsed or
            stored from it (validators untouched, no channel orphaned) and
            the next sync tries again.
        """
        try:
            real_path = self._localRealPath(path)
        except Exception as e:
            return {'status': 0, 'content': None, 'etag': None,
                    'last_modified': None, 'mtime_ns': None,
                    'error': 'local fetch failed: %s' % e}
        if real_path is None:
            return self._fetchLocalVFS(path, last_modified)

        before = self._localFileState(path)
        if before is None:
            return {'status': 0, 'content': None, 'etag': None,
                    'last_modified': None, 'mtime_ns': None,
                    'error': 'local source not found: %s' % path}
        mtime = before[1] / 1e9
        if last_modified is not None:
            try:
                if mtime <= float(last_modified):
                    return {'status': 304, 'content': None, 'etag': None,
                            'last_modified': str(mtime), 'mtime_ns': before[1], 'error': None}
            except (ValueError, TypeError):
                # imports.59 (S4): an invalid stored validator -- read in full.
                self.log('_fetchLocal, %s: stored last_modified %r is not a number; reading in full'
                         % (path, last_modified), level=xbmc.LOGDEBUG)

        content, error = None, None
        try:
            with open(real_path, 'rb') as f:
                content = f.read()
        except OSError as e:
            error = 'local fetch failed: %s' % e
        after = self._localFileState(path)
        if after != before:
            self.log('_fetchLocal, %s changed while reading; will retry' % (path,), level=xbmc.LOGINFO)
            return {'status': 0, 'content': None, 'etag': None,
                    'last_modified': None, 'mtime_ns': None, 'transient': True,
                    'error': 'file changed while reading; will retry'}
        if error is not None:
            # Stable but unreadable (e.g. permissions): mtime_ns still tells
            # the replay-links read this file was seen as it is.
            return {'status': 0, 'content': None, 'etag': None,
                    'last_modified': None, 'mtime_ns': after[1], 'error': error}
        return {'status': 200, 'content': content, 'etag': None,
                'last_modified': str(mtime), 'mtime_ns': after[1], 'error': None}

    def _fetchLocalVFS(self, path, last_modified):
        """Read a local source through Kodi's VFS (pre-imports.59 _fetchLocal,
        unchanged): only for a path that doesn't translate to a local file,
        e.g. a special:// folder mapped to a network share."""
        try:
            # Resolve special:// via FileAccess
            real_path = FileAccess.translatePath(path) if path.startswith('special://') else path
            if not FileAccess.exists(path):
                return {'status': 0, 'content': None, 'etag': None,
                        'last_modified': None,
                        'error': 'local source not found: %s' % path}

            # mtime via xbmcvfs.Stat (works through Kodi VFS layer)
            try:
                stat_obj = xbmcvfs.Stat(path)
                mtime = float(stat_obj.st_mtime())
            except Exception:
                # Fallback to os.stat on resolved path
                mtime = float(os.stat(real_path).st_mtime)

            if last_modified is not None:
                try:
                    if mtime <= float(last_modified):
                        return {'status': 304, 'content': None, 'etag': None,
                                'last_modified': str(mtime), 'error': None}
                except (ValueError, TypeError):
                    pass  # invalid stored last_modified — fall through to read

            # Read raw bytes — fall back to vanilla open() if FileAccess wrapper
            # returns str (test-stub or unexpected encoding handling).
            try:
                with FileAccess.stream(path, 'rb') as f:
                    content = f.read()
            except Exception:
                with open(real_path, 'rb') as f:
                    content = f.read()
            if isinstance(content, str):
                content = content.encode('utf-8')

            return {'status': 200, 'content': content, 'etag': None,
                    'last_modified': str(mtime), 'error': None}
        except Exception as e:
            return {'status': 0, 'content': None, 'etag': None,
                    'last_modified': None,
                    'error': 'local fetch failed: %s' % e}

    def _fetchRemote(self, url, etag, last_modified, timeout, chunk_size):
        """HTTP fetch with conditional GET + chunked download + abort polling."""
        try:
            import requests
            from requests.adapters import HTTPAdapter, Retry
        except ImportError as e:
            return {'status': 0, 'content': None, 'etag': None,
                    'last_modified': None,
                    'error': 'requests module unavailable: %s' % e}

        session = requests.Session()
        retries = Retry(total=3, backoff_factor=1, status_forcelist=[500, 502, 503, 504])
        adapter = HTTPAdapter(max_retries=retries)
        session.mount('http://',  adapter)
        session.mount('https://', adapter)

        headers = {}
        if etag:          headers['If-None-Match']     = etag
        if last_modified: headers['If-Modified-Since'] = last_modified

        # madteevee (imports fork): cap remote-fetch size at 100 MB. Without
        # this, an upstream that responds 200 OK and trickles bytes forever
        # (or claims an enormous Content-Length) would buffer until OOM on
        # the RPi5. 100 MB is well above any realistic M3U/XMLTV — movistar+
        # XMLTV is ~22 MB and the largest IPTV feeds we have seen are ~50 MB.
        MAX_FETCH_BYTES = 100 * 1024 * 1024

        try:
            with session.get(url, headers=headers, timeout=timeout, stream=True) as r:
                # 304 — unchanged; nothing to download.
                if r.status_code == 304:
                    return {'status': 304, 'content': None, 'etag': etag,
                            'last_modified': last_modified, 'error': None}

                if not (200 <= r.status_code < 300):
                    return {'status': r.status_code, 'content': None, 'etag': None,
                            'last_modified': None,
                            'error': 'HTTP %d for %s' % (r.status_code, url)}

                # Reject up-front if upstream declares an oversize body.
                try: declared = int(r.headers.get('Content-Length', '0') or '0')
                except (TypeError, ValueError): declared = 0
                if declared > MAX_FETCH_BYTES:
                    return {'status': 0, 'content': None, 'etag': None,
                            'last_modified': None,
                            'error': 'fetch aborted: declared %d bytes exceeds cap %d' % (declared, MAX_FETCH_BYTES)}

                # Chunked stream with abort polling (plan G15) + size cap.
                buf = bytearray()
                for chunk in r.iter_content(chunk_size=chunk_size):
                    if self.service is not None and hasattr(self.service, '_interrupt'):
                        if self.service._interrupt():
                            return {'status': 0, 'content': None, 'etag': None,
                                    'last_modified': None,
                                    'error': 'fetch interrupted (shutdown signaled)'}
                    if chunk:
                        buf.extend(chunk)
                        if len(buf) > MAX_FETCH_BYTES:
                            return {'status': 0, 'content': None, 'etag': None,
                                    'last_modified': None,
                                    'error': 'fetch aborted: stream exceeded cap %d bytes' % MAX_FETCH_BYTES}

                return {'status': 200, 'content': bytes(buf),
                        'etag': r.headers.get('ETag'),
                        'last_modified': r.headers.get('Last-Modified'),
                        'error': None}
        except Exception as e:
            return {'status': 0, 'content': None, 'etag': None,
                    'last_modified': None,
                    'error': 'remote fetch failed: %s' % e}
        finally:
            try: session.close()
            except Exception: pass

    # ------------------------------------------------------------------
    # Per-import EPG cache (step 5)
    # ------------------------------------------------------------------
    # Each import's most recent successful EPG fetch is stashed as raw
    # bytes at `CACHE_LOC/epg_<import_id>.xml`. On a 304 response, syncOne
    # hydrates `epg_pairs` from this file instead of leaving them empty —
    # which would otherwise let `_save` write an EPG that's missing this
    # source after a restart-then-304 sequence (XMLTVS._load.cleanSelf
    # strips non-`@PseudoTV_Live`-slug channels from in-memory state).
    # The parser auto-detects gzip via magic bytes, so we store the
    # server's response verbatim and let parseXMLTV do the right thing.

    def _epgCachePath(self, import_id):
        # CACHE_LOC is a Kodi special:// path at runtime (resolves to
        # ~/.kodi/userdata/addon_data/<id>/cache). os.makedirs / os.open
        # can't handle the URI form, so translate to a real fs path here.
        # In unit tests CACHE_LOC is a tmp_path (no scheme) — the test
        # xbmcvfs.translatePath stub returns non-special paths unchanged.
        return FileAccess.translatePath(os.path.join(CACHE_LOC, 'epg_%s.xml' % import_id))

    def _epgCacheWrite(self, import_id, content_bytes):
        """
        Atomically write fetched EPG bytes to the per-import cache file.

        Returns True on success, False on any I/O failure. Never raises.
        Caller MUST NOT update `epg_etag`/`epg_last_modified` in
        `updated_cfg` when this returns False — otherwise the next cycle
        will conditional-GET against validators whose payload isn't on
        disk, and on 304 fall through to "cache missing → force fetch"
        which costs one extra round-trip.
        """
        # madteevee (imports fork): reject empty bytes too — upstream that
        # responds 200 OK with Content-Length: 0 used to poison the per-import
        # EPG cache (empty file → next cycle's 304 load returned no channels).
        if not import_id or not content_bytes:
            return False
        target = self._epgCachePath(import_id)
        tmp    = target + '.tmp'
        try:
            os.makedirs(os.path.dirname(target), exist_ok=True)
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
            try:
                os.write(fd, content_bytes)
                os.fsync(fd)
            finally:
                os.close(fd)
            os.replace(tmp, target)
            self.log('_epgCacheWrite, [%s] wrote %d bytes to %s'
                     % (import_id, len(content_bytes), target))
            return True
        except Exception as e:
            self.log('_epgCacheWrite, [%s] failed: %s' % (import_id, e),
                     level=xbmc.LOGWARNING)
            try: os.unlink(tmp)
            except Exception: pass
            return False

    # ------------------------------------------------------------------
    # Per-channel logo cache (step 5)
    # ------------------------------------------------------------------
    # When `Imports_Cache_Logos` is on, fetched M3U `tvg-logo` URLs are
    # downloaded into CACHE_LOC/logos/ and the playlist and guide publish
    # the cached copy (`_portableLogoURL`) instead of the upstream URL.
    # IPTV Simple / Kodi PVR then loads logos from us instead of
    # re-fetching from upstream every refresh.
    #
    # Refresh policy (`Imports_Logo_Refresh`):
    #   0 = Fetch if missing  — write once, reuse until the logo's address changes
    #   1 = Conditional GET   — re-check each cycle via ETag/Last-Modified
    #   2 = Refetch every cycle — always download (~60 MB/hr; not recommended)
    #
    # Per-channel records live alongside the cache files at
    # CACHE_LOC/logos/.validators.json: {channel_id: {url, file, etag,
    # last_modified}} — the address the cached copy came from, its file name
    # (imports.58) and its validators. Loaded once per syncAll cycle,
    # mutated as we go, written back at end.

    def _logoCacheDir(self):
        return FileAccess.translatePath(os.path.join(CACHE_LOC, 'logos'))

    def _logoCachePath(self, channel_id, ext='img', version=None):
        # Channel IDs already use safe chars (alnum + `_-.@`); @ is fine on
        # ext4/NTFS/APFS. Add ext for human inspection. imports.58: with a
        # `version` the name is `<channel_id>~<version>.<ext>` (see
        # LOGO_VERSION_SEP).
        if version:
            return os.path.join(self._logoCacheDir(), '%s%s%s.%s' % (channel_id, LOGO_VERSION_SEP, version, ext))
        return os.path.join(self._logoCacheDir(), '%s.%s' % (channel_id, ext))

    def _logoExtForUrl(self, url, content_type=None):
        # Try Content-Type first (authoritative), fall back to URL suffix.
        if content_type:
            ct = content_type.split(';', 1)[0].strip().lower()
            for prefix, ext in (('image/png', 'png'), ('image/jpeg', 'jpg'),
                                ('image/jpg', 'jpg'), ('image/webp', 'webp'),
                                ('image/gif', 'gif'), ('image/svg+xml', 'svg'),
                                ('image/x-icon', 'ico')):
                if ct == prefix or ct.startswith(prefix):
                    return ext
        # URL extension fallback
        try:
            path = urllib.parse.urlparse(url).path
            tail = path.rsplit('/', 1)[-1]
            if '.' in tail:
                ext = tail.rsplit('.', 1)[-1].lower()
                if 1 <= len(ext) <= 5 and ext.isalnum():
                    return ext
        except Exception:
            pass
        return 'img'

    def _logoLoadValidators(self):
        path = os.path.join(self._logoCacheDir(), '.validators.json')
        try:
            if not os.path.exists(path):
                return {}
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception as e:
            self.log('_logoLoadValidators failed: %s' % e, level=xbmc.LOGWARNING)
            return {}

    def _logoSaveValidators(self, validators):
        target = os.path.join(self._logoCacheDir(), '.validators.json')
        tmp    = target + '.tmp'
        try:
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(validators, f)
            os.replace(tmp, target)
        except Exception as e:
            self.log('_logoSaveValidators failed: %s' % e, level=xbmc.LOGWARNING)
            try: os.unlink(tmp)
            except Exception: pass

    def _findLogoFile(self, channel_id):
        """Return the existing on-disk cache path for channel_id, or None.

        imports.58: matches the file name's channel id exactly (the old
        `<channel_id>.` prefix test also matched a channel whose id merely
        starts that way) and knows both name forms; the newest file wins."""
        try:
            cache_dir = self._logoCacheDir()
            if not os.path.isdir(cache_dir):
                return None
            found = []
            for name in os.listdir(cache_dir):
                if name.startswith('.') or name.endswith('.tmp'):
                    continue
                if logo_file_channel_id(name) == channel_id:
                    path = os.path.join(cache_dir, name)
                    try: found.append((os.path.getmtime(path), path))
                    except OSError: continue   # removed while listing
            if found:
                return max(found)[1]
        except Exception:
            pass
        return None

    def _currentLogoFile(self, channel_id, record=None):
        """imports.58: the cached copy currently in use for channel_id — the
        file named in its .validators.json record, else whatever
        `_findLogoFile` finds (records written before imports.58 carry no
        file name) — or None."""
        name = (record or {}).get('file')
        if isinstance(name, str) and name and logo_file_channel_id(name) == channel_id:
            path = os.path.join(self._logoCacheDir(), name)
            if os.path.isfile(path):
                return path
        return self._findLogoFile(channel_id)

    def _dropOtherLogoFiles(self, channel_id, keep):
        """imports.58: after a new copy of channel_id's logo is saved, remove
        the channel's other cache files (an older picture, or the same
        picture under its pre-imports.58 name)."""
        try:
            cache_dir = self._logoCacheDir()
            for name in os.listdir(cache_dir):
                if name.startswith('.') or name.endswith('.tmp'):
                    continue
                path = os.path.join(cache_dir, name)
                if path != keep and logo_file_channel_id(name) == channel_id:
                    try: os.unlink(path)
                    except Exception as e:
                        self.log('_dropOtherLogoFiles, [%s] could not remove %s: %s'
                                 % (channel_id, name, e), level=xbmc.LOGWARNING)
        except Exception as e:
            self.log('_dropOtherLogoFiles, [%s] failed: %s' % (channel_id, e),
                     level=xbmc.LOGWARNING)

    def _fetchLogo(self, url, etag=None, last_modified=None, timeout=15):
        """
        Fetch a single logo via conditional GET. Logos are small (~kB to ~100kB)
        so unchunked + non-streaming is fine; no abort polling either since
        the request is bounded by `timeout`.

        Returns dict {'status', 'content', 'etag', 'last_modified', 'error'}.
        """
        try:
            import requests
        except ImportError as e:
            return {'status': 0, 'content': None, 'etag': None,
                    'last_modified': None, 'error': 'requests unavailable: %s' % e}
        # Wikimedia (upload.wikimedia.org) — and a few other providers —
        # block the default `python-requests/X.Y.Z` User-Agent. Send an
        # identifying UA per the Wikimedia UA policy
        # (https://meta.wikimedia.org/wiki/User-Agent_policy).
        # imports.66: the module constant, shared with the show-picture
        # check; the value is unchanged.
        headers = {
            'User-Agent': _HTTP_USER_AGENT,
        }
        if etag:          headers['If-None-Match']     = etag
        if last_modified: headers['If-Modified-Since'] = last_modified
        try:
            r = requests.get(url, headers=headers, timeout=timeout, stream=False)
            if r.status_code == 304:
                return {'status': 304, 'content': None, 'etag': etag,
                        'last_modified': last_modified,
                        'content_type': None, 'error': None}
            if not (200 <= r.status_code < 300):
                return {'status': r.status_code, 'content': None, 'etag': None,
                        'last_modified': None,
                        'content_type': None,
                        'error': 'HTTP %d for %s' % (r.status_code, url)}
            return {'status': 200, 'content': r.content,
                    'etag': r.headers.get('ETag'),
                    'last_modified': r.headers.get('Last-Modified'),
                    'content_type': r.headers.get('Content-Type'),
                    'error': None}
        except Exception as e:
            return {'status': 0, 'content': None, 'etag': None,
                    'last_modified': None, 'content_type': None,
                    'error': 'logo fetch failed: %s' % e}

    def _logoWriteAtomic(self, target, content_bytes):
        tmp = target + '.tmp'
        try:
            os.makedirs(os.path.dirname(target), exist_ok=True)
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
            try:
                os.write(fd, content_bytes)
                os.fsync(fd)
            finally:
                os.close(fd)
            os.replace(tmp, target)
            return True
        except Exception as e:
            self.log('_logoWriteAtomic failed for %s: %s' % (target, e),
                     level=xbmc.LOGWARNING)
            try: os.unlink(tmp)
            except Exception: pass
            return False

    def _cacheLogo(self, channel_id, source_url, refresh_mode, validators):
        """
        Apply refresh policy and return the absolute fs path of the cached
        logo on success, or None when there is no copy to use (caller then
        publishes `source_url` as-is). Mutates `validators` dict in place
        when fetches succeed.

        imports.58: a cached copy belongs to the address it was downloaded
        from (`validators[channel_id]['url']`). Pre-imports.58 mode 0 reused
        any file named after the channel, so a logo whose address changed —
        an operator edit in the dashboard, or a source switching pictures —
        kept the old picture forever, and mode 1 sent the old address's
        validators to the new one. Now a copy is reused, or revalidated,
        only for the address it came from; a changed address is downloaded.
        If that download fails the new address is published as-is (Kodi
        tries it directly) and the old copy stays on disk; a copy with no
        recorded address (validators used to be written only when the server
        sent ETag/Last-Modified) is downloaded once and kept if that fails.
        New pictures are saved under a versioned name (LOGO_VERSION_SEP), so
        Kodi gets a new link for a new picture and the same link for the
        same one.
        """
        if not source_url or not is_remote_url(source_url):
            return None
        if not isinstance(validators, dict):
            validators = {}
        cv = validators.get(channel_id) or {}
        existing = self._currentLogoFile(channel_id, cv)

        # imports.56: never download one of our OWN /images/ links. A channel
        # whose source stopped supplying a logo keeps the portable URL as its
        # `logo`, and fetching it meant this addon calling itself over the
        # LAN address — refused (401) by the auth gate, or a 30 s timeout when
        # the host part was stale. The file is either already cached (reuse
        # it) or gone (nothing to fetch).
        if own_logo_basename(source_url, self._ownLogoPorts()) is not None:
            return existing

        recorded_url    = cv.get('url')
        same_source     = bool(existing) and recorded_url == source_url
        keep_on_failure = same_source or (bool(existing) and not recorded_url)

        if refresh_mode == 0 and same_source:
            # Fetch if missing — already present, no work
            return existing

        send_etag = cv.get('etag')          if (refresh_mode == 1 and same_source) else None
        send_lm   = cv.get('last_modified') if (refresh_mode == 1 and same_source) else None

        fetched = self._fetchLogo(source_url, etag=send_etag, last_modified=send_lm)
        if fetched['status'] == 304 and same_source:
            return existing
        if fetched['status'] != 200 or not fetched.get('content'):
            self.log('_cacheLogo, [%s] skipped (status=%s, error=%s, url=%s)'
                     % (channel_id, fetched.get('status'),
                        fetched.get('error'), source_url),
                     level=xbmc.LOGWARNING)
            return existing if keep_on_failure else None  # None: caller falls back to URL
        content = fetched['content']
        ext     = self._logoExtForUrl(source_url, fetched.get('content_type'))
        version = hashlib.md5(content).hexdigest()[:LOGO_VERSION_LEN]
        target  = self._logoCachePath(channel_id, ext, version=version)
        if target != existing:
            if not self._logoWriteAtomic(target, content):
                return existing if keep_on_failure else None
            # Drop the channel's previous copy (other picture, or the same
            # picture under its pre-imports.58 name).
            self._dropOtherLogoFiles(channel_id, keep=target)
        validators[channel_id] = {
            'etag'         : fetched.get('etag'),
            'last_modified': fetched.get('last_modified'),
            'url'          : source_url,
            'file'         : os.path.basename(target),
        }
        return target

    def _portableLogoURL(self, local):
        """imports.44: convert an absolute LOGO_LOC path returned by
        _cacheLogo into a portable `http://<remote_host>/images/<basename>`
        URL so cross-host iptvsimple clients (e.g. a tablet pulling our
        M3U via http://<madteevee>:50002/pseudotv.m3u) can resolve the
        logo. Without the wrap, the absolute madteevee-only path lands
        in tvg-logo and remote clients render Kodi's default texture for
        every cached logo. server.py's /images/ handler (server.py:1846+)
        maps the basename back to LOGO_LOC + <basename>, so the URL
        roundtrips to the same file. PROPERTIES.getRemoteHost() lazy-inits
        the Remote_Host window property if syncAll runs before the HTTP
        server has published it via setRemoteHost (server.py:2426). On
        the rare host-empty branch we keep the absolute path so at least
        local Kodi keeps rendering correctly.
        """
        host = PROPERTIES.getRemoteHost()
        if not host:
            return local
        return 'http://%s/images/%s' % (host, Globals._quoteString(os.path.basename(local)))

    def _ownLogoPorts(self):
        """imports.56: ports that mark a logo URL as one of our own
        /images/ links — the current server port plus the configured
        TCP_PORT (see logo_links.port_set)."""
        try:
            tcp_port = SETTINGS.getSettingInt('TCP_PORT')
        except Exception:
            tcp_port = None
        return port_set(PROPERTIES.getRemoteHost(), tcp_port)

    def _guideIcon(self, ch_rec, published=None):
        """imports.58: the logo to write into an imported channel's guide
        <icon>, or None to keep the icon the guide source supplied.

        The addon configures iptvsimple with "Channel logos from XMLTV" =
        Prefer XMLTV (kodi.py _IPTV_SIMPLE_SETTINGS, logoFromEpg='2'), so the
        guide's <icon> is the logo Kodi shows whenever the guide has one.
        `published` is the address the playlist uses for this channel this
        cycle (the cached copy's link), when it has one.
          - A logo the operator set ('logo' in operator_overrides) always
            wins — pre-imports.58 one typed as a web address never reached
            Kodi.
          - A local logo (logo pack, upload, special://) replaces the guide's
            icon, as before. (The pre-imports.58 rule was "not a web
            address"; once imports.44 published cached copies as http://
            links it only ever matched local files.)
          - Every other channel keeps the guide source's icon (operator
            decision 2026-10-20).
        """
        ch_rec = ch_rec or {}
        logo = published or ch_rec.get('logo') or ''
        if not isinstance(logo, str) or not logo:
            return None
        if 'logo' in (ch_rec.get('operator_overrides') or []):
            return logo
        if not is_remote_url(logo):
            return logo
        return None

    def _evictOrphanLogos(self, active_channel_ids):
        """Remove cache/logos/ files for channel ids no longer present.

        imports.35: extended the "keep" predicate to also preserve any
        file currently referenced by a channel record's `logo` field in
        channels.json. Without this, operator-uploaded custom logos
        (added via manager.py:switchLogo.__browse at manager.py:900,
        which copies to cache/logos/<chname>.<ext>) were treated as
        orphans because their filename stem (e.g., "TMNT") doesn't match
        any active import id (e.g., "TVLand.us@epgbest_46477"). Net
        effect pre-fix: every syncAll cycle wiped operator-uploaded
        Custom-channel logos. Naming-convention agnostic — works
        whether the file is named by channel-id (imports cache) or by
        channel-name (switchLogo.__browse).
        """
        try:
            cache_dir = self._logoCacheDir()
            if not os.path.isdir(cache_dir):
                return 0
            active = set(active_channel_ids or ())

            # imports.35: cross-reference channels.json's logo fields to
            # protect operator-uploaded customs (and any other valid
            # referenced file) from eviction. Build the set of basenames
            # currently referenced by ANY channel's logo field.
            #
            # imports.46: also recognize the imports.44 URL form
            # `http://<remote_host>/images/<url-encoded-basename>`. Pre-
            # imports.44 ch['logo'] for cached channels held the absolute
            # `/.../cache/logos/<basename>` path and matched the
            # `'cache/logos/' in logo` predicate; imports.44 replaced
            # that with the portable HTTP URL form so cross-host
            # consumers can resolve it, but `'cache/logos/'` no longer
            # appears in the field. Without this branch every cycle
            # where `all_imported_now` ends up empty (e.g. a 304-only
            # sync — every per-import returned Not-Modified, so no
            # `new`/`refreshed` records were synthesized) walks the
            # cache with active=empty AND referenced=empty and wipes
            # every file. Live-observed 2026-05-20 between imports.44
            # ship and imports.45: 78 PNGs in cache/logos/ → 0 after a
            # subsequent sync, which then made imports.45's translatePath
            # fix moot because the files /images/ pointed at no longer
            # existed.
            # Wrapped in try/except so a channels-layer failure falls
            # back to today's behavior (no regression — just no new
            # protection).
            referenced_basenames = set()
            try:
                for ch in (self.channels.getChannels() or []):
                    logo = ch.get('logo') or ''
                    if not isinstance(logo, str) or not logo:
                        continue
                    if 'cache/logos/' in logo:
                        referenced_basenames.add(os.path.basename(logo))
                    elif '/images/' in logo:
                        # imports.44 wrap form. Extract the URL-encoded
                        # basename from the tail and decode (mirrors
                        # server.py's _unquoteString of img_path).
                        try:
                            tail = logo.rsplit('/images/', 1)[1]
                            decoded = urllib.parse.unquote(tail)
                            if decoded and '/' not in decoded:
                                referenced_basenames.add(decoded)
                        except Exception:
                            pass
            except Exception as e:
                self.log('_evictOrphanLogos, channels cross-ref failed: %s'
                         % e, level=xbmc.LOGWARNING)

            # imports.46: defense-in-depth bail-out. If neither path
            # produced a "keep" predicate (active set empty AND no
            # channel references), refuse to walk the cache. The
            # eviction loop would unlink every file — almost certainly
            # not what the operator wants for a single bad sync cycle.
            if not active and not referenced_basenames:
                self.log('_evictOrphanLogos, skipping: empty active set + no channel references (likely a 304-only or failed sync cycle — refusing to mass-wipe)',
                         level=xbmc.LOGWARNING)
                return 0

            removed = 0
            for name in os.listdir(cache_dir):
                if name.startswith('.') or name.endswith('.tmp'):
                    continue
                # filename = <channel_id>~<version>.<ext> (imports.58) or
                # <channel_id>.<ext>
                cid = logo_file_channel_id(name)
                if cid and cid in active:
                    continue
                # imports.35: keep if any channel record references this file.
                if name in referenced_basenames:
                    continue
                try:
                    os.unlink(os.path.join(cache_dir, name))
                    removed += 1
                except Exception:
                    pass
            if removed:
                self.log('_evictOrphanLogos, removed %d orphan logo file(s)'
                         % removed, level=xbmc.LOGINFO)
            return removed
        except Exception as e:
            self.log('_evictOrphanLogos failed: %s' % e, level=xbmc.LOGWARNING)
            return 0

    def _epgCacheRead(self, import_id):
        """
        Hydrate `epg_pairs` from the per-import cache file.

        Returns the list of (kind, dict) tuples on success, or None if the
        cache is absent, unreadable, or yields zero pairs (treated as
        corrupt — `parseExternalSource` returns silently on `ParseError`,
        so an empty result indicates the file is unusable). The caller's
        304 branch interprets None as "cache miss → clear validators so
        next cycle force-fetches".
        """
        if not import_id:
            return None
        path = self._epgCachePath(import_id)
        try:
            if not os.path.exists(path):
                return None
        except Exception:
            return None
        try:
            pairs = list(self.parseXMLTV(path))
        except Exception as e:
            self.log('_epgCacheRead, [%s] parse raised: %s' % (import_id, e),
                     level=xbmc.LOGWARNING)
            return None
        if not pairs:
            self.log('_epgCacheRead, [%s] cache yielded 0 pairs (treating as corrupt)'
                     % (import_id,), level=xbmc.LOGWARNING)
            return None
        return pairs

    def _hasCachedGuide(self, import_id):
        """imports.56: True when the per-import guide cache holds a non-stub
        file — i.e. this import has had a guide before. Stat only; the
        parse happens in the sync this enables."""
        try:
            path = self._epgCachePath(import_id)
            return os.path.exists(path) and os.path.getsize(path) >= _DISK_PRESENCE_EPG_MIN_BYTES
        except Exception:
            return False

    def _guideNeedsSelfHeal(self, import_cfg, existing_channels):
        """imports.56: True when this import should be force-synced because
        its guide is missing from the guide data about to be written.

        Requires all of: the import is enabled and has a guide source; it
        has at least one live channel (enabled, allocated, not orphaned —
        a guide for nothing is legitimately empty); NOT ONE of its
        programmes is in self.xmltv; it has had a guide before (cache file
        present — rules out imports that never matched anything); and no
        self-heal for it in the last GUIDE_SELFHEAL_MIN_INTERVAL_SEC.
        Cheap checks run first; the programme scan stops at the first hit.

        imports.59 (S11): only a programme that hasn't ended counts (an
        unreadable stop still counts). Linked replay history is now kept for
        up to 7 days, and a slice holding only past shows must not hide a
        missing guide.
        """
        iid = import_cfg.get('id')
        if not iid or not import_cfg.get('enabled', True):
            return False
        if not (import_cfg.get('epg_url') or import_cfg.get('epg_path')):
            return False
        if self.xmltv is None:
            return False
        if not any(c.get('import_source') == iid
                   and c.get('enabled', True)
                   and not c.get('is_orphan')
                   and not c.get('unallocated')
                   for c in (existing_channels or [])):
            return False
        suffix = '@%s' % iid
        now = time.time()
        for p in (self.xmltv.XMLTVDATA.get('programmes') or []):
            ch = p.get('channel')
            if isinstance(ch, str) and ch.endswith(suffix):
                stop = replay_helpers.xmltv_to_epoch(p.get('stop'))
                if stop is None or stop > now:
                    return False
        if not self._hasCachedGuide(iid):
            return False
        last = _GUIDE_SELFHEAL_LAST.get(iid)
        if last and 0 <= now - last < GUIDE_SELFHEAL_MIN_INTERVAL_SEC:
            return False
        _GUIDE_SELFHEAL_LAST[iid] = now
        return True

    def _linksFileState(self, import_cfg, existing_channels):
        """imports.59 (S17) / imports.70 (c): (True, state) for an import that
        uses link-based replay -- a known exporter (replay_helpers.exporter_for)
        and stored channel records with link replay (link_replay_days) --
        where state is its replay-links file's (size, mtime_ns) from one
        os.stat (_localFileState, never xbmcvfs.Stat), or None when it can't
        be stat'ed. (False, None) for any other import. Errors propagate to
        the caller's own handler."""
        exporter = replay_helpers.exporter_for(import_cfg)
        iid = import_cfg.get('id')
        if exporter is None or not iid:
            return False, None
        records = [c for c in (existing_channels or ())
                   if isinstance(c, dict) and c.get('import_source') == iid]
        if not replay_helpers.link_replay_days(records):
            return False, None
        return True, self._localFileState(exporter[2])

    def _linksChanged(self, import_cfg, existing_channels):
        """imports.59 (S17): True when an import that uses link-based replay
        has a replay-links file (its playlist add-on's guide export) other
        than the one last read: the exporter is known (replay_helpers.
        exporter_for), the import's stored channel records use link-based
        replay (link_replay_days), and the file's mtime_ns differs from the
        stored links_mtime_ns. Compared as decimal text: _readLinks stores a
        string, and a number stored before (or rounded by the dashboard's
        JavaScript) differs from the file's only when its digits do. Nothing
        stored differs too. One os.stat per cycle (_localFileState, never
        xbmcvfs.Stat). A missing file or any error gives False."""
        try:
            # imports.70: the checks live in _linksFileState, shared with
            # _linksWentStale (same calls, same order as before).
            uses, state = self._linksFileState(import_cfg, existing_channels)
            if not uses or state is None:
                return False
            return str(state[1]) != str(import_cfg.get('links_mtime_ns'))
        except Exception as e:
            self.log('[%s] _linksChanged, check failed: %s' % (import_cfg.get('id'), e),
                     level=xbmc.LOGWARNING)
            return False

    def _linksWentStale(self, import_cfg, existing_channels, now=None):
        """imports.70 (c): True when an import that uses link-based replay is
        due a sync because its replay-links file is too old to trust
        (replay_helpers.stale_after): the file became stale after the
        import's last sync (last_sync_at before the cut), or it is still
        stale and that sync is at least LINKS_STALE_RESYNC_SECS old -- the
        sync while stale, at each imports cycle (about hourly with a cycle of
        an hour or less). The file's own mtime (_linksFileState),
        else the stored links_mtime_ns. A missing time, any error: False.

        The caller (syncAll's gate) never asks for a switched-off or failing
        import, so the abandon check and the failure backoff rule those."""
        try:
            uses, state = self._linksFileState(import_cfg, existing_channels)
            if not uses:
                return False
            mtime_ns = state[1] if state is not None else import_cfg.get('links_mtime_ns')
            now = time.time() if now is None else now
            cut = replay_helpers.stale_after(mtime_ns, now)
            if cut is None:
                return False
            try:
                last = int(import_cfg.get('last_sync_at') or 0)
            except (TypeError, ValueError):
                last = 0
            return last < cut or now - last >= LINKS_STALE_RESYNC_SECS
        except Exception as e:
            self.log('[%s] _linksWentStale, check failed: %s' % (import_cfg.get('id'), e),
                     level=xbmc.LOGWARNING)
            return False

    def _staleCut(self, iid, res, now):
        """imports.70 (c): replay_helpers.stale_after for this sync's links file
        (res['updated_cfg']['links_mtime_ns']: this sync's stable read, else
        the stored one -- also on a read to retry, which records nothing), or
        None when the guard stays off -- the file is younger than
        LINKS_STALE_AFTER_S or its time is unknown, or this sync's guide is the
        saved copy (its download failed) and that copy, as syncOne found it
        before reading it (res['epg_cache_mtime']), isn't newer than the file.
        A read to retry is the caller's to handle (_mergeReplayLinks: no
        filter, but the gap fill still runs)."""
        cut = replay_helpers.stale_after(res['updated_cfg'].get('links_mtime_ns'), now)
        if cut is None or not res.get('epg_error'):
            return cut
        cached = res.get('epg_cache_mtime')
        if cached is None or cached <= cut - replay_helpers.LINKS_STALE_AFTER_S:
            self.log("syncAll, [%s] replay links file is stale, but this sync's guide is the saved copy "
                     "from before it -- the export keeps its schedule" % (iid,), level=xbmc.LOGINFO)
            return None
        return cut

    def _mergeLinksIntoKept(self, iid, res, all_imported_now, published_logos):
        """imports.59 (S10.3, R2C-2): on the keep-previous paths (guide
        unavailable, nothing matched), this sync's replay links are still
        merged -- into the kept slice, which serves as both the details
        source and the history -- and the import's slice is replaced with the
        result. Without this, a links file read on these paths would not
        reach the guide until the import's next sync: its links_mtime_ns is
        saved, so the new-links trigger doesn't read it again. On a merge
        error the kept slice stays as it is, and that file's links wait for
        the import's next sync or a new export (see _readLinks)."""
        if res.get('links') is None or self.xmltv is None:
            return
        suffix = '@%s' % iid
        xtv_c = self.xmltv.XMLTVDATA.setdefault('channels', [])
        xtv_p = self.xmltv.XMLTVDATA.setdefault('programmes', [])
        kept_c = [c for c in xtv_c if _ofImport(c.get('id'), suffix)]
        kept_p = [p for p in xtv_p if _ofImport(p.get('channel'), suffix)]
        try:
            merged = self._mergeReplayLinks(iid, res, all_imported_now, published_logos, kept_c, kept_p)
        except Exception as e:
            self.log('syncAll, [%s] replay links merge into the kept guide failed (%s) — kept guide unchanged'
                     % (iid, e), level=xbmc.LOGERROR)
            return
        if merged is None:
            return
        new_chans, new_progs = merged
        xtv_c[:] = [c for c in xtv_c if not _ofImport(c.get('id'), suffix)]
        xtv_p[:] = [p for p in xtv_p if not _ofImport(p.get('channel'), suffix)]
        xtv_c.extend(new_chans)
        xtv_p.extend(new_progs)

    def _mergeReplayLinks(self, iid, res, all_imported_now, published_logos, guide_chans, guide_progs,
                          fresh_path=False):
        """imports.59 (S10.3): merge this sync's replay links (res['links'],
        _readLinks) into one import's guide with replay_helpers.
        merge_replay_guide. Returns (channel elements, programmes) to publish
        for the import, or None when it has no live link-replay channel.

        guide_chans / guide_progs -- the guide source's matched entries (the
            fresh path) or the kept slice (keep-previous paths); ids already
            namespaced. Not modified.
        The export's programmes and channels are mapped to namespaced ids by
        the exact tvg-id (res['epg_id_map']) -- only the import's live
        link-replay channels (link_replay_days, which also gives each one's
        replay window). The replay history is this import's programmes in
        the guide data as loaded (self.xmltv), read before any prune.

        fresh_path -- imports.70: True on the fresh-guide path only (the
            caller in syncAll's XML branch). There, (a) a new guide address
            (syncOne's epg_source_changed) re-describes the shows that
            haven't started (merge_replay_guide's redescribe), and (c) a
            stale links file (_staleCut) gives way to the guide source:
            replay_helpers.stale_export_filter on the merge's inputs, then
            fill_gaps on its output, with the very same guide_progs objects
            (fill_gaps finds the published ones by identity). On a read to
            retry (res['links']['retry']: the file changed while it was read,
            a file too young to parse yet, or the read failed) there is no
            listing to judge by -- the filter would drop every covered
            upcoming link, just as Movistar+ writes its new file -- so it
            waits for the next read and the links already in the guide stay;
            fill_gaps still runs, so the pieces the last guarded sync filled
            in come back (the merge never republishes unlinked copies) and the
            channel's replay on/off stays as it was. On the
            keep-previous paths (_mergeLinksIntoKept) the kept slice is both
            the details source and the history, so there is no independent
            schedule to re-describe from or give way to: neither applies.

        Channel element of a merged channel: the guide source's (davidmuma),
        else the export's (e.g. a channel only the export covers), else the
        kept one -- with the imports.58 _guideIcon rule."""
        records = [c for c in all_imported_now.values() if c.get('import_source') == iid]
        days_by_channel = replay_helpers.link_replay_days(records)
        if not days_by_channel:
            return None
        id_map = res.get('epg_id_map') or {}
        links = []
        link_chans = {}
        for kind, item in (res.get('links') or {}).get('pairs') or ():
            if kind == 'programme':
                ns_id = id_map.get(item.get('channel'))
                if ns_id in days_by_channel:
                    links.append(dict(item, channel=ns_id))
            elif kind == 'channel':
                ns_id = id_map.get(item.get('id'))
                if ns_id in days_by_channel:
                    link_chans[ns_id] = dict(item, id=ns_id)
        previous = [p for p in (self.xmltv.XMLTVDATA.get('programmes') or [])
                    if p.get('channel') in days_by_channel]
        prev_chans = {c.get('id'): c for c in (self.xmltv.XMLTVDATA.get('channels') or [])
                      if c.get('id') in days_by_channel}
        now = int(time.time())
        redescribe, cut, guard = False, None, None
        if fresh_path:
            redescribe = bool(res.get('epg_source_changed'))
            cut = self._staleCut(iid, res, now)
            if cut is not None and not (res.get('links') or {}).get('retry'):
                # imports.70 (c): on the merge's INPUTS -- the export's slots and
                # the published copies of the stale file's shows.
                links, previous, guard = replay_helpers.stale_export_filter(guide_progs, links, previous,
                                                                            days_by_channel, cut)
        programmes, stats = replay_helpers.merge_replay_guide(guide_progs, links, previous,
                                                              days_by_channel, now, redescribe=redescribe)
        if cut is not None:
            # imports.70 (c): on the merge's OUTPUT -- the rest of a guide show
            # that a kept slot cut short, so the hand-over leaves no hole. Only
            # unlinked copies of guide programmes of channels already in
            # guide_chans, so the channel elements below are unaffected. Also
            # on a read to retry (no filter): see fresh_path above.
            programmes, filled = replay_helpers.fill_gaps(programmes, guide_progs, days_by_channel, cut)
            if guard is None:
                self.log('syncAll, [%s] replay links file not read this sync -- the links already in the guide '
                         'stay and the stale-export guard waits for the next read; gaps filled=%d'
                         % (iid, filled), level=xbmc.LOGINFO)
            else:
                self.log('syncAll, [%s] replay links file is %.1f h old -- shows from %s follow the guide: '
                         'export yielded=%d agreeing=%d, history yielded=%d listed=%d, not covered=%d, '
                         'gaps filled=%d'
                         % (iid, (now - (cut - replay_helpers.LINKS_STALE_AFTER_S)) / 3600.0,
                            time.strftime('%Y-%m-%d %H:%M', time.localtime(cut)),
                            guard['export_yielded'], guard['export_agreeing'], guard['history_yielded'],
                            guard['history_listed'], guard['uncovered'], filled), level=xbmc.LOGINFO)
        have = {c.get('id') for c in guide_chans}
        extra = []
        for cid in sorted({p.get('channel') for p in programmes if p.get('channel') in days_by_channel} - have):
            chan = link_chans.get(cid) or prev_chans.get(cid)
            if chan is None:
                continue
            icon = self._guideIcon(all_imported_now.get(cid), published_logos.get(cid))
            if icon:
                chan['icon'] = [{'src': icon}]
            extra.append(chan)
        self.log('syncAll, [%s] replay links merged: channels=%d linked=%d with-details=%d kept-details=%d '
                 'overlap-details=%d titles-only=%d export=%d history=%d history-kept=%d unlinked=%d replaced=%d '
                 'redescribe-slots=%d'
                 % (iid, stats['channels'], stats['linked'], stats['with_content'], stats['kept_details'],
                    stats['overlap_details'], stats['plain'], stats['links_in'], stats['history_in'],
                    stats['history_kept'], stats['fresh_kept'], stats['fresh_dropped'],
                    stats['redescribe_slots']), level=xbmc.LOGINFO)
        return list(guide_chans) + extra, programmes

    # ------------------------------------------------------------------
    # imports.66: show pictures in the guide
    # ------------------------------------------------------------------
    # Some guide providers answer every show's picture link with one filler
    # image (epg.best serves a "BesTivi / Get it on Google Play" advert for
    # every show on its Spanish channels), and Kodi shows it like a real show
    # picture. syncAll compares up to 8 of each channel's show pictures about
    # once a day (_checkShowPictures) and records whether most of them are
    # one identical image (picture_helpers.judge); the choke point after its
    # XML loop then removes the
    # pictures of the channels that should not show them, so Kodi shows the
    # channel logo instead. The decisions themselves live in picture_helpers.

    def _savePictureVerdicts(self, verdicts):
        """imports.66: write the check results file through FileAccess.setJSON
        (temp file + os.replace, imports.59 S3), so loadPictureVerdicts never
        reads half a file. True when written. Never raises: after a failure
        (logged) the file keeps its previous content, and channels whose new
        result was lost are simply checked again at a later sync."""
        path = None
        try:
            path = _pictureVerdictsPath()
            if FileAccess.setJSON(path, verdicts):
                return True
            self.log('_savePictureVerdicts, could not write %s' % (path,), level=xbmc.LOGWARNING)
        except Exception as e:
            self.log('_savePictureVerdicts, could not write %s: %s' % (path, e), level=xbmc.LOGWARNING)
        return False

    def _pictureFingerprint(self, url):
        """imports.66: the sha256 hex digest of the first
        picture_helpers.FP_BYTES bytes of the picture at `url` (all of it when
        it is smaller), or None when it can't be read as a picture.

          - Only HTTP 200 with a Content-Type of image/* counts, so a host
            outage that answers every link with one error page can never
            look like a placeholder.
          - The body is streamed and read only that far. The response is used
            in a with-block, which closes it and releases the connection even
            though most of the body is never read (requests docs, "Body
            Content Workflow").
          - No retries; timeout=(5, 10): connecting, then between reads.
          - A failure is logged at DEBUG with the exception's type and the
            link's host only: a guide's picture links can carry access
            tokens, and an exception's message can quote the whole link."""
        host = '?'
        try:
            host = urllib.parse.urlsplit(url).hostname or '?'
            import requests
            limit = picture_helpers.FP_BYTES
            data = bytearray()
            with requests.get(url, headers={'User-Agent': _HTTP_USER_AGENT},
                              timeout=(5, 10), stream=True) as r:
                if r.status_code != 200:
                    self.log('_pictureFingerprint, picture from %s not used: HTTP %s' % (host, r.status_code))
                    return None
                media_type = (r.headers.get('Content-Type') or '').split(';', 1)[0].strip().lower()
                if not media_type.startswith('image/'):
                    self.log('_pictureFingerprint, picture from %s not used: not an image (%s)'
                             % (host, media_type or 'no content type'))
                    return None
                for chunk in r.iter_content(16384):
                    if chunk:
                        data.extend(chunk)
                        if len(data) >= limit:
                            break
            if not data:
                self.log('_pictureFingerprint, picture from %s not used: empty' % (host,))
                return None
            return hashlib.sha256(bytes(data[:limit])).hexdigest()
        except Exception as e:
            self.log('_pictureFingerprint, picture from %s not read: %s' % (host, e.__class__.__name__))
            return None

    def _checkShowPictures(self, iid, import_cfg, programmes, records_by_id, verdicts, now):
        """imports.66: the placeholder-picture check for one import, on its
        fresh guide `programmes` (namespaced channel ids) in syncAll. Records
        results in `verdicts` (in place) and returns
        {'checked': channels judged, 'placeholder': the ids judged
         placeholder, 'left': channels not reached or cut off, 'changed':
         whether `verdicts` changed, 'seconds': time spent}.

          - Nothing at all (no downloads) while the import's switch is off
            (picture_helpers.detect_enabled).
          - Candidates: the import's live channels (enabled, not orphaned,
            allocated) that are due a check (check_due: never checked, or
            checked MAX_AGE_S ago) and have at least MIN_SAMPLES show
            pictures to compare (pick_samples). Never-checked channels go
            first, then the oldest checks (due_order).
          - A channel's pictures are downloaded one at a time
            (_pictureFingerprint; a link already read in this call is not
            read again), and the channel stops as soon as the pictures not
            read yet can no longer change its result (picture_helpers.
            settled): with 8 samples, real pictures cost 6 downloads, a
            placeholder 5.
          - The result is picture_helpers.judge (most of the pictures one
            identical image = placeholder; a buffer keeps the previous
            result when it is one short), recorded with checked_at = now.
            "Can't tell" (too few pictures read) records nothing: the
            previous result stays and the channel is retried at the next
            sync.
          - A due channel with fewer than MIN_SAMPLES shows with pictures
            can't be judged from its guide; a placeholder result recorded
            earlier is dropped (pictures show again), a real one stays.
          - Before each channel: stop once BUDGET_S seconds have passed (so
            one slow picture host can't hold up the imports after this one).
            A started channel finishes, so every sync judges at least one;
            within it, only a hard stop at twice the budget and Kodi asking
            to stop (service._interrupt, as syncAll checks between imports)
            cut in. A channel cut off there is recorded only if its result
            is already settled; it and the channels not reached are left
            for a later sync."""
        summary = {'checked': 0, 'placeholder': [], 'left': 0, 'changed': False, 'seconds': 0.0}
        if not picture_helpers.detect_enabled(import_cfg):
            return summary

        due = set()
        for cid, rec in (records_by_id or {}).items():
            if not isinstance(rec, dict) or rec.get('import_source') != iid:
                continue
            if not rec.get('enabled', True) or rec.get('is_orphan') or rec.get('unallocated'):
                continue
            if picture_helpers.check_due(verdicts.get(cid), now):
                due.add(cid)
        if not due:
            return summary
        # One pass over the guide picks each due channel's own shows, instead
        # of one pass per channel (Movistar+ has ~50 channels and a week of
        # shows); pick_samples keeps only the channel's shows either way, so
        # the samples are the same.
        shows = {}
        for programme in programmes or ():
            cid = programme.get('channel') if isinstance(programme, dict) else None
            if isinstance(cid, str) and cid in due:
                shows.setdefault(cid, []).append(programme)
        samples_by_id = {}
        dropped = []
        for cid in due:
            samples = picture_helpers.pick_samples(shows.get(cid, ()), cid)
            if len(samples) >= picture_helpers.MIN_SAMPLES:
                samples_by_id[cid] = samples
                continue
            # Fewer than MIN_SAMPLES shows with pictures: the guide itself
            # can't be judged (not a failed download, which keeps the old
            # result). A placeholder result recorded earlier would otherwise
            # hide these few pictures for good -- the channel is never a
            # candidate again (epg.best removed its advert on 2026-11-09 and
            # left À Punt 1 pictured title, MTV 2). Drop it: back to "not
            # checked", so the pictures show; a real result hides nothing and
            # stays.
            previous = verdicts.get(cid)
            if isinstance(previous, dict) and previous.get('placeholder') is True:
                del verdicts[cid]
                dropped.append(cid)
                summary['changed'] = True
        if dropped:
            self.log('syncAll, [%s] show pictures: placeholder result dropped for %d channel(s) with fewer than %d pictured shows: %s'
                     % (iid, len(dropped), picture_helpers.MIN_SAMPLES, ', '.join(sorted(dropped))),
                     level=xbmc.LOGINFO)
        if not samples_by_id:
            return summary

        started = time.monotonic()
        deadline = started + picture_helpers.BUDGET_S
        # The budget is checked before a channel starts, so a started channel
        # finishes its reads (at most SAMPLES) and every sync judges at least
        # one channel, even from a picture host slow enough that the budget
        # wouldn't cover a whole channel (otherwise the same never-checked
        # channel would be cut off and go first again at every sync). Within a
        # channel only this hard stop and Kodi closing cut in.
        hard_stop = started + 2 * picture_helpers.BUDGET_S

        def _closing():
            return bool(self.service is not None and hasattr(self.service, '_interrupt')
                        and self.service._interrupt())

        fingerprints = {}   # {link: fingerprint, or None when unreadable} -- this call only
        stopped = False
        unsure = 0
        for cid in picture_helpers.due_order(list(samples_by_id), verdicts):
            if not stopped and (time.monotonic() >= deadline or _closing()):
                stopped = True
            if stopped:
                summary['left'] += 1
                continue
            previous = verdicts.get(cid)
            previous = previous.get('placeholder') if isinstance(previous, dict) else None
            samples = samples_by_id[cid]
            fps = []
            for url in samples:
                if url not in fingerprints:
                    if time.monotonic() >= hard_stop or _closing():
                        stopped = True
                        break
                    fingerprints[url] = self._pictureFingerprint(url)
                fps.append(fingerprints[url])
                if picture_helpers.settled(fps, len(samples) - len(fps), previous) is not None:
                    break
            if stopped:
                # Cut off: recorded only when the pictures not read can't
                # change the result; otherwise left for a later sync.
                verdict = picture_helpers.settled(fps, len(samples) - len(fps), previous)
                if verdict is None:
                    summary['left'] += 1
                    continue
            else:
                verdict = picture_helpers.judge(fps, previous)
            if verdict is None:
                unsure += 1
                continue
            verdicts[cid] = picture_helpers.make_verdict(verdict, now, sum(1 for fp in fps if fp))
            summary['changed'] = True
            summary['checked'] += 1
            if verdict:
                summary['placeholder'].append(cid)
        summary['seconds'] = time.monotonic() - started
        msg = ('syncAll, [%s] show pictures: checked %d channel(s) in %.1fs, placeholder: %s; %d left for a later sync'
               % (iid, summary['checked'], summary['seconds'], ', '.join(summary['placeholder']) or 'none',
                  summary['left']))
        if unsure:
            msg += '; %d with too few readable pictures (retried at the next sync)' % (unsure,)
        self.log(msg, level=xbmc.LOGINFO)
        return summary

    def cascadeAllocate(self, parsed_imports, existing_channels):
        """
        Greedy stable allocation per plan §4.

        parsed_imports: list of (import_cfg, list_of_parsed_channel_dicts)
                        in priority order (top = highest priority).
        existing_channels: list of channel records from `channels.json`.

        Returns: dict {channel_id: assigned_number}.

        Algorithm:
          1. Hard pins first (PseudoTV-built channels + operator-pinned imports)
             populate `allocations` and can't be displaced.
          2. Sticky allocations from prior cycles (existing imported channels
             with `assigned_number` that aren't operator-pinned). Preserves
             channel numbers across source updates so MovistarPlus adding a
             channel doesn't renumber everything else.
          3. New source channels in priority order with first-free-slot scan.
             Order within a single import: by source `tvg_chno` (numeric)
             then by name — deterministic across runs (plan G2).

        Cap at CASCADE_OVERFLOW_LIMIT (plan H5): channels that exhaust the
        scan are returned with assigned_number=None — caller marks them
        `unallocated=True` and excludes from the M3U write.
        """
        allocations = {}     # number -> channel_id (so we can detect collisions)
        result      = {}     # channel_id -> number (return value)

        # Disabled imported channels go in this high range so they sort to the
        # bottom of the channel list AND don't block their previous slot from
        # being reused by other channels (operator request: disabled channels
        # should free their slot + get a new number).
        DISABLED_BUCKET_START = 9000

        def _claim(cid, n):
            allocations[n] = cid
            result[cid]    = n

        def _next_free_from(desired):
            """Walk up from desired to first free slot; cap at overflow limit."""
            n = max(1, int(desired))
            while n in allocations:
                n += 1
                if n > CASCADE_OVERFLOW_LIMIT:
                    return None
            return n

        # Index existing channels for O(1) lookup
        existing_by_id = {c.get('id'): c for c in (existing_channels or []) if c.get('id')}

        def _is_enabled(cid):
            """Per-channel enabled lookup; defaults to True for unknown ids."""
            ec = existing_by_id.get(cid)
            return True if ec is None else ec.get('enabled', True)

        # ---- 1. Hard pins (skip disabled — they free their slot) ----
        # PseudoTV-built channels (type != 'import'): their number is sacred.
        # Operator-pinned imported channels: 'number' is in operator_overrides.
        for c in (existing_channels or []):
            cid = c.get('id')
            if not cid:
                continue
            if not c.get('enabled', True):
                continue  # disabled channels don't claim slots
            n = c.get('number')
            if not isinstance(n, int) or n < 1 or n >= DISABLED_BUCKET_START:
                continue
            is_import = c.get('type') == 'import'
            is_pin    = (not is_import) or ('number' in (c.get('operator_overrides') or []))
            if is_pin and n not in allocations:
                _claim(cid, n)

        # ---- 2. Sticky allocations for non-pinned ENABLED imported channels ----
        # Each existing enabled import channel keeps its assigned_number if free.
        # Disabled channels are SKIPPED so their old slot becomes available.
        for c in (existing_channels or []):
            cid = c.get('id')
            if cid in result or not cid:
                continue
            if c.get('type') != 'import':
                continue
            if not c.get('enabled', True):
                continue  # disabled → step 4 (bucket)
            sticky = c.get('assigned_number')
            if isinstance(sticky, int) and 1 <= sticky < DISABLED_BUCKET_START and sticky not in allocations:
                _claim(cid, sticky)

        # ---- 3. Allocate new + sticky-collision-cascade for parsed sources ----
        for import_cfg, parsed_channels in (parsed_imports or []):
            if not import_cfg.get('enabled', True):
                continue
            respect_src = bool(import_cfg.get('respect_source_numbers', True))
            start_num   = int(import_cfg.get('start_num', 1) or 1)

            # Sort source channels deterministically: by source tvg_chno (int),
            # then by name. Sentinel `999999` for missing tvg_chno keeps them
            # at end of the source-numbers ordering — so they fall through to
            # auto-allocation logic below if respect_src is True.
            srcs = sorted(
                parsed_channels,
                key=lambda c: (
                    c.get('source_tvg_chno') if isinstance(c.get('source_tvg_chno'), int) else 999999,
                    c.get('name', ''),
                ),
            )
            for idx, src in enumerate(srcs):
                cid = src.get('id')
                if not cid or cid in result:
                    continue  # already allocated (sticky or hard pin)

                # Skip disabled channels — they go to the 9000+ bucket in step 4
                # (operator request: disabled channels free their live slot).
                if not _is_enabled(cid):
                    continue

                # Decide desired number.
                if respect_src and isinstance(src.get('source_tvg_chno'), int):
                    desired = src['source_tvg_chno']
                else:
                    # Auto-allocate from start_num. Multiple new channels all
                    # start at start_num; _next_free_from cascades them through
                    # the next available slots, naturally skipping anything
                    # already allocated (sticky / hard-pin / earlier-this-loop).
                    desired = start_num

                actual = _next_free_from(desired)
                if actual is None:
                    self.log('cascadeAllocate, [%s] exhausted scan past %d (no free slot)'
                             % (cid, CASCADE_OVERFLOW_LIMIT), level=None)
                    result[cid] = None  # caller marks unallocated
                    continue
                _claim(cid, actual)
                if actual != desired:
                    self.log('cascadeAllocate, [%s] cascaded %d -> %d (taken)' % (cid, desired, actual))

        # ---- 4. Disabled imported channels go to the 9000+ bucket ----
        # Every imported channel that's disabled (or whose import is disabled)
        # gets a number in DISABLED_BUCKET_START..CHANNEL_LIMIT. This keeps them
        # out of the live channel range AND makes them sort to the bottom of
        # any number-ordered display.
        disabled_n = DISABLED_BUCKET_START
        for c in (existing_channels or []):
            cid = c.get('id')
            if not cid or cid in result:
                continue
            if c.get('type') != 'import':
                continue
            # Walk to next free in disabled bucket
            while disabled_n in allocations and disabled_n <= CHANNEL_LIMIT:
                disabled_n += 1
            if disabled_n > CHANNEL_LIMIT:
                # Bucket full — leave unallocated
                result[cid] = None
                continue
            allocations[disabled_n] = cid
            result[cid] = disabled_n
            disabled_n += 1

        return result

    def reconcile(self, parsed_channels, existing_imported_channels, import_cfg):
        """
        Match parsed source channels against existing imported channels.

        Match key: namespaced channel `id` (which embeds source tvg-id +
        import_id). Two channels with the same id are the same channel
        across sync cycles, even if the source renamed `display-name` etc.

        Returns (new_channels, refreshed_channels, orphan_channels):
        - new_channels       — parsed channels NOT in existing (filtered
                               against `import_cfg['tombstones']`). imports.69:
                               a tombstoned id comes back only with
                               "Re-discover deleted channels" ticked
                               (`rediscover_deleted`), and then always as a
                               new channel; a dashboard Save never edits
                               tombstones
        - refreshed_channels — list of (existing_channel, parsed_channel)
                               pairs; caller merges parsed source-side fields
                               into existing, preserving operator-edited
                               fields named in `operator_overrides`
        - orphan_channels    — existing imported channels for THIS import
                               that are NOT in the parsed source (operator
                               decides keep-or-delete via UI in step 4)

        Source-side fields (always refreshed): source_url, source_tvg_chno,
        catchup-source. Display fields (name, logo, group) are refreshed
        ONLY if not in operator_overrides.
        """
        if not isinstance(parsed_channels, list):
            parsed_channels = list(parsed_channels)

        tombstones = set(import_cfg.get('tombstones') or [])
        # imports.69: "Re-discover deleted channels". Before, the box was stored
        # but never read.
        rediscover = bool(import_cfg.get('rediscover_deleted'))
        existing_by_id = {
            c.get('id'): c for c in (existing_imported_channels or [])
            if c.get('id')
        }
        parsed_ids = {c.get('id') for c in parsed_channels if c.get('id')}

        new_channels       = []
        refreshed_channels = []

        for src in parsed_channels:
            cid = src.get('id')
            if not cid:
                continue
            if cid in tombstones:
                if rediscover:
                    # imports.69: always a NEW channel (switched on when the
                    # cascade gives it a number, provider name and logo, no
                    # overrides), even when a stale copy of its record is
                    # still on disk: the new record replaces that copy in the
                    # sync's commit (it is in modified_ids), and the commit
                    # takes the id out of the tombstones in the same write.
                    self.log('reconcile, [%s] re-discovered (tombstoned, Re-discover ticked)' % cid)
                    new_channels.append(src)
                else:
                    self.log('reconcile, [%s] skipped (tombstoned)' % cid)
                continue
            if cid in existing_by_id:
                refreshed_channels.append((existing_by_id[cid], src))
            else:
                new_channels.append(src)

        # Orphans: existing imported channels that didn't appear in source.
        # madteevee (imports fork): tombstoned ids are NOT re-emitted as orphans.
        # Without this filter, the orphan delete endpoint (server.py:753) is a
        # no-op against the next syncAll cycle: the channel gets removed from
        # channelDATA, but reconcile re-classifies it as orphan because it's
        # in existing_imported_channels (which is loaded fresh from disk each
        # cycle) AND not in parsed_ids (because the source M3U doesn't have
        # it). syncAll then re-emits it via all_imported_now (imports.py:534-
        # 546) and setChannels' merge-on-write keeps it alive forever.
        # Treating tombstones as the persistent delete marker means once the
        # operator hits "🗑 Orphans" and the tombstone is recorded, the channel
        # is permanently gone. imports.69: it comes back only when "Re-discover
        # deleted channels" is ticked and the source lists it again (the loop
        # above); a dashboard Save never edits tombstones (before imports.69
        # every Save wiped them by accident). This filter keeps the FULL
        # tombstone set either way, so a tombstoned channel the source no
        # longer lists is still never re-emitted as an orphan.
        orphan_channels = [
            c for c in (existing_imported_channels or [])
            if c.get('id') and c.get('id') not in parsed_ids
            and c.get('id') not in tombstones
        ]
        tombstoned_orphans = [
            c for c in (existing_imported_channels or [])
            if c.get('id') and c.get('id') not in parsed_ids
            and c.get('id') in tombstones
        ]

        self.log('reconcile, new=%d refreshed=%d orphan=%d (tombstoned=%d, tombstoned-and-still-on-disk=%d)'
                 % (len(new_channels), len(refreshed_channels),
                    len(orphan_channels), len(tombstones), len(tombstoned_orphans)))

        return new_channels, refreshed_channels, orphan_channels


    def applyRefresh(self, existing_channel, parsed_channel):
        """
        Merge parsed source-side fields into an existing channel record,
        preserving operator-edited fields.

        Returns the merged dict (mutates `existing_channel` in place too).

        Source-side ALWAYS refreshed: source_url, source_name (imports.59),
        source_tvg_chno, catchup-source, catchup-days, catchup-correction,
        provider, provider-type, provider-logo, kodiprops, extvlcopt, webprops.

        Display fields refreshed ONLY if NOT in operator_overrides:
        name, logo, group, catchup, radio.

        `operator_overrides` is the authoritative list of fields the
        operator has manually edited; their values stick across syncs.
        """
        overrides = set(existing_channel.get('operator_overrides') or [])

        # Always-refreshed (source-side identity / playback fields).
        # imports.59 (S18): source_name too -- the playlist's own name, kept
        # current even when the operator renamed the channel.
        for k in ('source_url', 'source_name', 'source_tvg_chno', 'catchup-source',
                  'catchup-days', 'catchup-correction', 'provider',
                  'provider-type', 'provider-logo', 'kodiprops',
                  'extvlcopt', 'webprops', 'tvg-shift', 'media-dir',
                  'media-size', 'x-playlist-type'):
            if k in parsed_channel:
                existing_channel[k] = parsed_channel[k]

        # Conditionally-refreshed (display fields — operator may have edited)
        for k in ('name', 'logo', 'group', 'catchup', 'radio', 'realtime', 'media'):
            if k not in overrides and k in parsed_channel:
                existing_channel[k] = parsed_channel[k]

        # Re-mark not-orphan (the source returned this channel)
        existing_channel['is_orphan'] = False
        return existing_channel
