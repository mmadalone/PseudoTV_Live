#   Copyright (C) 2025 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.
#
# -*- coding: utf-8 -*-
from globals    import *
from cqueue     import *
from overlay    import Background, Overlay, Replay
from rules      import RulesList
from tasks      import Tasks
from jsonrpc    import JSONRPC
import playstate_helpers # madteevee (imports fork, imports.60): Rollback_Watched snapshot/restore
import restart_helpers   # madteevee (imports fork, imports.62): restart from the beginning (pop-up, remote, guide entry)
import clock_helpers     # madteevee (imports fork, imports.63): the one clock + time conversions
import onnext_helpers    # madteevee (imports fork, imports.64): Up next drawn on the video
import rulestate_helpers # madteevee (imports fork, imports.65): channel player rules = settings + the tuned channel's rules
import livesubs_helpers # madteevee (imports fork, imports.67): LiveTV subtitles follow the channel
import replayend_helpers # madteevee (imports fork, imports.70): LiveTV replays frozen at their end move on
from logger import notice # madteevee (imports fork, imports.70): the replay-end watcher's lines that Kodi's log always gets
import loopguard_helpers # madteevee (imports fork, imports.71): which failures of the service's loops reach Kodi's log

class Player(xbmc.Player):
    # imports.16: pendingItem / playingItem live as instance attrs (set in
    # __init__). Class-level mutable defaults are a Python footgun — if Player
    # were ever instantiated more than once (test fixture, future refactor)
    # the dicts would silently share state across instances.
    background        = None
    overlay           = None
    # v.26: chid the current overlay was opened for. Used by toggleOverlay
    # for idempotency (no-op when overlay already shows the right channel)
    # and to force-rebuild on chid mismatch (recovers from the chkOverlay-vs-
    # _onPlay race during fast zaps that captured a stale citem snapshot).
    _overlay_chid     = None
    # imports.18: serializes toggleOverlay reads/writes of self.overlay across
    # threads. Without this, two threads (e.g., _onPlay @threadit worker AND
    # _chkIdle's __chkOverlay) could both see self.overlay = None, both create
    # an Overlay, both assign self.overlay. The first Overlay's channelBug
    # control gets orphaned in xbmcgui.Window(12005) — its instance ref is
    # overwritten, but the Kodi-side control persists for the rest of the
    # session. Operator-visible symptom: the previous channel's logo sticks on
    # top of the current channel. Class-level Lock is fine (one Player
    # instance only); separate from _state_lock-style globals on principle.
    _overlay_lock     = Lock()
    replay            = None
    runActions        = None
    lastSubState      = False
    # madteevee: smart-subtitle policy state. Set by ForceSubtitles.runAction on
    # RULES_ACTION_PLAYER_START (channel tune). One of 'legacy' / 'always_on' /
    # 'always_off' / 'smart'. 'legacy' preserves the pre-fork behavior so channels
    # without the new options behave exactly as before.
    smartSubsMode     = 'legacy'
    
    #global rules
    enableOverlay     = SETTINGS.getSettingBool('Overlay_Enable')
    infoOnChange      = SETTINGS.getSettingBool('Enable_OnInfo')
    disableTrakt      = SETTINGS.getSettingBool('Disable_Trakt')
    rollbackPlaycount = SETTINGS.getSettingBool('Rollback_Watched')
    minDuration       = SETTINGS.getSettingInt('Seek_Tolerance')
    maxProgress       = SETTINGS.getSettingInt('Seek_Threshold')
    sleepTime         = SETTINGS.getSettingInt('Idle_Timer')
    runWhilePlaying   = SETTINGS.getSettingBool('Run_While_Playing')
    replayPercentage  = SETTINGS.getSettingInt('Replay_Percentage')
    OnNextMode        = SETTINGS.getSettingInt('OnNext_Mode')
    onNextPosition    = SETTINGS.getSetting("OnNext_Position_XY")	
    
    """ 
    Player() Trigger Order
    Player: onPlayBackStarted
    Player: onAVChange (if playing)
    Player: onPlayBackEnded (if playing)
    Player: onAVStarted
    Player: onPlayBackSeek (if seek)
    Player: onAVChange (if changed)
    Player: onPlayBackError
    Player: onPlayBackEnded
    Player: onPlayBackStopped
    """
    
    def __init__(self, monitor=None, service=None):
        xbmc.Player.__init__(self)
        self.monitor     = monitor
        self.service     = service
        self.jsonRPC     = service.jsonRPC
        self.pendingItem = {}
        self.playingItem = {}
        # imports.47: transition-supervisor state. _play_started is stamped by
        # onAVStarted and read by _onChange to measure how long the just-ended
        # programme actually ran (loop-breaker short-play detection). _short_plays
        # is the consecutive-short-play counter; resets on a normal-length play.
        self._play_started = 0
        self._short_plays  = 0
        # madteevee (imports fork, imports.60): Rollback_Watched as an exact undo.
        # Every decision (what to snapshot, who owns it, what to send) lives in
        # playstate_helpers.PlaystateTracker, which has its own lock; this class
        # only supplies the Kodi I/O (_readPlaystateDetails, _playstateFile,
        # sendJSON) and calls _syncPlaystate from the player events.
        self.playstate = playstate_helpers.PlaystateTracker(read_details=self._readPlaystateDetails,
                                                            playing_file=self._playstateFile,
                                                            send=self.jsonRPC.sendJSON,
                                                            log=self._playstateLog)
        # madteevee (imports fork, imports.62): restart from the beginning (restart_helpers).
        # _play_epoch counts playback changes (started, AV started, ended, stopped, error),
        # so the pop-up and a restart can tell that what they were for no longer plays.
        # _retune marks the next tune after a Stop: it counts as a fresh tune, so the
        # channel's rules run again even on the same channel (imports.65).
        # _pendingRestart is a guide-entry restart of a Custom channel waiting for its tune.
        # _restart_lock lets one restart run at a time (@threadit alone doesn't serialize).
        # _play_stops / _play_errors count stop and error events, so a LiveTV restart can
        # tell a viewer's Stop from a replay that failed to open.
        self._play_epoch     = 0
        self._retune         = False
        self._pendingRestart = None
        self._restart_lock   = Lock()
        self._play_stops     = 0
        self._play_errors    = 0
        # madteevee (imports fork, imports.65): the rule-controlled values (rulestate_helpers)
        # always equal effective(settings, _rulesOverrides). Only _applyChannelRules,
        # _releaseChannelRules, _refreshChannelRules and _rollbackSwitched write them, each
        # under _rules_lock, which covers setting reads, dict work and attribute writes only
        # (never rule code, UI, JSON-RPC or another lock). _rulesOverrides is what the last
        # tuned Custom channel's rules set ({} after a hand-over); _rulesBaseline is the
        # settings last published (None before the first write).
        self._rules_lock     = Lock()
        self._rulesOverrides = {}
        self._rulesBaseline  = None
        # madteevee (imports fork, imports.67): LiveTV subtitles follow the channel (livesubs_helpers).
        # _liveSubs is the remembered on/off per LiveTV channel ({key: bool}, the memory file,
        # loaded once here). _liveSubsState is the settled LiveTV playback the monitor may record
        # for ({'epoch','key','seed','baseline'}), None until _restoreLiveSubtitles settles one.
        # No lock: both are only ever replaced whole (an atomic reference swap; the memory is
        # copied on write by livesubs_helpers.remember). The monitor thread (_chkLiveSubtitles)
        # is the only writer of the memory and its file; the _onPlay worker only reads the
        # memory, and every reader checks the state's epoch against _play_epoch.
        self._liveSubs       = self._loadLiveSubs()
        self._liveSubsState  = None
        # madteevee (imports fork, imports.68): LiveTV audio follows the channel. _liveAudio is the
        # language that last played per LiveTV channel ({key: code}, its own memory file, loaded
        # once here); the settled playback's audio fields ride on _liveSubsState. Same rule as
        # _liveSubs: only ever replaced whole (copied on write by livesubs_helpers.remember_audio),
        # the monitor thread is its only writer, the _onPlay worker only reads it.
        self._liveAudio      = self._loadLiveAudio()
        # madteevee (imports fork, imports.70): LiveTV replays frozen at their end move on
        # (replayend_helpers). _replayEndFacts is the watched replay's show ({'epoch','broadcastid',
        # 'channelid','start','end','endtime'}), written only by the _lookupReplayEnd worker;
        # _replayEndTrack is the tick's count (replayend_helpers.new_track), written only by
        # _chkReplayEnd on the monitor thread. No lock: both are only ever replaced whole, and both
        # carry the playback number (epoch), so nothing acts on another playback's record.
        self._replayEndFacts = None
        self._replayEndTrack = None


    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)


    def notice(self, msg):
        # madteevee (imports fork, imports.70): a line Kodi's log always gets (logger.notice), for
        # the replay-end watcher only: what it watches and what it did must be readable on a box
        # that runs without the add-on's debug logging (the 2026-11-19 TV test left no line).
        return notice('%s: %s'%(self.__class__.__name__,msg))


    def onPlayBackStarted(self):
        self._play_epoch += 1 # madteevee (imports fork, imports.62)
        self.pendingItem.update({'invoked':-1,'pending':False,'item':{},'last':self.pendingItem.get('item',{})})
        self.log('onPlayBackStarted, pendingItem = %s'%(self.pendingItem))


    def onAVChange(self):
        self.pendingItem.update({'resume':-1,'seek':-1,'item':{}})
        self.log('onAVChange, playingItem = %s'%(self.playingItem))

        
    def onAVStarted(self):
        # _tune_ts filter (madteevee fork): drop stale onAVStarted events from aborted fast-zap
        # tunes. Kodi back-fills onAVStarted in load-finish order, not user-zap order, so the
        # LAST event often corresponds to the FIRST tune in a CH+/CH- burst. Without this guard
        # player state anchors to the wrong channel; the overlay logo locks to it; and end-of-
        # programme PlayMedia(callback) routes to the wrong channel. _max_tune_ts is monotonic
        # and survives across onPlayBackStarted (which clears item/last but leaves it intact).
        newItem = self.getplayingItem()
        if newItem.get('isPseudoTV', False):
            new_ts = newItem.get('_tune_ts', 0)
            cur_ts = self.pendingItem.get('_max_tune_ts', 0)
            if new_ts and cur_ts and new_ts < cur_ts:
                self.log('onAVStarted, IGNORING stale event: _tune_ts=%.3f < max=%.3f (chid=%s, vid=%s)'%(new_ts, cur_ts, newItem.get('chid'), newItem.get('vid')), xbmc.LOGWARNING)
                return
            if new_ts > cur_ts:
                self.pendingItem['_max_tune_ts'] = new_ts
        self.pendingItem.update({'invoked':-1,'pending':False,'item':newItem})
        # imports.47: stamp the play-start timestamp so the loop-breaker can later
        # measure how long this programme actually played. Set AFTER the _tune_ts
        # stale-event early-return above so aborted fast-zap tunes don't pollute it.
        self._play_started = time.time()
        self._play_epoch  += 1 # madteevee (imports fork, imports.62): after the stale-event filter
        self.log('onAVStarted, pendingItem = %s'%(self.pendingItem))
        self._onPlay(self.pendingItem.get('item',{}), self._play_epoch)
        
                
    def onPlayBackSeek(self, seek_time=None, seek_offset=None): #Kodi bug? `OnPlayBackSeek` no longer called by player during seek, issue limited to pvr?
        self.pendingItem.update({'invoked':-1,'pending':False,'item':{}})
        self.log('onPlayBackSeek, seek_time = %s, seek_offset = %s, playingItem = %s'%(seek_time,seek_offset,self.playingItem))
    
    
    def onPlayBackError(self):
        self._play_epoch += 1 # madteevee (imports fork, imports.62)
        self._play_errors += 1
        self.pendingItem.update({'invoked':-1,'pending':False,'item':{}})
        self.log('onPlayBackError, pendingItem = %s'%(self.pendingItem))
        self._onError(self.playingItem)


    def onPlayBackEnded(self):
        self._play_epoch += 1 # madteevee (imports fork, imports.62)
        self.pendingItem.update({'invoked':-1,'pending':False,'item':{}})
        self.log('onPlayBackEnded, pendingItem = %s'%(self.pendingItem))
        self._onChange(self.playingItem)


    def onPlayBackStopped(self):
        # madteevee (imports fork, imports.62): a tune after a Stop may offer the Restart
        # pop-up even on the same channel (programme changes end, they don't stop).
        self._play_epoch += 1
        self._play_stops += 1
        self._retune      = True
        self.pendingItem.update({'invoked':-1,'pending':False,'item':{}})
        self.log('onPlayBackStopped, pendingItem = %s'%(self.pendingItem))
        self._onStop(self.playingItem)


    def getplayingItem(self):
        playingItem = FileAccess._decodeString(self.getPlayerItem().getProperty('sysInfo'))
        # _decodeString returns '' (str) when the listitem has no sysInfo property — the case for
        # every non-pseudotv playback (Kodi library file, regular IPTV, addon-as-source, etc.).
        # Without this guard, the .get('chid','') call below raises AttributeError every time
        # onAVStarted fires for non-pseudotv content, and the resulting CPythonInvoker exception
        # corrupts service-thread state (downstream saveChanges/builder flows then deadlock).
        # Return an empty dict so callers see playingItem.get('isPseudoTV', False) == False and
        # take the non-pseudotv path cleanly.
        if not isinstance(playingItem, dict):
            return {}
        if '@%s'%(PSEUDOTV_SLUG) in playingItem.get('chid',''):
            playingItem['isPseudoTV'] = True
            playingItem['chfile']     = BUILTIN.getInfoLabel('Filename','Player')
            playingItem['chfolder']   = BUILTIN.getInfoLabel('Folderpath','Player')
            playingItem['chpath']     = BUILTIN.getInfoLabel('Filenameandpath','Player')
            playingItem['isfiller']   = self.isPlayingFiller()
            #playingItem from listitem maybe outdated, check with channels.json for fresh citem.
            playingItem.update({'fitem':combineDicts(playingItem.get('fitem',{}),Globals._decodePlot(BUILTIN.getInfoLabel('Plot','VideoPlayer')))})
            playingItem.update({'nitem':combineDicts(playingItem.get('nitem',{}),Globals._decodePlot(BUILTIN.getInfoLabel('NextPlot','VideoPlayer')))})
            playingItem.update({'citem':combineDicts(playingItem.get('fitem',{}).get('citem',{}),next((item for item in self.service.channels if item.get('id',-1) == playingItem.get('chid',0)),{}))})
            playingItem.get('fitem',{})['runtime'] = self.getPlayerTime()
            PROPERTIES.setProperty('lastPlayed.sysInfo',FileAccess._encodeString(playingItem))
        return playingItem
      
        
    def getPlayerItem(self):
        try: return self.getPlayingItem()
        except Exception:
            if not self.isPlaying(): return xbmcgui.ListItem()
            self.monitor.waitForAbort(1.0) 
            return self.getPlayerItem()
        
        
    def getPlayerFile(self):
        if self.isPlaying(): return self.getPlayingFile()
        else:                return self.playingItem.get('fitem',{}).get('file')


    def getPlayerTime(self):
        if self.isPlaying(): return (self.getTimeLabel('Duration') or self.getTotalTime())
        else:                return (self.playingItem.get('fitem',{}).get('runtime') or -1)
            
       
    def getPlayedTime(self):
        if self.isPlaying(): return (self.getTimeLabel('Time') or self.getTime()) #getTime retrieves Guide times not actual media time.
        else:                return -1
       
            
    def getRemainingTime(self):
        if self.isPlaying(): return self.getPlayerTime() - self.getPlayedTime()
        else:                return self.getTimeLabel('TimeRemaining')


    def getPlayerProgress(self):
        if self.isPlaying(): return abs(int((self.getRemainingTime() / self.getPlayerTime()) * 100) - 100)
        else:                return int((BUILTIN.getInfoLabel('Progress','Player') or '-1'))


    def getTimeLabel(self, prop: str='TimeRemaining') -> int and float: #prop='EpgEventElapsedTime'
        if self.isPlaying(): return timeString2Seconds(BUILTIN.getInfoLabel('%s(hh:mm:ss)'%(prop),'Player'))
        else:                return -1


    def isPlayingFiller(self):
        if self.isPlaying(): return isFiller({'genre':BUILTIN.getInfoLabel('Genre(comma)','VideoPlayer').split(',')})
        else:                return isFiller(self.playingItem.get('fitem',{}))
        
        
    def isNextFiller(self):
        if self.isPlaying(): return isFiller({'genre':BUILTIN.getInfoLabel('NextGenre(comma)','VideoPlayer').split(',')})
        else:                return isFiller(self.playingItem.get('nitem',{}))


    def isPseudoTV(self):
        return (self.playingItem.get('isPseudoTV') or False)


    def isPlayingPseudoTV(self):
        return (self.isPlaying() & self.isPseudoTV())


    def setSubtitles(self, state: bool=True):
        # madteevee: branches by ForceSubtitles Mode. 'legacy' keeps the
        # original behavior (read state arg, gate on HasSubtitles infolabel).
        # 'always_on' / 'always_off' apply a fixed policy regardless of state arg.
        # 'smart' reads the per-item plan written at build time and applies
        # audio/sub stream selection + visibility in one Player.GetProperties
        # roundtrip (retried up to 3x / 200ms when stream lists arrive late
        # post-onAVStarted). If no plan is present (e.g. fitem lacks
        # streamdetails — fillers, recent-add lag), falls through to legacy.
        mode = getattr(self, 'smartSubsMode', 'legacy')
        if mode == 'always_on':
            has = BUILTIN.hasSubtitle()
            self.log('setSubtitles, mode=always_on hasSubtitle=%s'%(has))
            self.showSubtitles(bool(has))
            return
        if mode == 'always_off':
            self.log('setSubtitles, mode=always_off')
            self.showSubtitles(False)
            return
        if mode == 'smart':
            plan = ((self.playingItem.get('fitem') or {}).get('smart_subs') or None)
            if plan:
                self.log('setSubtitles, mode=smart APPLYING plan=%s'%(plan))
                self._applySmartSubsFromPlan(plan)
                return
            self.log('setSubtitles, mode=smart but no plan on fitem; falling through to legacy')
        # legacy
        hasSubtitle = BUILTIN.hasSubtitle()
        self.log('setSubtitles, mode=legacy state=%s hasSubtitle=%s'%(state, hasSubtitle))
        if not hasSubtitle: state = False
        self.showSubtitles(state)


    def _applySmartSubsFromPlan(self, plan):
        """
        Smart subtitle/audio application, driven by the per-item plan written at
        BUILD_FILELIST_POST by the ForceSubtitles rule. Reads available streams
        from Kodi via Player.GetProperties (one RPC with retry, since stream
        lists can lag onAVStarted by a few hundred ms), then issues at most one
        setAudioStream + one setSubtitleStream + one showSubtitles call.

        playerid is hardcoded to 1: this is the video player. _onPlay (the only
        caller path here) fires from onAVStarted on the video player.
        """
        try:
            # Fast paths that need no stream-list inspection
            sub_state         = bool(plan.get('sub_state'))
            sub_lang_target   = (plan.get('sub_lang_target')   or '').lower()
            audio_lang_target = (plan.get('audio_lang_target') or '').lower()
            if not sub_state and not audio_lang_target and not sub_lang_target:
                self.log('_applySmartSubsFromPlan, no-stream-info path: subs OFF', xbmc.LOGINFO)
                self.showSubtitles(False)
                return

            # Pull stream info — retry up to 3x with waitForAbort to respect shutdown
            props = None
            for attempt in range(3):
                resp = self.jsonRPC.sendJSON({
                    'method': 'Player.GetProperties',
                    'params': {
                        'playerid': 1,
                        'properties': ['audiostreams','currentaudiostream','subtitles','currentsubtitle','subtitleenabled'],
                    },
                })
                props = (resp or {}).get('result') or {}
                if props.get('audiostreams') or props.get('subtitles'):
                    break
                if self.service.monitor.waitForAbort(0.2): return

            if not props:
                self.log('_applySmartSubsFromPlan, Player.GetProperties returned empty after retries; falling through to legacy', xbmc.LOGWARNING)
                self.showSubtitles(sub_state if BUILTIN.hasSubtitle() else False)
                return

            from lang_codes import normalize_lang

            audio_streams = (props.get('audiostreams') or [])
            sub_streams   = (props.get('subtitles')   or [])
            self.log('_applySmartSubsFromPlan, runtime audio streams: %s'
                     % ([(s.get('index'), s.get('language'), s.get('name')) for s in audio_streams]))
            self.log('_applySmartSubsFromPlan, runtime sub streams:   %s'
                     % ([(s.get('index'), s.get('language'), s.get('name'), s.get('isforced')) for s in sub_streams]))

            # Audio switch (idempotent — skip when target already current)
            if audio_lang_target:
                cur = (props.get('currentaudiostream') or {})
                cur_lang = normalize_lang(cur.get('language'))
                if cur_lang != audio_lang_target:
                    idx = self._findStreamIdxByLang(audio_streams, audio_lang_target)
                    if idx is not None and 0 <= idx < len(audio_streams):
                        self.setAudioStream(idx)
                        self.log('_applySmartSubsFromPlan, switched audio: %s -> %s (idx=%s)'%(cur_lang, audio_lang_target, idx))

            # Sub stream + visibility
            if sub_state:
                if sub_lang_target:
                    idx = self._findStreamIdxByLang(sub_streams, sub_lang_target)
                    if idx is not None and 0 <= idx < len(sub_streams):
                        cur_sub = (props.get('currentsubtitle') or {})
                        cur_sub_idx = cur_sub.get('index') if isinstance(cur_sub, dict) else None
                        if cur_sub_idx != idx:
                            self.setSubtitleStream(idx)
                            self.log('_applySmartSubsFromPlan, set sub stream lang=%s idx=%s (was idx=%s)' % (sub_lang_target, idx, cur_sub_idx))
                self.showSubtitles(True)
                self.log('_applySmartSubsFromPlan, subs ON (lang=%s, rationale=%s)' % (sub_lang_target or '(default)', plan.get('rationale','')))
            else:
                self.showSubtitles(False)
                self.log('_applySmartSubsFromPlan, subs OFF (rationale=%s)'%(plan.get('rationale','')))
        except Exception as e:
            self.log('_applySmartSubsFromPlan, failed: %s'%(e), xbmc.LOGERROR)
            # graceful degrade
            try: self.showSubtitles(bool(plan.get('sub_state')))
            except Exception: pass


    @staticmethod
    def _findStreamIdxByLang(streams, target):
        if not target or not streams: return None
        from lang_codes import normalize_lang
        # Prefer isforced match for subtitles when multiple streams share the language
        forced_idx = None
        for s in streams:
            if normalize_lang(s.get('language','')) == target:
                if s.get('isforced'):
                    if forced_idx is None: forced_idx = s.get('index')
                else:
                    return s.get('index')
        return forced_idx


    @threadit
    def _onPlay(self, playingItem={}, epoch=None):
        self.log('_onPlay, playingItem = %s'%(playingItem))
        self.toggleInfo(False)
        self.toggleBackground(False)
        # madteevee (imports fork): split the overlay close into two cases to
        # avoid a race that left the previous channel's logo stuck on screen
        # during PseudoTV→PseudoTV zaps. Previously, `toggleOverlay(False)`
        # was the FIRST thing _onPlay did. Since _onPlay is @threadit (runs
        # on a separate thread), the main thread's __chkOverlay poll could
        # land between this close and the `self.playingItem = ...` update
        # below — at that moment self.overlay was None, the STALE
        # self.playingItem still had isPseudoTV=True with the OLD citem, so
        # __chkOverlay built a fresh Overlay snapshotting the OLD citem.
        # That overlay was the WRONG logo. The v.26 chid-aware idempotency
        # then locked it in (subsequent toggleOverlay calls saw
        # `_overlay_chid == current_chid` because both reflected the same
        # stale playingItem at the wrong moment).
        # Fix: for the PseudoTV→non-PseudoTV transition the close still
        # needs to happen up here (__chkOverlay never tells it to close
        # when state=True). For PseudoTV→PseudoTV the close is deferred
        # to AFTER playingItem updates, so __chkOverlay's chid-mismatch
        # branch closes and rebuilds with fresh data.
        if not playingItem.get('isPseudoTV'):
            # madteevee: extension to the v.26 zap-race fix. For PseudoTV→non-
            # PseudoTV transitions (IPTV import, addon source, library file)
            # we MUST update self.playingItem to the new (non-PseudoTV) item
            # BEFORE closing the overlay. Otherwise __chkOverlay (polling on
            # the idle thread) can land between the close below and a later
            # self.playingItem write: at that moment self.overlay = None AND
            # self.playingItem still has isPseudoTV=True with the OLD citem,
            # so __chkOverlay opens a new Overlay capturing the OLD logo.
            # That overlay then sits over the IPTV playback indefinitely —
            # and survives further channel tunes because subsequent
            # toggleOverlay calls see _overlay_chid matching the OLD chid
            # (the stale playingItem.citem at the moment Overlay was built).
            # The v.26 fix addressed the analogous PseudoTV→PseudoTV race;
            # this closes the symmetric gap for the non-PseudoTV destination.
            oldInfo = self.playingItem
            self.playingItem = playingItem
            # madteevee (imports fork, imports.60): PseudoTV handed over to other
            # playback. Kodi reuses the running player for the new file and sends
            # no stop, so the last PseudoTV programme is rolled back here (restore
            # only; a no-op when _onStop already did it).
            if oldInfo.get('isPseudoTV'): self._syncPlaystate(oldInfo)
            self.toggleOverlay(False)
            self.lastSubState = BUILTIN.isSubtitle()
            # madteevee (imports fork, imports.65): no Custom channel plays now, so its rules
            # stop applying: back to the settings (Kodi sends no stop on this hand-over).
            self._releaseChannelRules()
            # madteevee (imports fork, imports.62): the Restart pop-up for LiveTV channels
            # that can replay their show on now. LiveTV follows the global setting
            # (channel rule 54 belongs to Custom channels).
            self._retune = False
            self.toggleReplay(bool(SETTINGS.getSettingInt('Replay_Percentage')), epoch)
            # madteevee (imports fork, imports.67): a LiveTV channel (live or a replay) gets its
            # remembered subtitle on/off. Last, because it waits RECHECK_S for its re-check (this
            # is the @threadit worker, so no player callback waits for it).
            self._restoreLiveSubtitles(epoch)
            # imports.16: non-PTV path now early-returns. Previously the
            # method fell through to a redundant `else: self.playingItem =
            # playingItem` at the bottom — a second write of the same value.
            # Cleared stale pseudotv state then; cleared above the toggle now.
            return
        # PseudoTV path — non-PTV returned above
        self.lastSubState = BUILTIN.isSubtitle()
        retune, self._retune = self._retune, False # madteevee (imports fork, imports.62): see onPlayBackStopped
        oldInfo = self.playingItem
        # madteevee (imports fork, imports.65): a tune after a Stop is a tune: the channel's rules run again
        newChan = retune or oldInfo.get('chid',random.random()) != playingItem.get('chid')
        self.log('_onPlay, [%s], mode = %s, isPlaylist = %s, new channel = %s, retune = %s'%(playingItem.get('citem',{}).get('id'), playingItem.get('mode'), playingItem.get('isPlaylist',False), newChan, retune))
        if newChan: #New channel
            # madteevee (imports fork, imports.65): the channel's rules are worked out on a scratch
            # copy and published as settings + what they set, so no previous channel's value
            # (imports.62 rule 54, imports.64 rule 2, and every other player rule) carries over.
            self.playingItem = self._applyChannelRules(playingItem)
            # madteevee (imports fork, imports.60): roll back the previous programme and
            # snapshot this one. Started before the subtitle/overlay work so the snapshot
            # is read right after playback starts; the switch value is the one this
            # channel's start rules (rule 53) just applied.
            self._syncPlaystate(oldInfo, playingItem, bool(self.rollbackPlaycount))
            PROPERTIES.setTrakt(self.disableTrakt)
            self.setSubtitles(self.lastSubState) #todo allow rules to set sub preference per channel.
            self.toggleReplay(bool(self.replayPercentage), epoch)
            # Post-playingItem-update overlay refresh: now that
            # self.playingItem reflects the new channel, ask the overlay
            # to close-and-rebuild. The chid-aware check in toggleOverlay
            # will detect the mismatch with _overlay_chid (still set to
            # the OLD channel) and rebuild with fresh citem.
            self.toggleOverlay(self.enableOverlay)
        else: #New Program/Same Channel
            self.playingItem = playingItem
            self._syncPlaystate(oldInfo, playingItem, bool(self.rollbackPlaycount)) # madteevee (imports fork, imports.60): see the new-channel branch
            if playingItem.get('radio',False):
                BUILTIN.executebuiltin('Action(back)')
                BUILTIN.executewindow('ReplaceWindow(visualisation)')
            elif playingItem.get('isPlaylist',False):
                BUILTIN.executewindow('ReplaceWindow(fullscreenvideo)')
            # madteevee: per-program re-evaluation of smart subtitle/audio
            # policy. Gated to smart mode to keep legacy behavior identical
            # — without this, smart channels with mixed-language content
            # (e.g. anime ch with JA + EN-dubbed episodes interleaved) would
            # only re-evaluate at channel tune, not at each program transition.
            if getattr(self, 'smartSubsMode', 'legacy') == 'smart':
                self.setSubtitles(self.lastSubState)
            self.toggleInfo(self.infoOnChange)
            # madteevee (imports fork, imports.65): the add-on's own programme changes end the
            # previous file (no Stop), so they never offer the Restart pop-up. The same channel
            # tuned again after a Stop takes the new-channel branch (newChan above), which offers
            # it (imports.62) with the channel's own rule 54 value.
        # madteevee (imports fork, imports.62): a guide-entry restart of this channel was
        # waiting for this tune: jump to the start of the programme.
        self._restartPending(playingItem)
        # madteevee (imports fork, imports.60): quePlaycount removed (the rollback runs in
        # _syncPlaystate above); _setRuntime now only caches the player's runtime.
        self.jsonRPC._setRuntime(playingItem.get('fitem',{}),playingItem.get('fitem',{}).get('runtime'))


    # madteevee (imports fork, imports.67): LiveTV subtitles follow the channel. Kodi keeps video
    # settings per video and starts a video it has none for with the default (subtitles off on
    # this box); every replay (the RESTART pop-up, a guide replay, Kodi's "Play next programme
    # automatically") is a new video. The add-on remembers the on/off per LiveTV channel and
    # applies it whenever that channel plays. The decisions are in livesubs_helpers (tested
    # without Kodi); these methods only read Kodi, act and keep the memory file.
    def _liveSubsPath(self):
        # Built on every call (as imports.py's _pictureVerdictsPath), so tests can move CACHE_LOC.
        return FileAccess.translatePath(os.path.join(CACHE_LOC, livesubs_helpers.MEMORY_FILE))


    def _loadLiveSubs(self):
        # The usable entries of the memory file; {} when it is missing, unreadable or damaged.
        # Never raises (it runs in __init__). The lock-free read is safe: the only writer
        # replaces the file in one step (FileAccess.setJSON, imports.59 S3).
        path = None
        try:
            path   = self._liveSubsPath()
            memory = livesubs_helpers.valid_memory(FileAccess.getJSON(path))
        except Exception as e:
            self.log('_loadLiveSubs, could not read %s: %s'%(path, e), xbmc.LOGWARNING)
            return {}
        self.log('_loadLiveSubs, %s channel choice(s) remembered'%(len(memory)))
        return memory


    def _saveLiveSubs(self, memory):
        # Writes the memory file (temp file + os.replace). True when written. Never raises: after
        # a failure (logged) the file keeps its previous content; the memory in RAM still applies.
        path = None
        try:
            path = self._liveSubsPath()
            if FileAccess.setJSON(path, memory): return True
            self.log('_saveLiveSubs, could not write %s'%(path), xbmc.LOGWARNING)
        except Exception as e:
            self.log('_saveLiveSubs, could not write %s: %s'%(path, e), xbmc.LOGWARNING)
        return False


    # madteevee (imports fork, imports.68): LiveTV audio follows the channel. Kodi starts a replay
    # (a new video, no saved settings) in the preferred audio language and a live channel in the
    # audio it saved for it, so the same channel can play different languages live and in a
    # replay. The language that last played on each LiveTV channel is remembered in its own file
    # (the subtitle file's format stays untouched) and applied by the imports.67 restore; the
    # decisions are in livesubs_helpers. Same key, same single writer (the monitor thread).
    def _liveAudioPath(self):
        # imports.68: built on every call (as _liveSubsPath), so tests can move CACHE_LOC.
        return FileAccess.translatePath(os.path.join(CACHE_LOC, livesubs_helpers.AUDIO_MEMORY_FILE))


    def _loadLiveAudio(self):
        # imports.68: the usable entries of the audio memory file; {} when it is missing,
        # unreadable or damaged. Never raises (it runs in __init__), as _loadLiveSubs.
        path = None
        try:
            path   = self._liveAudioPath()
            memory = livesubs_helpers.valid_audio_memory(FileAccess.getJSON(path))
        except Exception as e:
            self.log('_loadLiveAudio, could not read %s: %s'%(path, e), xbmc.LOGWARNING)
            return {}
        self.log('_loadLiveAudio, %s channel language(s) remembered'%(len(memory)))
        return memory


    def _saveLiveAudio(self, memory):
        # imports.68: writes the audio memory file (temp file + os.replace). True when written.
        # Never raises, as _saveLiveSubs: after a failure (logged) the file keeps its previous
        # content and the memory in RAM still applies.
        path = None
        try:
            path = self._liveAudioPath()
            if FileAccess.setJSON(path, memory): return True
            self.log('_saveLiveAudio, could not write %s'%(path), xbmc.LOGWARNING)
        except Exception as e:
            self.log('_saveLiveAudio, could not write %s: %s'%(path, e), xbmc.LOGWARNING)
        return False


    def _liveSubsInfo(self):
        # Kodi read directly, not through BUILTIN.getInfoBool/getInfoLabel, which log every call
        # at debug level: _chkLiveSubtitles runs this about once a second during LiveTV.
        # imports.68: 'audio' is the playing audio track's language code ('eng'), the value the
        # audio memory keeps.
        return {'live'   : xbmc.getCondVisibility('Pvr.IsPlayingTv'),
                'epgtag' : xbmc.getCondVisibility('Pvr.IsPlayingEpgTag'),
                'number' : xbmc.getInfoLabel('VideoPlayer.ChannelNumberLabel'),
                'name'   : xbmc.getInfoLabel('VideoPlayer.ChannelName'),
                'current': xbmc.getCondVisibility('VideoPlayer.SubtitlesEnabled'),
                'has'    : xbmc.getCondVisibility('VideoPlayer.HasSubtitles'),
                'audio'  : xbmc.getInfoLabel('VideoPlayer.AudioLanguage')}


    def _liveSubsFile(self):
        # The playing file ('' when nothing plays): ties a settled state to the video it was
        # settled on (a replay of the same channel has the same channel labels).
        try: return self.getPlayingFile() or ''
        except Exception: return ''


    def _liveSubsChannels(self):
        # A fresh channel list for each LiveTV tune (Channels() reads channels.json), so a channel
        # imported or renamed since the service started resolves to its id; the service's list
        # when that read fails. madteevee (imports fork, imports.71): that list is refreshed every
        # 5 minutes (Tasks.chkServiceChannels) and after each settings save.
        try: return list(self.service.tasks.getChannels() or [])
        except Exception as e:
            self.log('_liveSubsChannels, channel list unavailable: %s'%(e), xbmc.LOGWARNING)
            return list(getattr(self.service, 'channels', None) or [])


    def _waitChannelPreview(self, epoch, limit=120.0):
        # Kodi's channel preview (Up/Down during live TV with "confirm channel switch" on) shows
        # the previewed channel's labels while the old one keeps playing. Waits until it ends, so
        # the labels read next are the playing channel's. A preview lasts as long as you browse
        # (the channel info stays up 5 s after each key here), so the cap is generous (`limit`
        # seconds); the playback number is checked on every pass, so a newer playback (you picked
        # a channel) ends the wait at once. False when a newer playback started, Kodi is closing
        # or the preview outlasts the cap.
        waited = 0.0
        while xbmc.getCondVisibility('Player.ChannelPreviewActive'):
            if self._play_epoch != epoch or waited >= limit or self.monitor.waitForAbort(0.25): return False
            waited += 0.25
        return self._play_epoch == epoch


    def _showLiveSubtitles(self, on, epoch):
        # "On" goes through the track: when a video starts with subtitles off, Kodi also disables
        # the subtitle track in the stream (inputstream.adaptive on Movistar+), and showSubtitles
        # (True) would only flip the visibility flag -- Kodi reports them on, nothing shows.
        # setSubtitleStream re-selects the track (reopening it) and makes it visible, as the OSD
        # does and as _applySmartSubsFromPlan does. "Off" is the visibility flag.
        # True when applied; False when a newer playback (another epoch) started first -- also
        # during the track read, which skips the RPC_Delay pause (delay=False) because the switch
        # follows it at once -- so a late call never lands on the next channel.
        if not on:
            if self._play_epoch != epoch: return False
            self.showSubtitles(False)
            return True
        resp  = self.jsonRPC.sendJSON({'method': 'Player.GetProperties',
                                       'params': {'playerid': 1, 'properties': ['subtitles', 'currentsubtitle']}},
                                      delay=False)
        if self._play_epoch != epoch: return False
        index = livesubs_helpers.subtitle_index((resp or {}).get('result'))
        if index is None: self.showSubtitles(True) # no track list from Kodi: the flag at least
        else:             self.setSubtitleStream(index)
        return True


    def _readAudioProps(self):
        # imports.68: the audio tracks Kodi lists for the playing video (index, language, flags)
        # and the current one, from JSON-RPC Player.GetProperties -- {} when Kodi gives none.
        # delay=False skips the RPC_Delay pause: a switch may follow at once (as in
        # _showLiveSubtitles). Its index is the one Player.setAudioStream takes.
        resp = self.jsonRPC.sendJSON({'method': 'Player.GetProperties',
                                      'params': {'playerid': 1, 'properties': ['audiostreams', 'currentaudiostream']}},
                                     delay=False)
        return (resp or {}).get('result') or {}


    def _applyLiveAudio(self, index, epoch):
        # imports.68: switches to audio track `index`. True when applied; False when a newer
        # playback (another epoch) started first -- checked right before the switch, so a late
        # call never lands on the next channel.
        if self._play_epoch != epoch: return False
        self.setAudioStream(index)
        return True


    def _restoreLiveSubtitles(self, epoch):
        # The end of _onPlay's LiveTV branch, on its @threadit worker. Applies the channel's
        # remembered on/off, checks once more after RECHECK_S (Kodi applies its per-video settings
        # before onAVStarted on the same queue, but that order couldn't be confirmed in Kodi's
        # queue code), then marks the playback settled so the monitor records your toggles.
        # A newer playback (another epoch) ends it at any step, and is checked again right before
        # each change, so a late worker never acts on the next channel. Never raises.
        try:
            # imports.67: a newer playback already started (this worker came late, e.g. after a slow
            # PseudoTV hand-over): its own _onPlay restores it, and clearing the state below would
            # cancel that playback's recording.
            if self._play_epoch != epoch: return
            self._liveSubsState = None # nothing is recorded until this playback is settled
            # imports.68: a channel preview (Up/Down while this channel still loads) shows another
            # channel's labels: the key read now would be that channel's, and its subtitle and audio
            # choice would be applied to this one. Waited out before anything is read.
            if not self._waitChannelPreview(epoch): return
            info = self._liveSubsInfo()
            if not livesubs_helpers.is_livetv(info['live'], info['epgtag'], False): return
            key = livesubs_helpers.channel_key(info['number'], info['name'], self._liveSubsChannels())
            if not key: return
            labels = (info['number'], info['name'])
            # imports.68: the video this restore is for. A RESTART pressed within the re-check
            # opens a replay of the same channel (same labels): it must not be settled on.
            file0  = self._liveSubsFile()
            saved  = self._liveSubs.get(key)
            act    = livesubs_helpers.restore_action(saved, info['current'], info['has'])
            if act is not None:
                if not self._showLiveSubtitles(act, epoch): return
                self.log('live subtitles: %s restored %s'%(key, 'on' if act else 'off'), xbmc.LOGINFO)
            # imports.68: the channel's remembered audio language, when the stream offers it and
            # another plays (the track list skips the RPC_Delay pause; the epoch is checked right
            # before the switch). Nothing is switched when the language isn't offered.
            saved_audio = self._liveAudio.get(key)
            props       = self._readAudioProps()
            idx         = livesubs_helpers.audio_restore_action(saved_audio, info['audio'], props)
            if idx is not None:
                if not self._applyLiveAudio(idx, epoch): return
                self.log('live audio: %s restored %s'%(key, saved_audio), xbmc.LOGINFO)
            # Always re-checked: with no restore above, a track that arrives late can still get "on".
            if self.monitor.waitForAbort(livesubs_helpers.RECHECK_S): return
            if not self._waitChannelPreview(epoch): return
            info = self._liveSubsInfo()
            if not livesubs_helpers.is_livetv(info['live'], info['epgtag'], False): return
            # The same channel (its name: Kodi's own running number can shift when the playlist
            # changes) and the same video.
            if info['name'] != labels[1] or self._liveSubsFile() != file0: return
            again = livesubs_helpers.restore_action(saved, info['current'], info['has'])
            if again is not None: # Kodi changed it after the first restore
                if not self._showLiveSubtitles(again, epoch): return
                self.log('live subtitles: %s re-applied %s'%(key, 'on' if again else 'off'), xbmc.LOGINFO)
            # imports.68: the audio re-check, once: Kodi may have put its own choice back.
            props       = self._readAudioProps()
            again_audio = livesubs_helpers.audio_restore_action(saved_audio, info['audio'], props)
            if again_audio is not None:
                if not self._applyLiveAudio(again_audio, epoch): return
                self.log('live audio: %s re-applied %s'%(key, saved_audio), xbmc.LOGINFO)
            if again is not None or again_audio is not None:
                # Kodi queues the change: read the state it left, not the one before it.
                # imports.68: one wait for either re-apply (subtitles, audio or both).
                if self.monitor.waitForAbort(livesubs_helpers.APPLY_WAIT_S): return
                info = self._liveSubsInfo()
                # imports.68: and the tracks after the audio switch, for the settle record below.
                if again_audio is not None: props = self._readAudioProps()
            if self._play_epoch != epoch: return
            # imports.68: the audio fields. 'audio' is the language playing now (the monitor's
            # baseline for a change), 'audio_forced' marks a language Kodi had to play, and
            # 'audio_pending' is the language to remember for this settle (or None; the monitor,
            # the memory's only writer, saves it at its first tick).
            # A live tune that lands on a show without the remembered language (a Spanish-only
            # show) plays another one because it has to, as when the language disappears mid-
            # playback: forced, so the monitor switches back once the next show offers it again
            # (Kodi itself keeps the stream it plays). Live only: a replay's tracks don't change.
            saved_offered = livesubs_helpers.audio_track(props, saved_audio) is not None
            forced        = (bool(info['live']) and not saved_offered and livesubs_helpers.lang_code(saved_audio)
                             not in ('', livesubs_helpers.lang_code(info['audio'])))
            self._liveSubsState = {'epoch'        : epoch,
                                   'key'          : key,
                                   'labels'       : labels,
                                   'file'         : file0,
                                   'has'          : bool(info['has']),
                                   'seed'         : bool(info['live']) and not isinstance(saved, bool),
                                   'baseline'     : bool(info['current']),
                                   'audio'        : info['audio'] or '',
                                   'audio_forced' : forced,
                                   'audio_pending': livesubs_helpers.audio_settle_record(
                                       saved_audio, info['audio'], saved_offered)}
        except Exception as e:
            self.log('_restoreLiveSubtitles, failed: %s'%(e), xbmc.LOGWARNING)


    def _chkLiveSubtitles(self):
        # Monitor thread, about once a second while no Custom channel plays (Monitor._chkIdle):
        # a subtitle toggle fires no player event, so a settled LiveTV playback is read here and
        # a change you make is remembered for its channel. Returns at once when no settled LiveTV
        # playback is current. The only writer of the memory and its file. Never raises.
        try:
            state = self._liveSubsState
            if not state or state.get('epoch') != self._play_epoch: return
            if not self.isPlayingVideo(): return
            # The channel preview shows another channel's labels: nothing to read until it ends.
            if xbmc.getCondVisibility('Player.ChannelPreviewActive'): return
            info = self._liveSubsInfo()
            if not livesubs_helpers.is_livetv(info['live'], info['epgtag'], False): return
            # Read again after the labels: a new playback that started meanwhile must not be
            # recorded as a change on this one (a replay of the same channel has the same key).
            if state.get('epoch') != self._play_epoch: return
            # The video and channel it was settled on: Kodi can show the next video (a RESTART
            # replay, its automatic next show) with its default a moment before the add-on hears
            # of it, and that default must not be saved as your choice for this channel.
            # The channel's name, not Kodi's own running number (it shifts when the playlist changes
            # mid-playback); the playing file (checked next) identifies the video.
            if info['name'] != (state.get('labels') or (None, None))[1]: return
            if self._liveSubsFile() != state.get('file'): return
            key = state.get('key')
            # imports.68: the audio memory, behind the same gates; the subtitle logic below goes on
            # with the state it leaves (a new dict when it changed one).
            state = self._chkLiveAudio(state, info, key)
            if info['has'] and not state.get('has'):
                # A subtitle track that appeared after the start: the channel's choice is applied
                # to it (it couldn't be at the start), not Kodi's off saved over it.
                act = livesubs_helpers.restore_action(self._liveSubs.get(key), info['current'], True)
                if act is not None:
                    try: applied = self._showLiveSubtitles(act, state.get('epoch'))
                    except Exception as e:
                        # Not retried every tick, and nothing more recorded for this playback:
                        # Kodi's value would be saved over the channel's choice.
                        if self._liveSubsState is state: self._liveSubsState = None
                        self.log('_chkLiveSubtitles, %s: the choice could not be applied to the new track: %s'%(key, e), xbmc.LOGWARNING)
                        return
                    if not applied: return
                    self.log('live subtitles: %s restored %s (track appeared)'%(key, 'on' if act else 'off'), xbmc.LOGINFO)
                    # Kodi queues the change: read the state it left (as the restore's re-apply).
                    if self.monitor.waitForAbort(livesubs_helpers.APPLY_WAIT_S): return
                    if state.get('epoch') != self._play_epoch: return
                    info = self._liveSubsInfo()
                if self._liveSubsState is state:
                    self._liveSubsState = dict(state, has=True, baseline=bool(info['current']))
                return
            value = livesubs_helpers.record_action(self._liveSubs.get(key), info['current'], info['has'],
                                                   state.get('seed'), state.get('baseline'))
            if value is None: return
            self._liveSubs = livesubs_helpers.remember(self._liveSubs, key, value)
            self._saveLiveSubs(self._liveSubs)
            # Only over the state read above: never over a newer playback's (or its None).
            if self._liveSubsState is state: self._liveSubsState = dict(state, seed=False, baseline=value)
            self.log('live subtitles: %s saved %s'%(key, 'on' if value else 'off'), xbmc.LOGINFO)
        except Exception as e:
            self.log('_chkLiveSubtitles, failed: %s'%(e), xbmc.LOGWARNING)


    def _chkLiveAudio(self, state, info, key):
        # madteevee (imports fork, imports.68): the audio part of _chkLiveSubtitles' tick, called
        # behind all its gates (settled epoch, no preview, LiveTV, same labels and file), on the
        # monitor thread -- the only writer of the audio memory and its file. Saves the language
        # the settle left to remember, then a change of the playing language (yours, or Kodi's
        # pick while the previous language is still offered); a change Kodi had to make (the
        # previous language disappeared) is only marked forced, and the remembered language is
        # switched back to once the stream offers it again. Returns the state to go on with: a
        # new dict when it replaced the current one, else `state` (a newer playback's state is
        # never overwritten). Raises into _chkLiveSubtitles' handler (one warning).
        pending = state.get('audio_pending')
        if pending:
            self._liveAudio = livesubs_helpers.remember_audio(self._liveAudio, key, pending)
            self._saveLiveAudio(self._liveAudio)
            self.log('live audio: %s saved %s'%(key, pending), xbmc.LOGINFO)
            if self._liveSubsState is not state: return state
            state = dict(state, audio_pending=None)
            self._liveSubsState = state
        playing = info['audio']
        code    = livesubs_helpers.lang_code(playing)
        if code and code != livesubs_helpers.lang_code(state.get('audio')):
            props = self._readAudioProps()
            # imports.68: the track list must be this playback's: a newer one that started during
            # the read would answer whether the previous language is offered for the wrong video.
            if state.get('epoch') != self._play_epoch: return state
            saved = self._liveAudio.get(key)
            if not livesubs_helpers.lang_code(state.get('audio')):
                # The first language Kodi shows after a settle without one (the label was still
                # blank): what the settle would have done, not a change -- a blank was never offered.
                offered = livesubs_helpers.audio_track(props, saved) is not None
                save    = livesubs_helpers.audio_settle_record(saved, playing, offered)
                forced  = bool(livesubs_helpers.lang_code(saved)) and not offered
            else:
                save, forced = livesubs_helpers.audio_change_record(
                    playing, state.get('audio'), livesubs_helpers.audio_track(props, state.get('audio')) is not None)
            # "Forced" only while there is a different remembered language to go back to;
            # otherwise the track list would be read every second for nothing.
            forced = bool(forced) and livesubs_helpers.lang_code(saved) not in ('', code)
            # imports.68: written only on change (as the subtitle memory): a change back to the
            # remembered language (Kodi's own after a forced one) ends "forced" but writes nothing.
            if save and livesubs_helpers.lang_code(save) != livesubs_helpers.lang_code(self._liveAudio.get(key)):
                self._liveAudio = livesubs_helpers.remember_audio(self._liveAudio, key, save)
                self._saveLiveAudio(self._liveAudio)
                self.log('live audio: %s saved %s'%(key, save), xbmc.LOGINFO)
            elif forced:
                self.log('live audio: %s forced to %s (not remembered)'%(key, playing.strip()), xbmc.LOGINFO)
            if self._liveSubsState is not state: return state
            # "Forced" carries on only while the remembered language isn't the one playing now
            # (Kodi may itself land on it when the show's languages change): otherwise nothing
            # is left to switch back to, and the track list would be read every second for nothing.
            carry = (state.get('audio_forced') and not save
                     and code != livesubs_helpers.lang_code(self._liveAudio.get(key)))
            state = dict(state, audio=playing, audio_forced=bool(forced or carry))
            self._liveSubsState = state
        elif state.get('audio_forced'):
            # imports.68: after a forced change, the remembered language back as soon as the stream
            # offers it again (the next show on live); _applyLiveAudio checks the epoch.
            props = self._readAudioProps()
            idx   = livesubs_helpers.audio_return_action(self._liveAudio.get(key), playing, props)
            if idx is not None and self._applyLiveAudio(idx, state.get('epoch')):
                self.log('live audio: %s switched back to %s'%(key, self._liveAudio.get(key)), xbmc.LOGINFO)
                # Kodi queues the switch: read the language it left, not the one before it.
                if self.monitor.waitForAbort(livesubs_helpers.APPLY_WAIT_S): return state
                # A newer playback that started during the wait isn't this one's language.
                if state.get('epoch') != self._play_epoch: return state
                playing = self._liveSubsInfo()['audio']
                if self._liveSubsState is not state: return state
                state = dict(state, audio=playing or state.get('audio'), audio_forced=False)
                self._liveSubsState = state
        return state


    @threadit
    def _onChange(self, playingItem={}):
        self.log('_onChange, playingItem = %s'%(playingItem))
        # madteevee (imports fork, imports.60): the programme reached its end. Kodi has
        # already saved its marks for the file, so roll it back now (restore only)
        # instead of waiting for the next playback.
        if playingItem.get('isPseudoTV'): self._syncPlaystate(playingItem)
        self.toggleOverlay(False)
        if playingItem:
            if not playingItem.get('isPlaylist',False):
                self.toggleBackground(self.enableOverlay)
                # v.46: guard against PlayMedia(None) after a stream-stall onPlayBackEnded.
                # When a VOD stream stalls mid-playback, Kodi fires onPlayBackEnded with the
                # listitem still in playingItem but `callback` never populated — _onIdle's
                # __chkCallback recovery (services.py:323) only runs in periodic ticks, not
                # on the synchronous EOF path. The bare `PlayMedia(%s)%None` formatting
                # produced the literal string "None" as the URL; Kodi logged
                # `VideoPlayer::OpenFile: None` → `OpenInputStream - error opening [None]`
                # → DialogConfirm "Playback failed. One or more items failed to play".
                # Fix: try the same getCallback recovery __chkCallback uses, and skip
                # PlayMedia entirely if it still resolves to falsy. The channel goes to
                # the background overlay instead of popping a user-facing error dialog.
                callback = playingItem.get('callback')
                if not callback:
                    callback = self.jsonRPC.getCallback(playingItem)
                    if callback: playingItem['callback'] = callback
                if callback:
                    # imports.47: transition supervisor — runaway loop-breaker + watchdog arm.
                    # Loop-breaker accounting: for PseudoTV non-filler items, measure how long
                    # the just-ended programme actually played (now - _play_started); a play
                    # shorter than Seek_Tolerance counts as "short" and increments _short_plays.
                    # Fillers are excluded (legitimately short) and so is non-PseudoTV content
                    # (so the supervisor never engages on library/IPTV playback).
                    if playingItem.get('isPseudoTV') and not playingItem.get('isfiller', False) and self._play_started > 0:
                        played = time.time() - self._play_started
                        if played < SETTINGS.getSettingInt('Seek_Tolerance'):
                            self._short_plays += 1
                            self.log('_onChange, [%s] short play: %.1fs < Seek_Tolerance — _short_plays=%s'%(playingItem.get('citem',{}).get('id'), played, self._short_plays))
                        else:
                            self._short_plays = 0
                    if playingItem.get('isPseudoTV') and self._short_plays >= TRANSITION_LOOP_THRESHOLD:
                        # Loop-breaker engaged: do NOT fire PlayMedia immediately. _chkTransition
                        # will fire it after the Playback_Timeout cooldown — calm spaced retries
                        # that naturally wait out the dead zone between a short file's end and
                        # its EPG slot's end. retune_attempts=0 because the watchdog cap is for
                        # true stalls (no onAVStarted), not the loop-breaker case where each
                        # cycle's onAVStarted resets it.
                        self.pendingItem.update({'invoked': time.time(), 'retune_cb': callback, 'retune_attempts': 0})
                        self.log('_onChange, [%s] runaway: %s consecutive short plays — deferring re-tune via Playback_Timeout cooldown'%(playingItem.get('citem',{}).get('id'), self._short_plays), xbmc.LOGWARNING)
                    else:
                        BUILTIN.executebuiltin('PlayMedia(%s)'%(callback))
                        self.log('_onChange, [%s], isPlaylist = %s, callback = %s'%(playingItem.get('citem',{}).get('id'),playingItem.get('isPlaylist',False),callback))
                        # Watchdog arm: only for PseudoTV items (non-PTV transitions stay byte-identical
                        # to pre-imports.47 — no arm, no _chkTransition involvement). Normal transitions
                        # auto-disarm in ~1s when onPlayBackStarted/onAVStarted reset invoked=-1.
                        if playingItem.get('isPseudoTV'):
                            self.pendingItem.update({'invoked': time.time(), 'retune_cb': callback, 'retune_attempts': 0})
                else:
                    self.log('_onChange, [%s], skipping PlayMedia: callback unresolved (would have been PlayMedia(None))'%(playingItem.get('citem',{}).get('id')), xbmc.LOGWARNING)
            self._runActions(RULES_ACTION_PLAYER_CHANGE, playingItem.get('citem',{}), playingItem, inherited=self)
        else:
            self.toggleBackground(False)
        
        
    @threadit
    def _onError(self, playingItem={}): #todo evaluate potential for error handling.
        self.log('_onError, playingItem = %s'%(playingItem))
        if self.isPseudoTV() and SETTINGS.getSettingBool('Debug_Enable'):
            DIALOG.notificationDialog(LANGUAGE(32000))
            self._onStop(playingItem)
            
           
    @threadit 
    def _onStop(self, playingItem={}):
        self.log('_onStop, playingItem = %s'%(playingItem))
        self.toggleInfo(False)
        self.toggleOverlay(False)
        self.toggleBackground(False)
        if playingItem:
            PROPERTIES.setTrakt(False)
            if playingItem.get('isPlaylist',False): xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
            # madteevee (imports fork, imports.60): replaces quePlaycount. Restore only:
            # rolls the programme back if it owns a snapshot.
            if playingItem.get('isPseudoTV'): self._syncPlaystate(playingItem)
            self._runActions(RULES_ACTION_PLAYER_STOP, playingItem.get('citem',{}), playingItem, inherited=self)
        
            
    def _runActions(self, action, citem={}, parameter=None, inherited=None):
        if self.runActions: return self.runActions(action, citem, parameter, inherited)
        else:               return parameter


    # madteevee (imports fork, imports.65): the four writers of the rule-controlled values
    # (rulestate_helpers). The invariant: those values always equal the settings plus what
    # the last tuned Custom channel's PLAYER_START rules set. runActions re-creates the rules
    # on every call, so the old per-rule restores at Stop could only restore a lost value.
    def _applyChannelRules(self, playingItem):
        # A tune (a channel change, a return from LiveTV, or Stop then the same channel). The
        # rules run on a scratch RuleState with no lock held (PauseRule's START may read a file
        # or the network); only the publish is locked.
        citem = playingItem.get('citem',{})
        self.runActions = RulesList([citem]).runActions
        state = rulestate_helpers.RuleState(dict(rulestate_helpers.baseline(SETTINGS), lastSubState=self.lastSubState))
        playingItem = self._runActions(RULES_ACTION_PLAYER_START, citem, playingItem, inherited=state)
        overrides = state.overrides()
        with self._rules_lock:
            base = rulestate_helpers.baseline(SETTINGS) # read here: a refresh that ran during the rules is not undone
            values = rulestate_helpers.effective(dict(base, lastSubState=self.lastSubState), overrides, rulestate_helpers.TUNE_FIELDS)
            rulestate_helpers.publish(values, self, rulestate_helpers.TUNE_FIELDS)
            self._rulesOverrides, self._rulesBaseline = overrides, base
        if overrides: self.log('[%s] channel rules: %s'%(citem.get('id'), overrides), xbmc.LOGINFO)
        return playingItem


    def _releaseChannelRules(self):
        # A hand-over to LiveTV or a library file: no Custom channel's rules apply.
        with self._rules_lock:
            base = rulestate_helpers.baseline(SETTINGS)
            rulestate_helpers.publish(base, self, rulestate_helpers.FIELDS)
            self._rulesOverrides, self._rulesBaseline = {}, base
        self.log('_releaseChannelRules, back to the settings')


    def _refreshChannelRules(self):
        # A settings change: the new settings under the same overrides. Runs no rule code, so
        # the add-on's own saves (ZeroConf_Status, Update_Status) leave the values unchanged.
        # A channel's own rule keeps winning while it plays (decision Q1 = a).
        with self._rules_lock:
            old, base = self._rulesBaseline, rulestate_helpers.baseline(SETTINGS)
            overrides = self._rulesOverrides
            rulestate_helpers.publish(rulestate_helpers.effective(base, overrides, rulestate_helpers.FIELDS), self, rulestate_helpers.FIELDS)
            self._rulesOverrides, self._rulesBaseline = overrides, base
        changed = sorted(k for k in base if old is not None and base[k] != old.get(k))
        if changed: self.log('_refreshChannelRules, settings changed: %s; channel keeps: %s'%(changed, sorted(set(overrides) & set(rulestate_helpers.FIELDS))), xbmc.LOGINFO)
        return bool(changed)


    def _rollbackSwitched(self, state):
        # The 'Rollback watched' switch acts at once (imports.60), except on a channel with its
        # own rule 53, which keeps its value (Q1 = a). Returns the value now in effect.
        with self._rules_lock:
            if 'rollbackPlaycount' not in self._rulesOverrides: self.rollbackPlaycount = state
            return self.rollbackPlaycount


    # madteevee (imports fork, imports.60): Rollback_Watched Kodi glue. The logic
    # is in playstate_helpers.PlaystateTracker (unit-tested without Kodi).
    @threadit
    def _syncPlaystate(self, oldInfo=None, newInfo=None, allow=False):
        # Own thread, not the service queue: channel builds and tunes block the
        # queue, and a snapshot taken late could capture Kodi's post-play marks.
        # The tracker's lock serializes overlapping events.
        self.playstate.transition(oldInfo, newInfo, allow)


    def _playstateFile(self, playingItem=None):
        # The programme's file, only when Kodi is playing exactly that file now:
        # catch-up clicks, catchup="vod" channels and playlist mode. Live
        # programmes play as pvr://...pvr items, which Kodi never marks (no
        # snapshot, no JSON-RPC). getPlayingItem().getPath() is the item's own
        # path; getPlayingFile() returns Kodi's resolved path and would let live
        # programmes through. plugin:// and resource paths are never looked up.
        playingItem = playingItem or {}
        file = (playingItem.get('fitem') or {}).get('file') or ''
        if not file or playingItem.get('radio',False) or file.startswith(tuple(VFS_TYPES)): return None
        try:
            if self.isPlayingVideo() and self.getPlayingItem().getPath() == file: return file
        except Exception as e: self.log('_playstateFile, playback changed during the check: %s'%(e)) # e.g. stopped between the two calls
        return None


    @threadit
    def _cancelPlaystate(self):
        # Own thread: Monitor.onSettingsChanged runs on the service's main thread,
        # which must not wait for the tracker lock while a transition talks to Kodi.
        self.playstate.clear()


    def _readPlaystateDetails(self, file):
        # delay=False: the tracker checks the player right after this read; the
        # RPC_Delay pause would sit between the two (writes keep the pause).
        return self.jsonRPC.getFileDetails(file, 'video', list(playstate_helpers.PLAYSTATE_PROPERTIES), cache=False, delay=False)


    def _playstateLog(self, msg, level=playstate_helpers.DEBUG):
        self.log(msg, {playstate_helpers.INFO:xbmc.LOGINFO, playstate_helpers.ERROR:xbmc.LOGERROR}.get(level, xbmc.LOGDEBUG))


    def _onSleep(self):
        self.log('_onSleep')
        sec = 0
        cnx = False
        inc = int(100/15)
        xbmc.playSFX(NOTE_WAV)
        dia = DIALOG.progressDialog(message=LANGUAGE(30078))
        while not self.monitor.abortRequested() and (sec < 15):
            sec += 1
            msg = '%s\n%s'%(LANGUAGE(32039),LANGUAGE(32040)%(15-sec))
            dia = DIALOG.progressDialog((inc*sec),dia, msg)
            if self.service._shutdown(1.0) or dia is None:
                cnx = True
                break
        DIALOG.progressDialog(100,dia)
        return not bool(cnx)


    def _chkCallback(self):
        # imports.16: CAS-gated callback resolution. This is the ONLY site
        # outside _onPlay where an idle-thread method mutates self.playingItem
        # in place. The pattern: snapshot the dict ref, resolve callback
        # against that snapshot, publish only if self.playingItem hasn't been
        # swapped under us by an _onPlay worker. If swapped, drop the write;
        # the next idle tick will retry against the fresh state.
        # Lock-free CAS analog — matches Kodi addon convention (GIL-reliance
        # over explicit locks). Replaces the prior nested __chkCallback
        # closure inside _onIdle, which wrote unconditionally and could
        # contaminate a freshly-tuned playingItem with a stale-context
        # callback resolution.
        state = self.playingItem
        if state.get('callback'): return
        callback = self.jsonRPC.getCallback(state)
        if self.playingItem is state:
            state['callback'] = callback
            self.log('_chkCallback, callback = %s'%(callback))
            PROPERTIES.setProperty('lastPlayed.sysInfo', FileAccess._encodeString(state))
        else:
            self.log('_chkCallback, state swapped under us; dropping write (next tick will retry)', xbmc.LOGINFO)


    def _chkTransition(self):
        # imports.47: channel-transition supervisor (watchdog + loop-breaker recovery).
        # Called every ~1s from Monitor._chkIdle's not-playing branch — i.e. it runs
        # during the between-programmes gap where _onIdle (and the dead __chkPlayback
        # it used to host) cannot reach.
        #
        # Two armers in _onChange set pendingItem['invoked']:
        #   1. Watchdog — a normal PseudoTV transition fired PlayMedia and we want
        #      a safety net in case Kodi sits on it (the BUG 1 stall class).
        #   2. Loop-breaker — _onChange detected a runaway (>=3 consecutive short
        #      plays: file ends before its slot does) and deferred the re-tune
        #      instead of firing PlayMedia; _chkTransition fires it after the
        #      Playback_Timeout cooldown, breaking the flicker storm into calm
        #      spaced retries that naturally wait out the dead zone.
        #
        # Auto-disarms (no-op) when:
        #   - pendingItem['invoked'] <= 0 (no transition pending; also clears the
        #     retune_attempts counter so the next genuine arm starts from zero)
        #   - isPlaying() (playback in progress — the relevant onXxx callback
        #     resets invoked=-1; we defensively re-check here too)
        #   - BUILTIN.isBusyDialog() (don't fight a system busy state)
        #   - elapsed < Playback_Timeout (not yet stale)
        #
        # Concurrency: pendingItem is already touched without a lock by Kodi's
        # player-event thread (callbacks), the @threadit workers (_onChange), and
        # this idle-thread method — consistent with the codebase's GIL-reliance
        # (cf. _chkCallback at line 522). The only meaningful race is "playback
        # just started in the ~1s window before we fire" — we re-check isPlaying()
        # immediately before executebuiltin to narrow it; a residual redundant
        # re-tune of the same channel is bounded and benign.
        inv = self.pendingItem.get('invoked', -1)
        if inv <= 0:
            if self.pendingItem.get('retune_attempts', 0) != 0:
                self.pendingItem['retune_attempts'] = 0
            return
        if self.isPlaying(): return
        if BUILTIN.isBusyDialog(): return
        timeout = SETTINGS.getSettingInt('Playback_Timeout') or 45
        if (time.time() - inv) < timeout: return
        attempts = self.pendingItem.get('retune_attempts', 0)
        if attempts >= TRANSITION_MAX_RETRIES:
            self.log('_chkTransition, giving up after %s recovery attempts — '
                     'channel left on background overlay; operator can change channel'
                     %(attempts), xbmc.LOGWARNING)
            self.pendingItem['invoked'] = -1
            DIALOG.notificationDialog(LANGUAGE(32000))
            return
        cb = self.pendingItem.get('retune_cb') or self.playingItem.get('callback')
        if not cb:
            self.log('_chkTransition, no retune_cb available — disarming', xbmc.LOGWARNING)
            self.pendingItem['invoked'] = -1
            return
        self.pendingItem['retune_attempts'] = attempts + 1
        self.pendingItem['invoked']         = time.time()
        self.log('_chkTransition, recovery re-fire #%s after %ss stall — PlayMedia(%s)'
                 %(attempts + 1, int(time.time() - inv), cb), xbmc.LOGWARNING)
        BUILTIN.executebuiltin('PlayMedia(%s)'%(cb))


    def _onIdle(self):
        # imports.47: the nested __chkPlayback that used to live here has been
        # removed — it was dead code (pendingItem['invoked'] was never positive
        # anywhere) AND its action (onPlayBackError → _onError → _onStop on debug)
        # would tear down the channel on a stall instead of recovering it. The
        # replacement is Player._chkTransition() above, called from Monitor._chkIdle
        # so it runs during the between-programmes gap (which _onIdle never could —
        # _chkIdle only invokes _onIdle while playing).

        def __chkBackground():
            remaining = floor(self.getRemainingTime())
            if floor(remaining) <= (OSD_TIMER*2):
                self.log('__chkBackground, remaining = %s'%(remaining))
                self.toggleBackground(self.enableOverlay)

        def __chkResumeTime():
            if not self.playingItem.get('isfiller',True) and self.playingItem.get('isPlaylist',False):
                if self.playingItem.get('fitem',{}).get('file') == self.getPlayingFile():
                    resume = {"position":self.getPlayedTime(),
                              "total":   self.getPlayerTime(),
                              "file" :   self.getPlayerFile(),
                              "updated":{'instance':PROPERTIES.getFriendlyName(),'time':clock_helpers.now()}} # imports.63: the real clock (PauseRule 'last viewed', shown by rules.py via epochTime)
                    self.playingItem.setdefault('resume',{}).update(resume)
                    self.log('__chkResumeTime, resume = %s'%(self.playingItem.get('resume')))

        def __chkOverlay():
            played = ceil(self.getPlayedTime())
            if not self.playingItem.get('isfiller',True) and played > self.minDuration: 
                self.toggleOverlay(self.enableOverlay)

        def __chkOnNext():
            # madteevee (imports fork, imports.64): the same window (onnext_helpers, one copy), shown
            # once per pass: before the window the pass is re-armed (a new show, or the same show
            # restarted). toggleOnNext returns at once, so this idle loop never waits on Up next.
            played    = ceil(self.getPlayedTime())
            remaining = floor(self.getRemainingTime())
            threshold, intTime = onnext_helpers.window(self.getPlayerTime(), self.maxProgress, ONNEXT_TIMER)
            overlay   = self.overlay # one read: _onPlay's thread can replace it
            if self.isPlayingPseudoTV() and not self.playingItem.get('isfiller',True) and not overlay is None:
                if remaining > threshold: overlay.rearmOnNext()
                elif onnext_helpers.in_window(played, remaining, threshold, intTime, self.minDuration):
                    self.log('__chkOnNext, played = %s, remaining = %s'%(played,remaining))
                    overlay.toggleOnNext(bool(self.OnNextMode))
                
        def __chkSleep():
            if self.sleepTime > 0 and (self.monitor.idleTime > (self.sleepTime * 10800)):
                if not PROPERTIES.isRunning('Player.__chkSleep'):
                    with PROPERTIES.chkRunning('Player.__chkSleep'):
                        if self._onSleep(): self.stop()
        
        __chkBackground()
        __chkResumeTime()
        self._chkCallback()
        __chkOverlay()
        __chkOnNext()
        __chkSleep()
            
                
    def toggleBackground(self, state: bool=SETTINGS.getSettingBool('Overlay_Enable')):
        if state and self.service.monitor.isIdle and self.background is None:
            if not self.overlay is None: self.toggleOverlay(False)
            BUILTIN.executebuiltin("Dialog.Close(all)")
            self.background = Background(BACKGROUND_XML, ADDON_PATH, "default", player=self)
            self.background.show()
        elif not state and hasattr(self.background,'close'):
            self.background = self.background.close()
        else: return
        self.log("toggleBackground, state = %s, background = %s"%(state,self.background))


    def toggleOverlay(self, state: bool=SETTINGS.getSettingBool('Overlay_Enable')):
        # v.26: chid-aware idempotency. The Overlay constructor at overlay.py:180
        # snapshots self.player.playingItem.get('citem') at __init__ — once. If
        # __chkOverlay's poll lands between _onPlay's toggleOverlay(False) and
        # _onPlay's self.playingItem update during a fast zap, the new Overlay
        # captures the PREVIOUS channel's citem (and logo). Without this guard,
        # subsequent toggleOverlay(True) calls see overlay != None and no-op,
        # leaving the wrong logo stuck on screen indefinitely. Track the chid
        # the overlay was opened for; if it mismatches the current playingItem's
        # chid, close and rebuild with fresh state. The fix is described in
        # CLAUDE.md memory and was originally master-fork commit 9be4969 — lost
        # during the rebase to upstream/nightly.
        #
        # imports.18: also serialize the entire toggleOverlay critical section
        # with _overlay_lock. v.26's chid check only fires when self.overlay is
        # not None; it doesn't protect the initial-create race where two
        # threads (e.g., _onPlay worker + __chkOverlay idle thread) both see
        # self.overlay = None, both create an Overlay, both `self.overlay = ...`.
        # The loser's Overlay python object is orphaned, but its channelBug
        # control was already added to xbmcgui.Window(12005) by open(). It
        # persists for the rest of the Kodi session, showing the wrong logo
        # over subsequent channels. Lock is held during Overlay.__init__ +
        # open() — both fast (no I/O, just python + xbmcgui control creation).
        with self._overlay_lock:
            if state and self.isPlayingPseudoTV():
                current_chid = self.playingItem.get('citem',{}).get('id')
                if self.overlay is not None:
                    if self._overlay_chid == current_chid:
                        return
                    self.overlay = self.overlay.close()
                self.overlay = Overlay(player=self)
                self.overlay.open()
                self._overlay_chid = current_chid
            elif not state and hasattr(self.overlay,'close'):
                self.overlay = self.overlay.close()
                self._overlay_chid = None
            else:
                return
            self.log("toggleOverlay, state = %s, overlay = %s, _overlay_chid = %s"%(state, self.overlay, self._overlay_chid))


    @debounceit(restart_helpers.POPUP_DELAY) # imports.63: was OSD_TIMER (about 5 s later)
    def toggleReplay(self, state: bool=False, epoch=None):
        # madteevee (imports fork, imports.62): offers the Restart pop-up for the playback
        # `epoch` (Custom and LiveTV channels). restart_helpers decides; the dialog is a
        # passive view that is always released when it closes (it used to stay set for
        # the whole Kodi session, so it could be offered once at most).
        if not state:
            self._closeReplay()
            return
        if self.replay is not None or epoch != self._play_epoch: return
        target = self._restartOffer()
        if not target or not self._waitRestartWindow(epoch): return
        if restart_helpers.popup_done(epoch, self._play_epoch, time.time(), target.get('end')): return
        dialog = Replay(REPLAY_XML, ADDON_PATH, "default", "1080i", player=self, epoch=epoch, end=target.get('end'))
        self.replay, chosen = dialog, False
        self.log("toggleReplay, offering %s"%(target))
        try:
            dialog.doModal()
            chosen = dialog.restart
        finally:
            self.replay = None
            del dialog
        self.log("toggleReplay, closed, restart = %s"%(chosen))
        if chosen: self.requestRestart({'source':'popup','target':target})


    @debounceit(OSD_TIMER)
    def toggleInfo(self, state: bool=SETTINGS.getSettingBool('Enable_OnInfo')):
        if state and self.isPlayingPseudoTV() and not self.playingItem.get('isfiller',True) and not BUILTIN.getInfoBool('IsVisible(fullscreeninfo)','Window'):
            BUILTIN.executewindow('ActivateWindow(fullscreeninfo)')
            timerit(self.toggleInfo)(float(OSD_TIMER),False)
        elif not state and BUILTIN.getInfoBool('IsVisible(fullscreeninfo)','Window'):
            BUILTIN.executebuiltin('Action(back)')
            BUILTIN.executebuiltin('Dialog.Close(fullscreeninfo)')
        else: return
        self.log('toggleInfo, state = %s'%(state))


    # madteevee (imports fork, imports.62): restart from the beginning. Every decision is
    # in restart_helpers (unit-tested without Kodi); these methods only read Kodi and act.
    def _closeReplay(self):
        # Asks an open Restart pop-up to close. One read of self.replay: toggleReplay's
        # finally (another thread) can clear it at any moment.
        replay = self.replay
        if replay is not None: replay.closing = True


    def _restartWait(self, done, limit, step=0.25):
        # True as soon as done() holds; False after `limit` s or at shutdown.
        waited = 0.0
        while not done():
            if waited >= limit or self.service._shutdown(step): return False
            waited += step
        return True


    def _restartOffer(self):
        # The pop-up's target, or None. Custom: the playing episode is >= Restart Percentage
        # and < Seek_Threshold through (not a filler or radio). LiveTV: a live channel whose
        # show on now is that far in and that Kodi says can be replayed.
        if self.isPlayingPseudoTV():
            if restart_helpers.custom_offer(self.playingItem, self.getPlayedTime(), self.getPlayerTime(),
                                            self.replayPercentage, self.maxProgress):
                return restart_helpers.custom_target(self.playingItem)
            return None
        if not BUILTIN.getInfoBool('IsPlayingTv','Pvr'): return None
        item = self.jsonRPC.getPlayerItemRef()
        if item.get('type') != 'channel': return None
        target = self._restartLiveTarget(item.get('id'), time.time(), offer=True)
        return target if target and target.get('playable') else None


    def _restartLiveTarget(self, channelid, now, offer=False):
        # hasarchive first, so the channels without replays never get a broadcastnow read
        # (their artwork links are signed).
        if not channelid or self.jsonRPC.getPVRChannelInfo(channelid, ('hasarchive',)).get('hasarchive') is not True: return None
        details = self.jsonRPC.getPVRChannelInfo(channelid, ('broadcastnow','hasarchive'))
        target  = restart_helpers.livetv_target(channelid, details, now, Globals._decodePlot,
                                                SETTINGS.getSettingInt('Replay_Percentage'), self.maxProgress, offer)
        if target: target['playable'] = self.jsonRPC.isBroadcastPlayable(target['broadcastid'])
        return target


    def _restartGuideTarget(self, path, now):
        # One read of every channel's show on now, the same data matchChannel reads at
        # every own-channel tune; the guide entry's path is matched against it.
        target = restart_helpers.guide_target(self.jsonRPC.getPVRChannelsNow(), path, now, Globals._decodePlot)
        if target and target.get('kind') == 'livetv': target['playable'] = self.jsonRPC.isBroadcastPlayable(target['broadcastid'])
        return target


    def _waitRestartWindow(self, epoch, limit=OSD_TIMER*2):
        # Waits (bounded) until full-screen video plays with Kodi's channel info, the
        # channel preview and any other dialog gone, while the same playback goes on.
        ready = self._restartWait(lambda: epoch != self._play_epoch or xbmc.getCondVisibility(restart_helpers.WINDOW_READY), limit)
        return ready and epoch == self._play_epoch


    def _restartTuneTs(self):
        # The playing ListItem's own tune stamp (default.py), to tell the programme the
        # service knows from a zap still in progress. None when unreadable.
        try:
            sysInfo = FileAccess._decodeString(self.getPlayingItem().getProperty('sysInfo'))
            return sysInfo.get('_tune_ts') if isinstance(sysInfo, dict) else None
        except Exception: return None


    def _restartFacts(self):
        video    = self.isPlayingVideo()
        pseudotv = self.isPlayingPseudoTV()
        return {'video':      video,
                'seekable':   BUILTIN.getInfoBool('SeekEnabled','Player'),
                'pvr_live':   BUILTIN.getInfoBool('IsPlayingTv','Pvr'),
                'pvr_epgtag': BUILTIN.getInfoBool('IsPlayingEpgTag','Pvr'),
                'item':       self.jsonRPC.getPlayerItemRef() if video else {},
                'pseudotv':   self.playingItem if pseudotv else None,
                'tune_ts':    self._restartTuneTs() if pseudotv else None}


    @threadit
    def requestRestart(self, request=None):
        # THE restart action, shared by the pop-up (B), the remote button (C) and the guide
        # entry (D). One at a time: @threadit alone does not serialize.
        if not self._restart_lock.acquire(False):
            self.log('requestRestart, a restart is already running; ignoring %s'%(request), xbmc.LOGINFO)
            return
        try: self._runRestart(request or {})
        except Exception as e: self.log('requestRestart, failed! %s'%(e), xbmc.LOGERROR)
        finally: self._restart_lock.release()


    def _runRestart(self, request):
        # A zap still settling ('tune in progress') is retried for a few seconds, so a
        # pressed button never ends without an answer.
        path  = request.get('path')
        guide = bool(path)
        for _ in range(restart_helpers.SETTLE_TRIES):
            now     = time.time()
            facts   = self._restartFacts()
            playing = restart_helpers.classify_playing(facts)
            target  = self._restartGuideTarget(path, now) if guide else request.get('target')
            action, reason = restart_helpers.decide(playing, target, now, guide)
            if action == restart_helpers.LOOKUP_LIVE:
                target = self._restartLiveTarget(playing.get('channelid'), now)
                if target: action, reason = restart_helpers.decide(playing, target, now)
                else:      action, reason = restart_helpers.UNAVAILABLE, 'no replay for the show on now'
            if action != restart_helpers.IGNORE: break
            if self.service._shutdown(restart_helpers.SETTLE_WAIT): return
        else: action, reason = restart_helpers.UNAVAILABLE, '%s (after %s tries)'%(reason, restart_helpers.SETTLE_TRIES)
        self.log('requestRestart, source = %s, playing = %s, action = %s (%s), target = %s'
                 %(request.get('source'), playing.get('kind'), action, reason, target), xbmc.LOGINFO)
        if action != restart_helpers.UNAVAILABLE: self._closeReplay()
        if   action == restart_helpers.SEEK_START:     self._restartSeek(guide)
        elif action == restart_helpers.OPEN_BROADCAST: self._restartOpen(target, facts.get('item') or {})
        elif action == restart_helpers.TUNE_CUSTOM:    self._restartTune(target)
        elif action == restart_helpers.RETUNE_CUSTOM:  self._restartTune(target, stop_first=True)
        elif action == restart_helpers.UNAVAILABLE:    self._restartNote()


    def _restartSeek(self, guide=False, wait=0.0):
        # Player.seekTime does nothing when the player can't seek and raises when nothing
        # plays. The guide entry also brings the video back to full screen, as Kodi's own
        # 'Play programme' does for the entry that already plays.
        if wait: self._restartWait(lambda: BUILTIN.getInfoBool('SeekEnabled','Player'), wait)
        try: self.seekTime(0)
        except Exception as e:
            self.log('_restartSeek, failed! %s'%(e), xbmc.LOGWARNING)
            return False
        if guide and not BUILTIN.getInfoBool('IsActive(fullscreenvideo)','Window'):
            BUILTIN.executewindow('ActivateWindow(fullscreenvideo)')
        return True


    def _restartOpen(self, target, before):
        # Kodi's own 'Play programme' (PlayEpgTag). Kodi doesn't tell Python that a replay
        # was refused, so the result is read from the player (restart_helpers.watch_outcome),
        # timed from the moment Player.Open returned.
        bid = target['broadcastid']
        if not self.jsonRPC.playerOpen({'item':{'broadcastid':bid}}):
            self.log('_restartOpen, broadcast %s: Player.Open refused'%(bid), xbmc.LOGINFO)
            return self._restartNote()
        t0, idle0, stops, errors = time.time(), BUILTIN.getIdle(), self._play_stops, self._play_errors
        before_key = (before.get('type'), before.get('id')) if before else None
        can_retune = before.get('type') == 'channel' and (before.get('id') or 0) > 0
        while not self.service._shutdown(restart_helpers.WATCH_POLL):
            playing = self.isPlaying()
            item    = self.jsonRPC.getPlayerItemRef() if playing else {}
            outcome = restart_helpers.watch_outcome({'elapsed':    time.time() - t0,
                                                     'replay':     playing and BUILTIN.getInfoBool('IsPlayingEpgTag','Pvr') and item.get('id') == bid,
                                                     'unchanged':  playing and before_key is not None and (item.get('type'), item.get('id')) == before_key,
                                                     'playing':    playing,
                                                     'busy':       BUILTIN.isBusyDialog(),
                                                     'idle':       BUILTIN.getIdle(),
                                                     'idle0':      idle0,
                                                     'stopped':    self._play_stops != stops,
                                                     'errored':    self._play_errors != errors,
                                                     'can_retune': can_retune})
            if outcome == 'wait': continue
            self.log('_restartOpen, broadcast %s: %s'%(bid, outcome), xbmc.LOGINFO)
            if outcome == 'retune': self.jsonRPC.playerOpen({'item':{'channelid':before['id']}})
            if outcome in ('refused','retune','failed'): self._restartNote()
            return


    def _restartTune(self, target, stop_first=False):
        # A Custom guide entry whose channel isn't playing that programme: tune the channel
        # (it joins mid-show), then _restartPending jumps to the start once it plays. When
        # Kodi plays that very channel, Player.Open {channelid} would only switch to full
        # screen, so it is stopped first.
        if stop_first:
            self.stop()
            if not self._restartWait(lambda: not self.isPlaying(), restart_helpers.STOP_WAIT): return self._restartNote()
        self._pendingRestart = {'chid':target['chid'], 'start':target['start'], 'ts':time.time()}
        if not self.jsonRPC.playerOpen({'item':{'channelid':target['channelid']}}):
            self._pendingRestart = None
            self._restartNote()


    def _restartPending(self, playingItem):
        # Called at the end of _onPlay's PseudoTV path.
        pending = self._pendingRestart
        if not pending: return
        now = time.time()
        if restart_helpers.pending_match(pending, playingItem, now):
            self._pendingRestart = None
            self.log('_restartPending, [%s] jumping to the start of the programme'%(pending.get('chid')), xbmc.LOGINFO)
            self._restartSeek(wait=2.0)
        elif restart_helpers.pending_expired(pending, now):
            self._pendingRestart = None


    def _restartNote(self):
        # 'Restart Unavailable...'. Shown even when 'Notify while playing' is off: it
        # answers a button the viewer pressed.
        DIALOG.notificationDialog(LANGUAGE(30154), show=True)


    # madteevee (imports fork, imports.70): LiveTV replays frozen at their end move on. A replay
    # opened while its show is on air (the RESTART pop-up, the guide's 'Play programme', Kodi's own
    # next show) is a live stream on Movistar+; inputstream.adaptive never ends its last
    # period, so Kodi stalls on the last second and never plays the next show (its "Play next
    # programme automatically" runs only on a natural end). Every decision is in replayend_helpers
    # (tested without Kodi); these methods only read Kodi and act. They never read the playing
    # file or path: Movistar+ stream links carry tokens.
    def _chkReplayEnd(self):
        # imports.70: Monitor._chkIdle's tick, about once a second while no Custom channel plays
        # (right after _chkTransition). The only writer of _replayEndTrack. Kodi reads only, no
        # JSON-RPC: the one lookup per playback runs on its own worker. Never raises: a failure
        # parks this playback ('failed'), so it warns once per playback, never every second.
        epoch = self._play_epoch
        try:
            if not xbmc.getCondVisibility('Pvr.IsPlayingEpgTag'):
                if self._replayEndTrack is not None: self._replayEndTrack = None
                return
            now   = clock_helpers.now()
            track = self._replayEndTrack
            if track is None or track.get('epoch') != epoch:
                self._replayEndTrack = replayend_helpers.new_track(epoch, now)
                return
            if track.get('failed'): return
            if not track.get('lookup'):
                # One lookup per playback, once its start has settled; a clock change either
                # way never holds it back.
                if abs(now - track['seen']) >= replayend_helpers.ARM_DELAY_S:
                    self._replayEndTrack = dict(track, lookup=True)
                    self._lookupReplayEnd(epoch)
                return
            facts = self._replayEndFacts
            if not facts or facts.get('epoch') != epoch: return   # a finished show, or the lookup still runs
            # imports.70 (the repair after the 2026-11-19 TV test): the stream alone decides; due 20 s
            # after it stood still at its end, with no wait for the guide's end time. Where to go is
            # the move's choice (on_air, next_broadcast), so these lines report the standstill only.
            new, due = replayend_helpers.stall_step(track, self._replayEndSample(), now)
            # A newer playback that started during the reads: the sample may be its own.
            if self._play_epoch != epoch: return
            self._replayEndTrack = new
            if new.get('deferred') and not track.get('deferred'):
                self.notice('replay end: broadcast %s is frozen at its end (%d of %d s); waiting for full-screen video'
                            ' with no menu open and %d s without a key press'
                            %(facts.get('broadcastid'), new['pos'], new['total'], replayend_helpers.QUIET_S))
            if due:
                self.notice('replay end: broadcast %s stood still for %d s at %d of %d s: moving on (attempt %d of %d)'
                            %(facts.get('broadcastid'), now - new['since'], new['pos'], new['total'], new['fires'],
                              replayend_helpers.MAX_FIRES))
                self._moveReplayEnd(dict(facts), epoch)
        except Exception as e:
            self._replayEndTrack = {'epoch': epoch, 'failed': True}
            # imports.70: ERROR (at most once per playback, the track is marked failed): the add-on
            # writes WARNING/INFO lines only with its debug logging on, and a watcher that never runs
            # must leave a trace in kodi.log for the next frozen replay to be diagnosable.
            self.log('_chkReplayEnd, failed: %s'%(e), xbmc.LOGERROR)


    def _replayEndSample(self):
        # imports.70: the tick's Kodi reads (replayend_helpers.stall_step's sample), never logged.
        # Kodi is read directly, not through BUILTIN.getInfoBool, which logs every call at debug
        # level. getTime / getTotalTime are the OSD's own values ('1:40:53 of 1:40:54'); both are
        # None when the player can't say. isPlaying() is asked first: with nothing playing (a
        # replay that just ended, before Kodi's PVR flag follows) the two getters raise and Kodi
        # itself writes an ERROR line ('EXCEPTION: Kodi is not playing any media file') for each
        # call, once a second here.
        pos, total = None, None
        if self.isPlaying():
            try: pos, total = self.getTime(), self.getTotalTime()
            except Exception: pos, total = None, None
        return {'pos'   : pos,
                'total' : total,
                'busy'  : xbmc.getCondVisibility(replayend_helpers.BUSY),
                'window': xbmc.getCondVisibility(replayend_helpers.ACT_WINDOW),
                'idle'  : BUILTIN.getIdle()}


    @threadit
    def _lookupReplayEnd(self, epoch):
        # imports.70: once per replay playback (the tick, ARM_DELAY_S after it started): is its show
        # the one on air? Two narrow reads (imports.62's: no 'file'). The only writer of
        # _replayEndFacts, always whole and tagged with its epoch, and only while that playback is
        # still current. A finished show's replay is a recording that ends by itself: left to Kodi.
        # Never raises.
        try:
            bid = replayend_helpers.playing_broadcast(self.jsonRPC.getPlayerItemRef())
            if self._play_epoch != epoch: return
            if bid is None:
                self.notice('replay end: not watching: Kodi reports no guide entry playing')
                return
            facts = replayend_helpers.programme(self.jsonRPC.getPVRChannelsNow(), bid, clock_helpers.now(), Globals._decodePlot)
            if self._play_epoch != epoch: return
            if facts is None:
                # imports.70: the line says what was checked, no more: whether a replay opened after its
                # guide end while its stream's window is still open freezes too is not measured
                # (FORK_NOTES, Limits).
                self.notice('replay end: not watching broadcast %s: not a LiveTV show on air now: left to Kodi'%(bid))
                return
            self._replayEndFacts = dict(facts, epoch=epoch)
            self.notice('replay end: watching broadcast %s on channel %s; its guide entry ends %s UTC'
                        %(bid, facts['channelid'], facts['endtime']))
        except Exception as e:
            # imports.70: ERROR, once per playback (one lookup per playback): see _chkReplayEnd.
            self.log('_lookupReplayEnd, failed: %s'%(e), xbmc.LOGERROR)


    @threadit
    def _moveReplayEnd(self, facts, epoch):
        # imports.70: the move, on its own thread (it waits for Kodi). It takes the RESTART lock
        # without waiting (requestRestart's pattern), so a restart and a move never run together:
        # a restart (or an earlier move still watching) running now wins, and the tick's second
        # attempt comes RETRY_S later.
        if not self._restart_lock.acquire(False):
            self.notice('replay end: broadcast %s: not moving on now: a restart or an earlier move is still running'
                        %(facts.get('broadcastid')))
            return
        try: self._runReplayEnd(facts, epoch)
        except Exception as e: self.log('_moveReplayEnd, failed! %s'%(e), xbmc.LOGERROR)
        finally: self._restart_lock.release()


    def _runReplayEnd(self, facts, epoch):
        # imports.70: what Kodi does at a natural end (CPVRPlaybackState::OnPlaybackEnded). The
        # replay's own flag decides between going on and a stop. Going on plays the live channel
        # while the guide still lists the show as on air (replayend_helpers.on_air: a stream's
        # window need not match its guide entry, 2026-11-19), else the next guide entry (Kodi's
        # rule, replayend_helpers.next_broadcast) or the live channel; one try of live when the next
        # show won't open, and a stop of the frozen replay when the live channel won't
        # (after_open). At most 2 opens and 1 stop; the playback number is checked at every step,
        # and right before acting full screen, no key press and what plays (frozen(), read last).
        bid, cid = facts['broadcastid'], facts['channelid']

        def frozen():
            # The watched replay still plays: the same playback number and broadcast.
            if self._play_epoch != epoch or not xbmc.getCondVisibility('Pvr.IsPlayingEpgTag'): return None
            item = self.jsonRPC.getPlayerItemRef()
            if self._play_epoch != epoch or replayend_helpers.playing_broadcast(item) != bid: return None
            return item

        def can_act():
            return (replayend_helpers.ready(xbmc.getCondVisibility(replayend_helpers.ACT_WINDOW), BUILTIN.getIdle())
                    and self._play_epoch == epoch)

        # imports.70: asked without waiting (Service._aborted). The first build asked with
        # _shutdown(0); Kodi's waitForAbort takes 0 as "no timeout", so the move stood on this
        # line until Kodi closed, holding the RESTART lock (TV test 2026-11-19).
        if self.service._aborted(): return
        item = frozen()
        if item is None:
            self.notice('replay end: broadcast %s: not moving on: it no longer plays'%(bid))
            return
        before   = (item.get('type'), bid)
        autoplay = replayend_helpers.autoplay_on(self._replayEndAutoplay())
        # imports.70 (the repair after the 2026-11-19 TV test): the target is chosen with the clock
        # read after the guide read, the moment of the choice: the live channel while the guide
        # lists the show as on air, else the next entry (or live); `why` goes into the log line.
        target, why = ('channel', cid), ''
        if autoplay:
            rows = self.jsonRPC.getPVRBroadcastTimes(cid)
            now  = clock_helpers.now()                      # after the read: the moment of the choice
            nxt  = replayend_helpers.next_broadcast(rows, facts['start'], facts['end'], now)
            if nxt: target, why = ('broadcast', nxt['broadcastid']), 'its guide entry is over'
            elif replayend_helpers.on_air(facts['end'], now):
                why = 'the guide lists its show as on air until %s UTC'%(facts['endtime'])
            else:
                why = 'its guide entry is over and no next entry has started (or the guide changed)'
        # The last check, right before acting (the tick's was a moment ago, before these reads).
        if not can_act():
            self.notice('replay end: broadcast %s: not moving on now: not in full-screen video, a key was pressed or'
                        ' another video plays'%(bid))
            return
        # imports.70 (the repair, from the Kodi check): then what plays, read fresh. Kodi swaps its
        # playing item at once, but the playback number moves only when the service's main thread
        # runs the callback (between its 100 ms wait slices), and the flag and guide reads above come
        # in between: a zap made then without a key press (a phone app, JSON-RPC) is left alone,
        # neither stopped (the flag, read from the new item, says off) nor opened over.
        if frozen() is None:
            self.notice('replay end: broadcast %s: not moving on: it no longer plays'%(bid))
            return
        if not autoplay:
            # imports.70: Kodi leaves the flag off when "Play next programme automatically" was off
            # at the replay's start, and also for the guide menu's "Play only this programme"
            # (offered while the setting is on): either way Kodi would stop at a natural end.
            self.notice('replay end: broadcast %s: stopping, as Kodi does at the end of a replay without its next-show'
                        ' flag ("Play next programme automatically" was off when it started, or "Play only this'
                        ' programme" opened it)'%(bid))
            self.stop()
            return
        # imports.70: written before Player.Open, so a move that blocks there (a PIN or "play
        # recording?" question of Kodi's) still leaves its decision in the log.
        self.notice('replay end: broadcast %s: %s: opening %s'%(bid, why, replayend_helpers.target_text(target)))
        outcome = self._replayEndOpen(target, before)
        step    = replayend_helpers.after_open(target[0], outcome)
        if step == 'live':
            # The frozen replay still plays (the next show was refused, or Kodi said no): the same
            # checks as before the first open. 'retune', a start that failed with an error, would
            # skip them, the error having ended the playback; Kodi 21 never reports one: a failed
            # start arrives as a stop ('gave_up') and ends the move (FORK_NOTES, Limits).
            if outcome != 'retune' and (frozen() is None or not can_act()):
                self.notice('replay end: broadcast %s: the next show did not open; not trying the live channel now'
                            ' (it no longer plays, not in full-screen video, or a key was pressed)'%(bid))
                return
            outcome = self._replayEndOpen(('channel', cid), before)
            step    = replayend_helpers.after_open('channel', outcome)
        if step == 'stop' and frozen() is not None:
            # imports.70: this stop acts too, so it waits like the first open and the flag-off stop:
            # never under the guide, a menu or a key press; the tick's second attempt comes RETRY_S
            # later. The live channel may have been the first and only target (the guide still
            # listed the show as on air): stopping when nothing opens is the 2026-11-15 decision.
            if not can_act():
                self.notice('replay end: broadcast %s: the live channel did not open; not stopping now (not in'
                            ' full-screen video, or a key was pressed)'%(bid))
                return
            self.notice('replay end: broadcast %s: the live channel did not open: stopping'%(bid))
            self.stop()


    def _replayEndOpen(self, target, before):
        # imports.70: a sibling of _restartOpen (imports.62, unchanged), with no note on screen
        # (Kodi's own next show is silent). Opens the next show ('broadcast', id: Kodi's 'Play
        # programme', PlayEpgTag, which keeps the next-show chain going) or the live channel
        # ('channel', id). Kodi doesn't tell Python that an open was refused, so the result is read
        # from the player (restart_helpers.watch_outcome), timed from when Player.Open returned.
        # Returns 'not_opened' (Player.Open said no), a watch_outcome result, or 'shutdown'.
        # 'started' means Kodi reports the target as the playing item, which it does before the new
        # stream is open. Each result is written to Kodi's log with the frozen replay's id
        # (before[1]) and a few words of what it means (replayend_helpers.outcome_note).
        kind, value = target
        # imports.70: the key and event counters are read before Player.Open, the clock after it.
        # playerOpen waits RPC_Delay after Kodi's reply, and a stop in that second (on Kodi 21 also a
        # start that failed) must be seen at once. The key check stays exact: the idle time only
        # grows while no key is pressed.
        idle0, stops, errors = BUILTIN.getIdle(), self._play_stops, self._play_errors
        if not self.jsonRPC.playerOpen({'item':{('broadcastid' if kind == 'broadcast' else 'channelid'):value}}):
            self.notice('replay end: broadcast %s: %s: %s'%(before[1], replayend_helpers.target_text(target),
                                                          replayend_helpers.outcome_note('not_opened')))
            return 'not_opened'
        t0 = clock_helpers.now()
        while not self.service._shutdown(restart_helpers.WATCH_POLL):
            playing = self.isPlaying()
            item    = self.jsonRPC.getPlayerItemRef() if playing else {}
            # imports.70: the live channel has started when Player.GetItem reports it. Pvr.IsPlayingTv
            # isn't asked: Kodi refreshes that flag about twice a second (CPVRGUIInfo), after the item
            # (2026-11-19: about 1 s later), and a check in between read the started channel as
            # 'other'. A replay target keeps Pvr.IsPlayingEpgTag: it is true before and after (a
            # replay follows a replay), and it tells a guide entry's id from any other item's.
            if kind == 'broadcast': hit = xbmc.getCondVisibility('Pvr.IsPlayingEpgTag') and item.get('id') == value
            else:                   hit = item.get('type') == 'channel' and item.get('id') == value
            outcome = restart_helpers.watch_outcome({'elapsed':    clock_helpers.now() - t0,
                                                     'replay':     playing and hit,
                                                     'unchanged':  playing and (item.get('type'), item.get('id')) == before,
                                                     'playing':    playing,
                                                     'busy':       BUILTIN.isBusyDialog(),
                                                     'idle':       BUILTIN.getIdle(),
                                                     'idle0':      idle0,
                                                     'stopped':    self._play_stops != stops,
                                                     'errored':    self._play_errors != errors,
                                                     'can_retune': kind == 'broadcast'})
            if outcome == 'wait': continue
            self.notice('replay end: broadcast %s: %s: %s'%(before[1], replayend_helpers.target_text(target),
                                                          replayend_helpers.outcome_note(outcome)))
            return outcome
        return 'shutdown'


    def _replayEndAutoplay(self):
        # imports.70: Kodi's own flag on the playing replay (replayend_helpers.AUTOPLAY_PROPERTY),
        # set at its start: from "Play next programme automatically" as it stood then ('Play
        # programme', Player.Open, Kodi's own next show), always for the guide menu's "Play
        # programmes from here", never for its "Play only this programme". Exactly what Kodi reads
        # at a natural end. '' when unreadable.
        try: return self.getPlayingItem().getProperty(replayend_helpers.AUTOPLAY_PROPERTY)
        except Exception: return ''


class Monitor(xbmc.Monitor):
    idleTime  = 0
    isIdle    = False
    isRunning = False
    
    def __init__(self, service=None):
        xbmc.Monitor.__init__(self)
        self.service = service
        self.jsonRPC = service.jsonRPC
        self.player  = Player(self,service)
        self.rollbackSwitch = SETTINGS.getSettingBool('Rollback_Watched') # madteevee (imports fork, imports.60): see _chkRollbackSwitch
        # madteevee (imports fork, imports.71): _tickFailed's memory, this loop's own
        self.tickFailures   = loopguard_helpers.Failures()

        
    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)


    def chkIdle(self):
        self.idleThread = Thread(target=self._chkIdle)
        self.idleThread.daemon = True
        self.idleThread.start()
            
        
    def _chkIdle(self):
        if not self.isRunning:
            self.isRunning = True
            while not self.abortRequested():
                try:
                    if   self.service._shutdown(0.5): break
                    elif self.player.isPlayingPseudoTV():
                        self.idleTime = BUILTIN.getIdle()
                        self.isIdle   = bool(self.idleTime) | self.idleTime > OSD_TIMER
                        self.log('_chkIdle, isIdle = %s, idleTime = %s'%(self.isIdle, self.idleTime))
                        if self.isIdle: self.player._onIdle()
                    else:
                        # imports.47: not-playing branch now drives the transition supervisor
                        # (watchdog stall-recovery + loop-breaker cooldown). _chkTransition is
                        # a fast no-op when no transition is pending — safe to call every tick.
                        # Keeps the second _shutdown wait so shutdown stays responsive and the
                        # not-playing loop cadence stays ~1s (matches pre-imports.47 timing).
                        # madteevee (imports fork, imports.67): LiveTV plays in this branch; a subtitle
                        # toggle fires no player event, so it is read on this tick (fast no-op otherwise).
                        self.player._chkLiveSubtitles()
                        self.player._chkTransition()
                        # madteevee (imports fork, imports.70): a LiveTV replay frozen at its end moves on.
                        self.player._chkReplayEnd()
                        if self.service._shutdown(0.5): break
                except Exception as e:
                    # madteevee (imports fork, imports.71): one failed tick no longer ends this thread
                    # (_tickFailed). Then the tick's own 0.5 s wait, so a failing tick can't turn without
                    # one; should that wait itself fail, the thread ends, as before.
                    self._tickFailed(e)
                    if self.service._shutdown(0.5): break
            self.isRunning = False
            self.log("_chkIdle, shutdown!")


    def _tickFailed(self, error):
        # madteevee (imports fork, imports.71): a tick of _chkIdle failed. Its exception used to end
        # this thread for the rest of the session (chkIdle starts it at each service start, and
        # isRunning then stays True), and with it the idle check, the LiveTV subtitle memory
        # (imports.67), the transition supervisor (imports.47) and the replay-end watcher
        # (imports.70). Written by the main loop's rule (Service._passFailed): each distinct error
        # once per session, at ERROR with its traceback; this loop keeps a memory of its own.
        if self.tickFailures.first(loopguard_helpers.error_key(error)):
            self.log('_chkIdle, a tick failed; the idle loop goes on (each different error is written once per'
                     ' session): %s'%(loopguard_helpers.describe(error)), xbmc.LOGERROR)


    def onNotification(self, sender, method, data):
        self.log("onNotification, sender %s - method: %s  - data: %s" % (sender, method, data))
        # madteevee (imports fork, imports.62): the remote button (no data) and the guide
        # entry (data {path}) both arrive as NotifyAll(pseudotv, restart). The work runs on
        # the restart thread, so this returns at once.
        request = restart_helpers.parse_notification(sender, method, data)
        if request is not None:
            request['source'] = 'guide' if request.get('path') else 'remote'
            self.player.requestRestart(request)
            

    def onSettingsChanged(self):
        # madteevee (imports fork, imports.60): "Rollback watched" applies at once;
        # everything else stays debounced (15 s) and queued as before.
        self._chkRollbackSwitch()
        self._onSettingsChanged()


    def _chkRollbackSwitch(self):
        # Acts only when this setting itself changed: switching it off cancels the
        # pending rollback of the programme playing at once (before, that waited for
        # the 15 s debounce plus the service queue, so a quick Stop still rolled
        # back). Other settings changes cancel nothing.
        state = SETTINGS.getSettingBool('Rollback_Watched')
        if state == self.rollbackSwitch: return
        self.log('_chkRollbackSwitch, Rollback_Watched = %s'%(state))
        self.rollbackSwitch = state
        # madteevee (imports fork, imports.65): through the player's lock; a channel with its
        # own rule 53 keeps its value, so its pending rollback is cancelled only when off.
        effective = self.player._rollbackSwitched(state)
        if not state and not effective: self.player._cancelPlaystate()


    @debounceit(15)
    def _onSettingsChanged(self):
        self.log('onSettingsChanged')
        self.service._que(self._updatePlayerSettings)
        self.service._que(self._updateServiceSettings)
            
            
    def _updateServiceSettings(self):
        self.log('_updateServiceSettings')
        # madteevee (imports fork, imports.71): the queue's Enable_Executor follows a save here; _run
        # no longer reads it (cqueue.CustomQueue._chkExecutor). First, so a failure below can't skip it.
        self.service.priorityQUE._chkExecutor()
        self.service.channels = self.service.tasks.getChannels()
        self.service.settings = self.service.tasks.chkSettingsChange(self.service.settings) #check for settings change, take action if needed
        
        
    def _updatePlayerSettings(self):
        self.log('_updatePlayerSettings')
        self.player.minDuration       = SETTINGS.getSettingInt('Seek_Tolerance')
        self.player.maxProgress       = SETTINGS.getSettingInt('Seek_Threshold')
        self.player.sleepTime         = SETTINGS.getSettingInt('Idle_Timer')
        self.player.runWhilePlaying   = SETTINGS.getSettingBool('Run_While_Playing')
        # madteevee (imports fork, imports.65): the rule-controlled values are the settings plus
        # the playing Custom channel's rules. Every settings save lands here: the add-on's own
        # ZeroConf_Status (server.py discovery loop) and Update_Status (tasks.chkVersion) saves,
        # the dashboard settings API and the settings dialog. Writing the globals here used to
        # put them back over the playing channel's rules.
        self.player._refreshChannelRules()
        
        
class Service(object):
    channels         = []
    isScanning       = BUILTIN.isScanning()
    isPaused         = BUILTIN.isPaused()
    isPlaying        = BUILTIN.isPlaying()
    isClient         = SETTINGS.getSettingBool('Enable_Client')
    pendingSuspend   = PROPERTIES.setPendingSuspend(False)
    pendingInterrupt = PROPERTIES.setPendingInterrupt(False)
    pendingShutdown  = PROPERTIES.setPendingShutdown(False)
    pendingRestart   = PROPERTIES.setPendingRestart(False)
    # madteevee (imports fork, imports.71): the Kodi-restart marker (_kodiRestart) goes with the request.
    # This body runs once per interpreter: when Kodi starts this service script (at its own start, or
    # after an add-on update, a reinstall or a disable and enable), whose modules then read their data
    # paths and files anew. A marker left over from the old interpreter, its reason gone, would make a
    # later 'Force background service to reload' pause the service with an old note.
    PROPERTIES.setPendingKodiRestart('')
    jsonQue          = set(SETTINGS.getCacheSetting('jsonQue') or [])
    postQue          = set(SETTINGS.getCacheSetting('postQue') or [])
    logoQue          = set(SETTINGS.getCacheSetting('logoQue') or [])
    kodiRestartNoted = '' # madteevee (imports fork, imports.71): the Kodi-restart reason last shown (_kodiRestart)

    def __init__(self):
        self.jsonRPC     = JSONRPC(service=self)
        self.monitor     = Monitor(service=self)
        self.player      = self.monitor.player
        self.tasks       = Tasks(service=self)
        self.channels    = self.tasks.getChannels()
        self.settings    = SETTINGS.getCurrentSettings()
        self.isClient    = SETTINGS.getSettingBool('Enable_Client')
        self.priorityQUE = CustomQueue(priority=True, service=self)
        # madteevee (imports fork, imports.71): _passFailed's memory, kept across restarts
        self.loopFailures = loopguard_helpers.Failures()


    def __del__(self):
        try:
            SETTINGS.setCacheSetting('jsonQue', self.jsonQue)
            SETTINGS.setCacheSetting('postQue', self.postQue)
            SETTINGS.setCacheSetting('logoQue', self.logoQue)
        except Exception: pass


    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)


    def _que(self, func, priority=-1, *args, **kwargs):# priority -1 autostack (FIFO), 1 Highest, 5 Lowest
        self.priorityQUE._push((func, args, kwargs), priority)


    def _isPlaying(self) -> bool: #assert playback for background service throttling.
        if (self.isPlaying or self.isPaused) and not self.player.runWhilePlaying: return True
        return False
    
        
    def _tasks(self):
        self._que(self.tasks._chkEpochTimer,-1,*('chkQueTimer', self.tasks.chkQueTimer, 15)) #keep CustomQueue alive after interrupt.
    
    
    def _aborted(self) -> bool: #service break, asked without waiting
        # madteevee (imports fork, imports.70): True when Kodi or this service is closing, asked
        # without waiting; the same two signals as _shutdown (cache.py's _aborted is the precedent).
        # For a one-off check before acting. Kodi's Monitor.waitForAbort takes a timeout of 0 or
        # less as "no timeout" (xbmc/interfaces/legacy/Monitor.cpp: timeoutMS <= 0 ->
        # endTime.SetInfinite(); the default argument is -1), so imports.70's first build, which
        # asked with _shutdown(0), waited there until Kodi closed: the replay-end move never ran
        # and kept Player._restart_lock (TV test 2026-11-19). abortRequested() only reads Kodi's
        # flag. No bookkeeping and no log line, so any thread may call it at any time.
        return any([self.monitor.abortRequested(),PROPERTIES.isPendingShutdown()])


    def _shutdown(self, wait=SERVICE_INTERVAL) -> bool: #service break
        # madteevee (imports fork, imports.70): a wait of 0 or less asks without waiting (_aborted)
        # where it used to wait until Kodi closed; a positive wait is the same waitForAbort call as
        # before. A loop must still wait a positive time: Kodi delivers the Player's and the
        # Monitor's callbacks only inside waitForAbort (or xbmc.sleep), on the thread that created
        # them.
        if wait > 0: pendingShutdown = any([self.monitor.waitForAbort(wait),PROPERTIES.isPendingShutdown()])
        else:        pendingShutdown = self._aborted()
        if self.pendingShutdown != pendingShutdown:
            self.pendingShutdown = pendingShutdown
            self.log('_shutdown, pendingShutdown = %s, wait = %s'%(self.pendingShutdown,wait))
        return self.pendingShutdown
    
    
    def _restart(self) -> bool: #service restart
        pendingRestart = PROPERTIES.isPendingRestart()
        if self.pendingRestart != pendingRestart:
            self.pendingRestart = pendingRestart
            self.log('_restart, pendingRestart = %s'%(self.pendingRestart))
        return self.pendingRestart


    def _kodiRestart(self) -> bool: #service paused until Kodi restarts
        # madteevee (imports fork, imports.71): a restored channel backup (Backup.recoverChannels,
        # 'restore') or a moved data folder (Tasks.setUserPath, 'folder') sets this marker next to
        # pendingRestart, because only a Kodi restart finishes either. A restart of the service alone
        # keeps this interpreter's modules, whose data paths were fixed when they were imported
        # (variables.py, cache.py), and the timers it keeps in Window(10000) properties
        # (Tasks._chkEpochTimer): it would go on with the old folder, and the work a Kodi start runs at
        # once, such as the library walk that ends by building channels, would wait for its next turn
        # (Library_Walk_Interval). Before imports.71 the service restarted itself every 20-30 s, doing
        # nothing, until Kodi was restarted. Now it stays paused, as the modules that check pendingRestart
        # do (their _interrupt reads it; the imports thread still wakes, and its sync stops at its first
        # check), and says once what to do. The marker ends with Kodi (Window(10000)'s properties do), or
        # when a new interpreter imports this module (the class body).
        reason = PROPERTIES.getPendingKodiRestart()
        if not reason: return False
        # Sets this object's own pendingInterrupt at once, which Service._sleep reads without asking
        # again (Discovery's waits end on it). The shared Window property it writes too can be set back
        # by another writer (each PROPERTIES.interruptActivity() ends by writing it False); no module
        # relies on it alone: each stand-in service also reads pendingRestart, which stays set.
        self._interrupt()
        if reason != self.kodiRestartNoted:
            self.kodiRestartNoted = reason
            # A line Kodi's log always gets (logger.notice), once per reason: on a box that runs without
            # the add-on's debug logging, the pause and why must still show there (the note is 4 s).
            notice('Service: _kodiRestart, paused until Kodi restarts (%s)'%(reason))
            note = {'restore':30910, 'folder':30911}.get(reason)
            # shown even with 'Notifications During Playback' off: it answers what the user just did
            if note: DIALOG.notificationDialog(LANGUAGE(note), show=True)
        return True


    def _interrupt(self) -> bool: #tasks break
        # Same self-referential bug class as _suspend below: ORing against PROPERTIES
        # .isPendingInterrupt() — the property this method writes via setPendingInterrupt
        # — meant any one-shot interrupt (Manager.saveChanges sets it, Builder honours it,
        # finally clauses release it) could leave pendingInterrupt stuck True if anything
        # in the path failed. Then the OR keeps reading True and never clears, deadlocking
        # the saveChanges → builder.interruptActivity → setChannels chain. Master fork ORs
        # against PROPERTIES.isInterruptActivity() — the flag set/cleared by the
        # interruptActivity() context manager — which has its own finally to clear cleanly.
        pendingInterrupt = any([self.pendingShutdown, self.pendingRestart, self.isScanning, self._isPlaying(), PROPERTIES.isInterruptActivity()])
        if pendingInterrupt != self.pendingInterrupt:
            self.pendingInterrupt = PROPERTIES.setPendingInterrupt(pendingInterrupt)
            self.log('_interrupt, pendingInterrupt = %s'%(self.pendingInterrupt))
        return self.pendingInterrupt
    

    def _suspend(self, wait=0) -> bool: #tasks continue
        # OR against isSuspendActivity (set by the suspendActivity() context manager around
        # plugin invocations), NOT isPendingSuspend — that's the property this method writes
        # via setPendingSuspend below, so ORing against it creates a self-referential lock:
        # once any earlier event set pendingSuspend=True (settings opened, plugin invocation),
        # subsequent _suspend calls see isPendingSuspend()=True, OR keeps it True, the property
        # never clears, and the service stays paused forever even after the trigger is gone.
        # Master fork uses isSuspendActivity() here.
        pendingSuspend = any([BUILTIN.isSettingsOpened(), PROPERTIES.isSuspendActivity(),])
        if pendingSuspend != self.pendingSuspend:
            self.pendingSuspend = PROPERTIES.setPendingSuspend(pendingSuspend)
            self.log('_suspend, pendingSuspend = %s'%(self.pendingSuspend))
        return self.pendingSuspend
        

    def _sleep(self, wait=1.0): #waitForAbort replacement for tasks
        while not self.monitor.abortRequested() and wait > 0:
            if any([self.monitor.waitForAbort(CPU_CYCLE),self.pendingInterrupt]): return True
            else: wait -= CPU_CYCLE
        if wait > 0: self.log('_wait, remaining = %s'%(wait))
        return False
                    

    def _initialize(self):
        if self.isClient: self._que(self.tasks._client,1)
        else:             self._que(self.tasks._host,1)


    def _start(self):
        self.log('_start')
        self._initialize()
        if DIALOG.notificationWait('%s...'%(LANGUAGE(32054)),wait=15):
            if self.player.isPlayingPseudoTV(): self.player.onAVStarted()
            while not self.monitor.abortRequested():
                # madteevee (imports fork, imports.71): one failed pass no longer ends the service. Its
                # exception went up to service.py, which logged it, showed 'Something Went Wrong' and
                # ended the script, and Kodi never starts a stopped service script again
                # (xbmc/addons/Service.cpp:37-52; the interpreter stays up for the other threads,
                # interfaces/python/PythonInvoker.cpp:382-407): the queue stood still while the
                # dashboard answered (2026-06-05, 2026-10-04 for 3 days 17 h, 2026-11-07). Now the
                # failure is written once (_passFailed) and the loop waits its normal interval, then
                # goes on. Exception only: SystemExit and the like still end it, and Kodi closing ends
                # the wait at once. A request that only a Kodi restart finishes pauses the loop
                # instead of restarting the service (_kodiRestart).
                try:
                    self.isScanning = BUILTIN.isScanning()
                    self.isPaused   = BUILTIN.isPaused()
                    self.isPlaying  = self.player.isPlaying()
                    if    self._shutdown() and self._interrupt() and self._sleep(): break
                    elif  self._restart() and self._kodiRestart(): pass #paused until Kodi restarts
                    elif  self.pendingRestart and self._interrupt() and self._sleep(): break
                    else: self._tasks()
                except Exception as e:
                    self._passFailed(e)
                    if self._shutdown(): break
            return self._stop(self.pendingRestart)


    def _passFailed(self, error):
        # madteevee (imports fork, imports.71): a pass of the main loop (_start) failed. Each distinct
        # error (loopguard_helpers.error_key: its class and the add-on line it came from, not its
        # message) is written once per session at ERROR, with its traceback: logger.log adds it, as
        # this runs inside the except, and writes ERROR lines with debug logging off unless
        # Debug_Level asks for fatal lines only. A repeat writes nothing, so an error that comes
        # back every pass can't fill the log (the user's decision, 2026-11-20: each different error
        # once). The memory is kept across service restarts, like the session's log.
        if self.loopFailures.first(loopguard_helpers.error_key(error)):
            self.log('_start, a pass of the main loop failed; the service goes on (each different error is written once'
                     ' per session): %s'%(loopguard_helpers.describe(error)), xbmc.LOGERROR)


    def _stop(self, pendingRestart: bool=False):
        if self.player.isPlayingPseudoTV(): self.player.onPlayBackStopped()
        with PROPERTIES.interruptActivity():
            for thread in thread_enumerate():
                if thread.name != "MainThread" and thread.is_alive():
                    if hasattr(thread, 'cancel'): thread.cancel()
                    try: thread.join(1.0)
                    except Exception: pass
                    self.log('_stop, closing %s...'%(thread.name))
            PROPERTIES.setInstanceID() #clrTrash
        # madteevee (imports fork, imports.71): a restart request is taken here, once. Its property
        # (Utility Menu 'Force background service to reload') was cleared only by this class's body
        # when service.py imported it, and service.py restarts this same object, so _restart() read
        # True again at once: the service restarted every 20-30 s, doing nothing, until Kodi was
        # restarted. Cleared after the threads above were told to stop, so each of them saw it (a
        # Timer thread's _que -> _run -> _interrupt during the joins still reads the restart). Left
        # set when the request asks for a Kodi restart too (_kodiRestart): the restarted run pauses.
        if pendingRestart and not PROPERTIES.getPendingKodiRestart():
            self.pendingRestart = PROPERTIES.setPendingRestart(False)
            # The threads told to stop above include the 15 s timer of a settings save's refresh
            # (Monitor._onSettingsChanged), and the Utility Menu button that leads to this reload is such
            # a save: Kodi saves the add-on's settings when a settings button closes its window
            # (xbmc/addons/settings/AddonSettings.cpp:213-218, addons/gui/GUIDialogAddonSettings.cpp:
            # 381-399). Nothing else would run that refresh (Discovery's saves no longer repeat it every
            # few minutes; _run no longer reads Enable_Executor): re-armed, so the restarted run reads the
            # settings as after a save. Never the end of the service: a failure here is written and the
            # restart goes on.
            try: self.monitor._onSettingsChanged()
            except Exception as e: self.log('_stop, the settings refresh was not re-armed: %s'%(e), xbmc.LOGERROR)
        return pendingRestart