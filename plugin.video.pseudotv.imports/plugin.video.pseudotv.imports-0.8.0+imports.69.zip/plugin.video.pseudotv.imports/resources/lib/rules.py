#   Copyright (C) 2025 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.

# -*- coding: utf-8 -*-
from globals    import *
from jsonrpc    import JSONRPC
from channels   import Channels
from lang_codes import LANG_CHOICES, normalize_lang
import clock_helpers # madteevee (imports fork, imports.63): the one clock + time conversions
#todo pinlock
        

# Enable_Fillers
# Enable_Preroll
# Random_Pre_Chance
# Enable_Postroll
# Random_Post_Chance
# Build_Post_Folders
# Resource_Trailers
# Include_Trailers_KODI


# Resource_Overlay
# Resource_Ratings
# Resource_Bumpers
# Resource_Adverts
  
class RulesList(object):
    def __init__(self, channels=None):
        self.channels = channels
        self.ruleList = [BaseRule(),
                         ShowChannelBug(),
                         ShowOnNext(),
                         SetScreenVingette(),
                         MST3k(),
                         DisableOverlay(),
                         ForceSubtitles(),
                         DisableTrakt(),
                         RollbackPlaycount(),
                         DisableRestart(),
                         DisableOnChange(),
                         ForceRebuild(),
                         DurationOptions(),
                         IncludeOptions(),
                         PreRoll(),
                         PostRoll(),
                         InterleaveValue(),
                         SeasonalRule(),
                         HandleMethodOrder(),
                         HandleLimits(),
                         ForceEpisodeOrder(),
                         ForceRandom(),
                         EvenShowsRule(),
                         PauseRule(),
                         PadScheduling()]
                          
        if channels: self.ruleItems = self.loadRules(channels)
        else:        self.ruleItems = {}
                         

    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def getTemplate(self) -> dict: 
        return Channels().channelRULE.copy()
        
                  
    def dumpRules(self, rules={}):
        #convert rule instances to json
        nrules = {}
        for myId, rule in list(rules.items()):
            ritem = {}
            if isinstance(myId, str): myId = int(myId) #temp correct format change
            ritem[myId] = {"values":dict()}
            for idx, value in enumerate(rule.optionValues):
                if isinstance(idx, str): idx = int(idx) #temp correct format change
                ritem[myId]["values"][idx] = value
            nrules.update(ritem)
        return nrules
            

    def loadRules(self, channels=None, append=False):
        if channels is None: channels = Channels().getChannels()
        #load channel rules and their instances. append = full rule list.
        def __load(ruleList, citem={}):
            tmpruleList = {}
            # madteevee fix: channels.json stores rule IDs as JSON object keys —
            # which JSON forces to strings ("2999"). dumpRules writes them as
            # ints, but the round-trip through json.dump → json.load returns
            # strings. rule.myId is int, so citem.get('rules',{}).get(rule.myId)
            # silently returned None for every persisted rule. Persisted rules
            # never loaded — the only rules that actually fired were the ones
            # injected in-memory by _injectRules (which uses int keys directly).
            # Normalize the citem rules dict to int keys before lookup.
            citem_rules = {int(k) if isinstance(k, str) and k.lstrip('-').isdigit() else k: v
                           for k, v in citem.get('rules', {}).items()}
            if not append and len(citem_rules) == 0: return None
            for rule in ruleList:
                ruleInstance = rule.copy()
                tmpritem = {"values":{}}
                for idx, value in enumerate(ruleInstance.optionValues): #load default rule as template
                    if isinstance(idx, str): idx = int(idx) #temp correct format change
                    tmpritem["values"][idx] = value

                if citem_rules.get(rule.myId):
                    for key, value in list(citem_rules[rule.myId].get('values',{}).items()): #load channel rule
                        try:
                            if isinstance(key, str): key = int(key) #temp correct format change
                            tmpritem["values"].update({key:value}) #update default rule value with channel value.
                            ruleInstance.optionValues[key] = tmpritem["values"][key] #load values to rule instance
                        except Exception as e: log('[%s] loadRules, failed! %s\nrule = %s'%(citem['id'],e,citem_rules[rule.myId]), xbmc.LOGERROR)
                    tmpruleList[rule.myId] = ruleInstance

                elif append: #append missing default rule values
                    tmpruleList[rule.myId] = ruleInstance

            self.log('[%s] loadRules: append = %s, rule myIds = %s'%(citem.get('id'), append,list(tmpruleList.keys())))
            rules[citem['id']] = tmpruleList
            
        rules    = {}
        ruleList = self.ruleList.copy()
        ruleList.pop(0) #remove boilerplate baseRule()
        [__load(ruleList,channel) for channel in channels]
        return rules


    def allRules(self): #load all rules.
        self.log('allRules')
        tmpruleList = self.ruleList.copy()
        tmpruleList.pop(0) #remove boilerplate baseRule()
        return [rule.copy() for rule in tmpruleList]
               
        
    def runActions(self, action, citem={}, parameter=None, inherited=None):
        if inherited is None: inherited = self
        # madteevee: prefer freshly-loaded rules from the passed-in citem when
        # available, so user edits via Channel Manager take effect on the next
        # build even though self.ruleItems (built at RulesList init from the
        # class-level Channels instance) doesn't refresh after disk writes.
        # The citem flowing in from chkChanged → buildChannels was just read
        # from disk, so its 'rules' is authoritative. Falls back to ruleItems
        # only when the citem itself carries no rules dict (rare).
        if citem.get('rules'):
            rules = self.loadRules([citem]).get(citem.get('id','')) or {}
        else:
            rules = self.ruleItems.get(citem.get('id','')) or {}
        for myId, rule in list(sorted(rules.items())):
            if action in rule.actions:
                self.log("[%s] runActions, %s performing channel rule: %s"%(citem.get('id'),inherited.__class__.__name__,rule.name))
                try: parameter = rule.runAction(action, citem, parameter, inherited)
                except Exception as e: log('[%s] runActions, failed! %s\nrule = %s'%(citem.get('id'),e,rule), xbmc.LOGERROR)
        return parameter


class BaseRule(object):
    dialog = Dialog()
    
    def __init__(self):
        self.myId               = 0
        self.name               = ""
        self.description        = ""
        self.optionLabels       = []
        self.optionValues       = []
        self.optionDescriptions = []
        self.actions            = []
        self.selectBoxOptions   = []
        self.storedValues       = []
        

    def getTitle(self):
        return self.name
        

    def onAction(self, optionindex):
        return ''


    def getId(self):
        return self.myId


    def runAction(self, actionid, citem, parameter, inherited):
        return parameter


    def copy(self):
        return BaseRule()


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)


    def validate(self):
        pass


    def reset(self):
        self.__init__()


    def validateTextBox(self, optionindex, length):
        if len(self.optionValues[optionindex]) > length:
            self.optionValues[optionindex] = self.optionValues[optionindex][:length]


    def validateTimeBox(self, optionindex):
        values = []
        broken = False

        try:
            values.append(int(self.optionValues[optionindex][0]))
            values.append(int(self.optionValues[optionindex][1]))
            values.append(int(self.optionValues[optionindex][3]))
            values.append(int(self.optionValues[optionindex][4]))
        except Exception:
            self.optionValues[optionindex] = "00:00"
            return

        if values[0] > 2:
            broken = True

        if values[0] == 2:
            if values[1] > 3:
                broken = True

        if values[2] > 5:
            broken = True

        if broken:
            self.optionValues[optionindex] = "00:00"
            return


    def validateDaysofWeekBox(self, optionindex):
        self.log("validateDaysofWeekBox")
        daysofweek = "UMTWHFS"
        newstr = ''
        for day in daysofweek:
            loc = self.optionValues[optionindex].find(day)
            if loc != -1: newstr += day
        self.optionValues[optionindex] = newstr


    def validateRange(self, optionindex, minimum, maximum, default):
        if int(self.optionValues[optionindex]) < minimum:
            self.log("Invalid minimum range")
            self.dialog.notificationDialog(LANGUAGE(32077)%(self.optionLabels[optionindex]))
            self.optionValues[optionindex] = default
            return
        elif int(self.optionValues[optionindex]) > maximum:
            self.log("Invalid maximum range")
            self.dialog.notificationDialog(LANGUAGE(32077)%(self.optionLabels[optionindex]))
            self.optionValues[optionindex] = default
            return


    def validateDigitBox(self, optionindex, minimum, maximum, default):
        if int(self.optionValues[optionindex]) == 0: return
        try:
            val = int(self.optionValues[optionindex])
            if val >= minimum and val <= maximum:
                self.optionValues[optionindex] = val
            return
        except Exception: pass
        self.dialog.notificationDialog(LANGUAGE(32077)%(self.optionLabels[optionindex]))
        self.optionValues[optionindex] = default

    
    def onActionToggleBool(self, optionindex):
        self.log("onActionToggleBool")
        self.optionValues[optionindex] = not self.optionValues[optionindex]


    def onActionFunction(self, optionindex):
        self.log("onActionFunction")
        value = self.selectBoxOption[optionindex]()
        if value: self.optionValues[optionindex] = value


    def onActionPickColor(self, optionindex, colorlist=[], colorfile=""):
        self.log("onActionPickColor")
        value = self.dialog.colorDialog(colorlist, self.optionValues[optionindex], colorfile, self.name)
        if value: self.optionValues[optionindex] = value
        

    def onActionTextBox(self, optionindex):
        self.log("onActionTextBox")
        value = self.dialog.inputDialog(self.name, default=self.optionValues[optionindex], key=xbmcgui.INPUT_ALPHANUM)
        if value: self.optionValues[optionindex] = value


    def onActionDigitBox(self, optionindex):
        self.log("onActionDigitBox")
        info =  self.dialog.inputDialog(self.optionLabels[optionindex], default=self.optionValues[optionindex], key=xbmcgui.INPUT_NUMERIC)
        if info != None: self.optionValues[optionindex] = info


    def onActionTimeBox(self, optionindex):
        self.log("onActionTimeBox")
        info = self.dialog.inputDialog(self.optionLabels[optionindex], default=self.optionValues[optionindex], key=xbmcgui.INPUT_NUMERIC)
        if info != None:
            if info[0] == ' ': info = info[1:]
            if len(info) == 4: info = "0" + info
            self.optionValues[optionindex] = info


    def onActionSelect(self, optionindex, header=None, preselect=None, useDetails=False, autoclose=SELECT_DELAY, multi=False):
        self.log("onActionSelect")
        if header is None:
            if multi: header = '%s - %s'%(ADDON_NAME,LANGUAGE(32017)%(''))
            else:     header = '%s - %s'%(ADDON_NAME,LANGUAGE(32223)%(''))
        
        if isinstance(self.selectBoxOptions[optionindex],dict): values, options = list(self.selectBoxOptions[optionindex].values()), list(self.selectBoxOptions[optionindex].keys())
        else:                                                   values, options = self.selectBoxOptions[optionindex], self.optionValues[optionindex]
        items  = [str(v).title() for v in self.selectBoxOptions[optionindex]]
        select = self.dialog.selectDialog(items, header, Globals._findItemsInLST(values, options), useDetails, autoclose, multi)
        if not select is None:
            # madteevee fix: when selectBoxOptions[optionindex] is a dict, the
            # dialog returns the integer index of the chosen item, not a dict
            # key. The previous form `self.selectBoxOptions[optionindex][select]`
            # indexed the dict with that int and KeyError'd. The local `options`
            # variable (set at line ~309) is already list(dict.keys()) for the
            # dict case — index it instead, then look up the value via .get().
            # Mirrors upstream/master's working pattern.
            if   isinstance(self.selectBoxOptions[optionindex],dict): self.optionValues[optionindex] = self.selectBoxOptions[optionindex].get(options[select])
            elif isinstance(select,list):                             self.optionValues[optionindex] = [self.selectBoxOptions[optionindex][idx] for idx in select]
            elif select < len(self.selectBoxOptions[optionindex]):    self.optionValues[optionindex] = self.selectBoxOptions[optionindex][select]
            elif select:                                              self.optionValues[optionindex] = select
                
          
    def onActionBrowse(self, optionindex, type=0, heading=ADDON_NAME, shares='', mask='', useThumbs=True, treatAsFolder=False, multi=False, monitor=False, options=[], exclude=[]):
        self.log("onActionBrowse")
        info = self.dialog.browseSources(type, heading, self.optionValues[optionindex], shares, mask, useThumbs, treatAsFolder, multi, monitor, options, exclude)
        if info is not None: self.optionValues[optionindex] = info 
    
    
    def onActionMultiBrowse(self, optionindex, header=ADDON_NAME, exclude=[], monitor=True):
        self.log("onActionMultiBrowse")
        info = self.dialog.multiBrowse(self.optionValues[optionindex], header, exclude, monitor)
        if info is not None: self.optionValues[optionindex] = info 


    def onActionResources(self, optionindex, ftype=''):
        log("onActionResources")
        info = self.dialog.browseResources(self.optionValues[optionindex].split('|'), ftype=ftype)
        if not info is None: self.optionValues[optionindex] = '|'.join(info)

#Rules apply sequentially by myId
class ShowChannelBug(BaseRule): #OVERLAY RULES [1-49]
    def __init__(self):
        self.myId               = 1
        self.name               = LANGUAGE(30143)
        self.description        = LANGUAGE(30144)
        self.optionLabels       = [LANGUAGE(30043),LANGUAGE(30112),LANGUAGE(30044),LANGUAGE(30208)]
        self.optionValues       = [SETTINGS.getSettingBool('Enable_ChannelBug'),SETTINGS.getSetting("Channel_Bug_Position_XY"),SETTINGS.getSetting('ChannelBug_Color'),SETTINGS.getSettingBool('Force_Diffuse'),SETTINGS.getSettingInt('ChannelBug_Transparency')]
        self.optionDescriptions = [LANGUAGE(33043),LANGUAGE(33112),LANGUAGE(33044),LANGUAGE(33209)]
        self.actions            = [RULES_ACTION_OVERLAY_OPEN,RULES_ACTION_OVERLAY_CLOSE]
        self.selectBoxOptions   = [[True,False],[LANGUAGE(30022),LANGUAGE(32136)],"","",list(range(15,51,5))]
        self.storedValues       = [[],[],[],[],[],[]]
        

    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return ShowChannelBug()


    def getTitle(self):
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])


    def getPosition(self, optionindex):
        orgvalue = self.optionValues[optionindex]
        self.onActionSelect(optionindex, LANGUAGE(32223)%(''))
        if self.optionValues[optionindex] == self.selectBoxOptions[optionindex][1]:
            from overlaytool import OverlayTool
            try: overlaytool = OverlayTool(OVERLAYTOOL_XML, ADDON_PATH, "default", ADV_RULES=True, Focus_IDX=1, Channel_Bug_Position_XY=self.optionValues[optionindex], ChannelBug_Color=self.optionValues[3])
            except Exception as e: self.log("getPosition, failed! %s"%(e), xbmc.LOGERROR)
            finally: del overlaytool
            value = PROPERTIES.getProperty("Channel_Bug_Position_XY")
            PROPERTIES.clrProperty("Channel_Bug_Position_XY")
            if value: self.optionValues[optionindex] = value
            else:     self.optionValues[optionindex] = orgvalue
        elif self.optionValues[optionindex] != self.selectBoxOptions[optionindex][0]:
            self.optionValues[optionindex] = orgvalue


    def onAction(self, optionindex):
        if   optionindex == 0: self.onActionToggleBool(optionindex)
        elif optionindex == 1: self.getPosition(optionindex)
        elif optionindex == 2: self.onActionPickColor(optionindex)
        elif optionindex == 3: self.onActionToggleBool(optionindex)
        elif optionindex == 4: self.onActionSelect(optionindex, LANGUAGE(33209))
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, overlay):
        if actionid == RULES_ACTION_OVERLAY_OPEN:
            self.storedValues[0] = overlay.enableChannelBug
            self.storedValues[1] = (overlay.channelBugX, overlay.channelBugY)
            self.storedValues[2] = overlay.channelBugColor
            self.storedValues[3] = overlay.channelBugDiffuse
            self.storedValues[4] = overlay.channelBugFade
            
            overlay.enableChannelBug   = self.optionValues[0]
            overlay.channelBugX, overlay.channelBugY = literal_eval(self.optionValues[1])
            overlay.channelBugColor    = '0x%s'%(self.optionValues[2])
            overlay.channelBugDiffuse  = self.optionValues[3]
            overlay.channelBugFade     = self.optionValues[4]
            self.log("runAction, setting enableChannelBug = %s, channelBugColor = %s, channelBugDiffuse = %s"%(overlay.enableChannelBug,(overlay.channelBugX, overlay.channelBugY),overlay.channelBugColor,overlay.channelBugDiffuse,overlay.channelBugFade))
            
        elif actionid == RULES_ACTION_OVERLAY_CLOSE:
            overlay.enableChannelBug   = self.storedValues[0]
            overlay.channelBugX, overlay.channelBugY = self.storedValues[1]
            overlay.channelBugColor   = self.storedValues[2]
            overlay.channelBugDiffuse = self.storedValues[3]
            overlay.channelBugFade    = self.storedValues[4]
            self.log("runAction, restoring enableChannelBug = %s, channelBugColor = %s, channelBugDiffuse = %s"%(overlay.enableChannelBug,(overlay.channelBugX, overlay.channelBugY),overlay.channelBugColor,overlay.channelBugDiffuse,overlay.channelBugFade))
        return parameter


class ShowOnNext(BaseRule):
    def __init__(self):
        self.myId               = 2
        self.name               = LANGUAGE(30045)
        self.description        = LANGUAGE(33045)
        # madteevee (imports fork, imports.64): three options, each list in step (from upstream
        # 4c58e817): the third was labelled 'Select Diffuse Color' and its mode list sat one slot
        # further on, so picking a mode showed an empty list.
        self.optionLabels       = [LANGUAGE(30045),LANGUAGE(32229),LANGUAGE(30196)]
        self.optionValues       = [bool(SETTINGS.getSettingInt('OnNext_Mode')),SETTINGS.getSetting("OnNext_Position_XY"),SETTINGS.getSettingInt('OnNext_Mode')]
        self.optionDescriptions = [LANGUAGE(30045),LANGUAGE(33229),LANGUAGE(30196)]
        # madteevee (imports fork, imports.65): no PLAYER_STOP. The player owns the reset (Player._applyChannelRules,
        # rulestate_helpers); runActions re-creates the rules on every call, so a stop here could only restore a lost value.
        self.actions            = [RULES_ACTION_PLAYER_START]
        self.selectBoxOptions   = ["",[LANGUAGE(30022),LANGUAGE(32136)],{LANGUAGE(30021):0,LANGUAGE(30193):1,LANGUAGE(30194):2,LANGUAGE(30197):3,LANGUAGE(30195):4}]
        self.storedValues       = [[],[],[],[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return ShowOnNext()


    def getTitle(self):
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])


    def getPosition(self, optionindex):
        orgvalue = self.optionValues[optionindex]
        self.onActionSelect(optionindex, LANGUAGE(32223)%(''))
        if self.optionValues[optionindex] == self.selectBoxOptions[optionindex][1]:
            from overlaytool import OverlayTool
            try: overlaytool = OverlayTool(OVERLAYTOOL_XML, ADDON_PATH, "default", ADV_RULES=True, Focus_IDX=0, OnNext_Position_XY=self.optionValues[optionindex], OnNext_Color=self.optionValues[2])
            except Exception as e: self.log("getPosition, failed! %s"%(e), xbmc.LOGERROR)
            finally: del overlaytool
            value = PROPERTIES.getProperty("OnNext_Position_XY")
            PROPERTIES.clrProperty("OnNext_Position_XY")
            if value: self.optionValues[optionindex] = value
            else:     self.optionValues[optionindex] = orgvalue
        elif self.optionValues[optionindex] != self.selectBoxOptions[optionindex][0]:
            self.optionValues[optionindex] = orgvalue


    def onAction(self, optionindex):
        if   optionindex == 0: self.onActionToggleBool(optionindex)
        elif optionindex == 1: self.getPosition(optionindex)
        elif optionindex == 2: self.onActionSelect(optionindex, LANGUAGE(30196))
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, player):
        # madteevee (imports fork, imports.64): the player's attribute is OnNextMode (upstream
        # 4c58e817 made the same fix): reading 'onNextMode' raised AttributeError, so the rule
        # never applied, and the stop wrote the old mode to an attribute nothing reads. The rule's
        # own 'Show OnNext' switch now counts: off means mode 0 on this channel.
        if actionid == RULES_ACTION_PLAYER_START:
            # The web dashboard saves a list choice as text ('1'): the overlay compares numbers.
            try:    mode = int(self.optionValues[2])
            except (TypeError, ValueError): mode = SETTINGS.getSettingInt('OnNext_Mode')
            player.onNextPosition = self.optionValues[1]
            player.OnNextMode     = mode if self.optionValues[0] else 0
            self.log("runAction, setting onNextPosition = %s, OnNextMode = %s"%(player.onNextPosition, player.OnNextMode))
        return parameter


class SetScreenVingette(BaseRule):
    def __init__(self):
        self.myId               = 3
        self.name               = LANGUAGE(30177)
        self.description        = LANGUAGE(33177)
        self.optionLabels       = [LANGUAGE(30174),LANGUAGE(30175),LANGUAGE(30176),LANGUAGE(30178),LANGUAGE(30185),LANGUAGE(30186)]
        self.optionValues       = [False,' ',1.00,0.00,1.00,False]
        self.optionDescriptions = [LANGUAGE(33174),LANGUAGE(33175),LANGUAGE(33176),LANGUAGE(33179),LANGUAGE(33185),LANGUAGE(34186)]
        self.actions            = [RULES_ACTION_OVERLAY_OPEN,RULES_ACTION_OVERLAY_CLOSE]
        self.selectBoxOptions   = ['','',list(frange(5,21,1)),list(range(-2,3,1)),list(frange(5,21,1)),'']#[LANGUAGE(30022),LANGUAGE(32136)]]
        self.storedValues       = [[],[],[]]
        

    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return SetScreenVingette()


    def getTitle(self):
        return '%s (%s)'%(self.name,self.optionValues)
            
            # todo set viewmode as {} response from json.
    def getPosition(self, optionindex):#todo vin utility to adjust zoom,vshift,pratio and nls
        self.dialog.notificationDialog(LANGUAGE(32020))


    def getImage(self, image=''):
        self.log('getImage, In image = %s'%(image))
        day    = re.compile(r'\_Day(.*?)', re.IGNORECASE).search(image)
        night  = re.compile(r'\_Night(.*?)', re.IGNORECASE).search(image)
        mytime = time.localtime()
        if mytime.tm_hour < 6 or mytime.tm_hour > 18:
            if day:
                nImage = image.replace(day.group(),'_Night')
                if FileAccess.exists(nImage): image = nImage
        else:
            if night:
                nImage = image.replace(night.group(),'_Day')
                if FileAccess.exists(nImage): image = nImage
        self.log('getImage, Out image = %s'%(image))
        return image


    def onAction(self, optionindex):
        if   optionindex == 1:       self.onActionBrowse(optionindex, type=1, heading=self.optionLabels[1], mask=xbmc.getSupportedMedia('picture'), exclude=[12,13,14,15,16,17])
        elif optionindex in [0,5]:   self.onActionToggleBool(optionindex)
        elif optionindex in [2,3,4]: self.onActionSelect(optionindex, self.optionLabels[optionindex])
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, overlay):
        if actionid == RULES_ACTION_OVERLAY_OPEN:
            self.storedValues[0] = overlay.enableVignette
            self.storedValues[1] = overlay.vinImage
            self.storedValues[2] = overlay.vinView
            
            overlay.enableVignette = self.optionValues[0]
            overlay.vinImage      = self.getImage(self.optionValues[1])
            overlay.vinView   = {"nonlinearstretch":self.optionValues[5] ,"pixelratio":self.optionValues[4],"verticalshift":self.optionValues[3],"viewmode":"custom","zoom": self.optionValues[2]}
            self.log('runAction, setting vignette image = %s\nmode = %s'%(overlay.vinImage,overlay.vinView))
            
        elif actionid == RULES_ACTION_OVERLAY_CLOSE:
            overlay.enableVignette = self.storedValues[0]
            overlay.vinImage      = self.storedValues[1]
            overlay.vinView   = self.storedValues[2]
            self.log('runAction, restoring vignette image = %s\nmode = %s'%(overlay.vinImage,overlay.vinView))
        return parameter
        

class MST3k(BaseRule):
    def __init__(self):
        self.myId               = 4
        self.name               = "Mystery Science Theater 3K Silhouette"
        self.description        = "Animated Silhouette of MST3K"
        self.optionLabels       = ['Enable MST3K Silhouette']
        self.optionValues       = [False]
        self.optionDescriptions = ["Enable Silhouette"]
        self.actions            = [RULES_ACTION_OVERLAY_OPEN,RULES_ACTION_OVERLAY_OPEN+.1,RULES_ACTION_OVERLAY_CLOSE]
        self.storedValues       = [[],[],[]]
        self.threadTimer        = Timer(SERVICE_INTERVAL, self.runAction)
        self.optionImages       = [os.path.join(MEDIA_LOC,'overlays','MST3K_1.gif'), os.path.join(MEDIA_LOC,'overlays','MST3K_2.gif')]

   
    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return MST3k()


    def getTitle(self):
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])


    def setImage(self, actionid, citem, overlay, image):
        if not self.threadTimer.is_alive():
            self.threadTimer = Timer(SERVICE_INTERVAL, overlay.runActions,[actionid, citem, None, overlay])
            self.threadTimer.name = 'MST3k.setImage'
            self.threadTimer.start()
        self.log('setImage, image = %s'%(image))
        return image


    def onAction(self, optionindex):
        if optionindex == 0: self.onActionToggleBool(optionindex)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, overlay):
        if actionid == RULES_ACTION_OVERLAY_OPEN:
            self.storedValues[0] = overlay.vinImage
            self.storedValues[1] = overlay._vinOffsetXY
            self.storedValues[2] = overlay._vinZoom
            
            overlay.vinImage    = self.setImage(actionid+.1, citem, overlay, self.optionImages[0])
            overlay._vinOffsetXY = (0,0)
            overlay._vinZoom     = 1.0
            self.log("runAction, setting overlay enabled = %s, image %s @ (%s) X %s"%(overlay.enableVignette, overlay.vinImage, overlay._vinOffsetXY, overlay._vinZoom))
            
        elif actionid == RULES_ACTION_OVERLAY_OPEN+.1:
            overlay.vinImage = self.setImage(actionid, citem, overlay, self.optionImages[1])
            overlay._setImage(overlay.vignette,overlay.vinImage)
            self.log("runAction, setting overlay enabled = %s, image %s @ (%s) X %s"%(overlay.enableVignette, overlay.vinImage, overlay._vinOffsetXY, overlay._vinZoom))
            
        elif actionid == RULES_ACTION_OVERLAY_CLOSE:
            overlay.vinImage    = self.storedValues[0]
            overlay._vinOffsetXY = self.storedValues[1]
            overlay._vinZoom     = self.storedValues[2]
            self.log("runAction, restoring overlay enabled = %s, image %s @ (%s) X %s"%(overlay.enableVignette, overlay.vinImage, overlay._vinOffsetXY, overlay._vinZoom))
            
            if self.threadTimer.is_alive():
                if hasattr(self.threadTimer, 'cancel'): self.threadTimer.cancel()
                try: self.threadTimer.join()
                except Exception: pass
        return parameter
        

class DisableOverlay(BaseRule): #PLAYER RULES [50-99]
    def __init__(self):
        self.myId               = 50
        self.name               = LANGUAGE(30042)
        self.description        = LANGUAGE(33042)
        self.optionLabels       = [LANGUAGE(30042)]
        self.optionValues       = [SETTINGS.getSettingBool('Overlay_Enable')]
        self.optionDescriptions = [LANGUAGE(33042)]
        # madteevee (imports fork, imports.65): no PLAYER_STOP. The player owns the reset (Player._applyChannelRules,
        # rulestate_helpers); runActions re-creates the rules on every call, so a stop here could only restore a lost value.
        self.actions            = [RULES_ACTION_PLAYER_START]
        self.storedValues       = [[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return DisableOverlay()


    def getTitle(self):
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])


    def onAction(self, optionindex):
        self.onActionToggleBool(optionindex)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, player):
        if actionid == RULES_ACTION_PLAYER_START:
            player.enableOverlay = self.optionValues[0]
            self.log("runAction, setting enableOverlay = %s"%(player.enableOverlay))
        return parameter


# madteevee fork: ForceSubtitles extended with Smart-by-Audio-Language mode.
# Legacy option 0 (Force Subtitles bool) preserved for back-compat — only
# read when Mode (option 1) is "Use Legacy Toggle". Six new options drive
# per-item plan generation at build time (BUILD_FILELIST_POST action); the
# plan is consumed at playback by Player.setSubtitles / _applySmartSubsFromPlan.
# See lang_codes.py for ISO 639-1/2 normalization.
SMART_MODES = {
    'Use Legacy Toggle':         'legacy',
    'Always On':                 'always_on',
    'Always Off':                'always_off',
    'Smart by Audio Language':   'smart',
}

SMART_FALLBACKS = {
    'First available':           'first',
    'Off':                       'off',
    'Kodi default':              'default',
}

SMART_UNKNOWN_AUDIO = {
    'Treat as foreign (subs on)':   'foreign',
    'Treat as native (subs off)':   'native',
    'Use legacy toggle value':      'legacy',
}


class ForceSubtitles(BaseRule):
    def __init__(self):
        self.myId               = 51
        self.name               = "Force Subtitles"
        self.description        = "Subtitle and audio policy (legacy toggle or Smart by Audio Language)."
        self.optionLabels       = [
            'Force Subtitles (legacy)',
            'Mode',
            'Native audio language',
            'Preferred subtitle language',
            'Preferred audio language',
            'Fallback when no matching sub',
            'Unknown audio language policy',
        ]
        self.optionValues       = [
            BUILTIN.isSubtitle(),
            'legacy',
            '',
            '',
            '',
            'first',
            'foreign',
        ]
        self.optionDescriptions = [
            'Honored only when Mode = Use Legacy Toggle. Identical to the original Force Subtitles behavior.',
            'Use Legacy Toggle reproduces the original rule. Smart by Audio Language reads the file metadata at build time and decides per program.',
            'Audio in this language is treated as understood: subs OFF. (Smart mode only.)',
            'Pick the sub stream matching this language when subs are turned on. (Smart mode only.)',
            'If the file has audio in this language, switch to it before evaluating subs. (Smart mode only.)',
            'What to do in Smart mode when no subtitle stream matches the preferred sub language.',
            'What to do in Smart mode when the audio stream has no language tag (empty / und).',
        ]
        # madteevee (imports fork, imports.65): no PLAYER_STOP. The player owns the reset (Player._applyChannelRules,
        # rulestate_helpers); runActions re-creates the rules on every call, so a stop here could only restore a lost value.
        self.actions            = [
            RULES_ACTION_PLAYER_START,
            RULES_ACTION_CHANNEL_BUILD_FILELIST_POST,
        ]
        self.selectBoxOptions   = [
            [],
            SMART_MODES,
            LANG_CHOICES,
            LANG_CHOICES,
            LANG_CHOICES,
            SMART_FALLBACKS,
            SMART_UNKNOWN_AUDIO,
        ]
        self.storedValues       = [[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)


    def copy(self):
        return ForceSubtitles()


    def getTitle(self):
        mode = self._modeValue()
        if mode == 'legacy':
            return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[bool(self.optionValues[0])])
        return '%s (Mode: %s)'%(self.name, mode)


    def onAction(self, optionindex):
        if optionindex == 0:
            self.onActionToggleBool(optionindex)
        else:
            self.onActionSelect(optionindex)
        return self.optionValues[optionindex]


    def _modeValue(self):
        v = (self.optionValues[1] if len(self.optionValues) > 1 else 'legacy')
        return v if v in ('legacy','always_on','always_off','smart') else 'legacy'


    def _planForItem(self, item):
        """
        Compute the smart_subs plan for one fileList entry. Returns a dict or None
        when no plan is needed (item has no streamdetails → caller leaves the item
        alone; playback falls through to legacy behavior).
        """
        streamdetails = (item.get('streamdetails') or {})
        audio_streams = streamdetails.get('audio') or []
        sub_streams   = streamdetails.get('subtitle') or []
        if not audio_streams: return None

        # Normalize all detected languages to ISO 639-1
        audio_langs = []
        for s in audio_streams:
            l = normalize_lang(s.get('language',''))
            if l: audio_langs.append(l)
        sub_langs = []
        for s in sub_streams:
            l = normalize_lang(s.get('language',''))
            if l: sub_langs.append(l)

        native      = normalize_lang(self.optionValues[2])
        pref_sub    = normalize_lang(self.optionValues[3])
        pref_audio  = normalize_lang(self.optionValues[4])
        fallback    = self.optionValues[5] if self.optionValues[5] in ('first','off','default') else 'first'
        unknown_pol = self.optionValues[6] if self.optionValues[6] in ('foreign','native','legacy') else 'foreign'
        legacy_bool = bool(self.optionValues[0])

        # Effective audio language: if we want to switch to a preferred audio and
        # that language exists on the file, evaluate AGAINST the preferred. Otherwise
        # the first detected language is the de-facto default Kodi will pick.
        will_switch_audio = bool(pref_audio and pref_audio in audio_langs)
        effective_audio   = pref_audio if will_switch_audio else (audio_langs[0] if audio_langs else '')

        # Subs on/off
        if not effective_audio:
            if   unknown_pol == 'foreign': sub_state = True;        rationale = 'unknown_audio_foreign'
            elif unknown_pol == 'native':  sub_state = False;       rationale = 'unknown_audio_native'
            else:                          sub_state = legacy_bool; rationale = 'unknown_audio_legacy'
        else:
            is_native = (native and effective_audio == native)
            sub_state = not is_native
            rationale = 'native_audio' if is_native else 'foreign_audio'

        # Pick sub language target + apply fallback if needed
        sub_lang_target = ''
        if sub_state:
            if pref_sub and pref_sub in sub_langs:
                sub_lang_target = pref_sub
                rationale += '+pref_sub_match'
            elif sub_streams:
                if   fallback == 'first':
                    if sub_langs:
                        sub_lang_target = sub_langs[0]
                        rationale += '+fallback_first'
                    else:
                        rationale += '+fallback_first_unknown_lang'
                elif fallback == 'off':
                    sub_state = False
                    rationale += '+fallback_off'
                else:  # 'default'
                    rationale += '+fallback_kodi_default'
            else:
                # No sub streams scraped — Kodi may still auto-load external subs at playback
                rationale += '+no_sub_streams_in_metadata'

        return {
            'sub_state':         sub_state,
            'sub_lang_target':   sub_lang_target,
            'audio_lang_target': pref_audio if will_switch_audio else '',
            'rationale':         rationale,
        }


    def _formatLabel(self, plan):
        if not plan: return ''
        bits = []
        a = (plan.get('audio_lang_target') or '').upper()
        if a: bits.append('Audio %s'%(a))
        if plan.get('sub_state'):
            s = (plan.get('sub_lang_target') or '').upper()
            bits.append('Subs %s'%(s) if s else 'Subs ON')
        else:
            bits.append('Subs OFF')
        return ' / '.join(bits)


    def runAction(self, actionid, citem, parameter, inherited):
        if actionid == RULES_ACTION_PLAYER_START:
            # parameter is the playingItem dict.
            mode = self._modeValue()
            inherited.smartSubsMode = mode
            if mode == 'legacy':
                inherited.lastSubState = bool(self.optionValues[0])
                self.log("runAction PLAYER_START, mode=legacy lastSubState=%s"%(inherited.lastSubState))
            else:
                self.log("runAction PLAYER_START, mode=%s"%(mode))

        elif actionid == RULES_ACTION_CHANNEL_BUILD_FILELIST_POST:
            # parameter is the fileList (list of fitems). For Smart mode write a
            # smart_subs plan + smart_subs_label to each item with usable
            # streamdetails. For any other mode, scrub stale plans left over
            # from a previous Smart build.
            mode = self._modeValue()
            if isinstance(parameter, list):
                if mode == 'smart':
                    n_planned = 0
                    for it in parameter:
                        plan = self._planForItem(it)
                        if plan:
                            it['smart_subs']       = plan
                            it['smart_subs_label'] = self._formatLabel(plan)
                            n_planned += 1
                        else:
                            it.pop('smart_subs', None)
                            it.pop('smart_subs_label', None)
                    self.log("[%s] BUILD_FILELIST_POST: planned %d/%d items"%(citem.get('id'), n_planned, len(parameter)))
                else:
                    for it in parameter:
                        it.pop('smart_subs', None)
                        it.pop('smart_subs_label', None)
        return parameter


class DisableTrakt(BaseRule):
    def __init__(self):
        self.myId               = 52
        self.name               = "Trakt scrobbling"
        self.description        = "Disable Trakt scrobbling."
        self.optionLabels       = [LANGUAGE(30131)]
        self.optionValues       = [SETTINGS.getSettingBool('Disable_Trakt')]
        self.optionDescriptions = [LANGUAGE(33131)]
        # madteevee (imports fork, imports.65): no PLAYER_STOP. The player owns the reset (Player._applyChannelRules,
        # rulestate_helpers); runActions re-creates the rules on every call, so a stop here could only restore a lost value.
        self.actions            = [RULES_ACTION_PLAYER_START]
        self.storedValues       = [[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return DisableTrakt()


    def getTitle(self):
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])


    def onAction(self, optionindex):
        self.onActionToggleBool(optionindex)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, player):
        if actionid == RULES_ACTION_PLAYER_START:
            player.disableTrakt = self.optionValues[0]
            self.log("runAction, setting disableTrakt = %s"%(player.disableTrakt))
        return parameter


class RollbackPlaycount(BaseRule):
    def __init__(self):
        self.myId               = 53
        self.name               = "Rollback Playcount"
        self.description        = "Passive Playback w/o playcount & progress tracking."
        self.optionLabels       = [LANGUAGE(30132)]
        self.optionValues       = [SETTINGS.getSettingBool('Rollback_Watched')]
        self.optionDescriptions = [LANGUAGE(33132)]
        # madteevee (imports fork, imports.65): no PLAYER_STOP. The player owns the reset (Player._applyChannelRules,
        # rulestate_helpers); runActions re-creates the rules on every call, so a stop here could only restore a lost value.
        self.actions            = [RULES_ACTION_PLAYER_START]
        self.storedValues       = [[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return RollbackPlaycount()


    def getTitle(self):
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])


    def onAction(self, optionindex):
        self.onActionToggleBool(optionindex)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, player):
        if actionid == RULES_ACTION_PLAYER_START:
            player.rollbackPlaycount = self.optionValues[0]
            self.log("runAction, setting rollbackPlaycount = %s"%(player.rollbackPlaycount))
        return parameter


class DisableRestart(BaseRule):
    def __init__(self):
        self.myId               = 54
        self.name               = "Restart Button"
        self.description        = LANGUAGE(33153)
        self.optionLabels       = [LANGUAGE(30153)]
        self.optionValues       = [SETTINGS.getSettingInt('Replay_Percentage')]
        self.optionDescriptions = [LANGUAGE(33153)]
        # madteevee (imports fork, imports.65): no PLAYER_STOP. The player owns the reset (Player._applyChannelRules,
        # rulestate_helpers); runActions re-creates the rules on every call, so a stop here could only restore a lost value.
        self.actions            = [RULES_ACTION_PLAYER_START]
        self.selectBoxOptions   = [list(range(25,100,5))]
        self.storedValues       = [[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return DisableRestart()


    def getTitle(self):
        return '%s (%s)'%(self.name,self.optionValues[0])


    def onAction(self, optionindex):
        self.onActionSelect(optionindex, self.optionLabels[optionindex])
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, player):
        if actionid == RULES_ACTION_PLAYER_START:
            player.replayPercentage = self.optionValues[0]
            self.log("runAction, setting replayPercentage = %s"%(player.replayPercentage))
        return parameter

        
class DisableOnChange(BaseRule):
    def __init__(self):
        self.myId               = 55
        self.name               = LANGUAGE(30170)
        self.description        = LANGUAGE(33171)
        self.optionLabels       = [LANGUAGE(30170)]
        self.optionValues       = [SETTINGS.getSettingBool('Enable_OnInfo')]
        self.optionDescriptions = [LANGUAGE(33171)]
        # madteevee (imports fork, imports.65): no PLAYER_STOP. The player owns the reset (Player._applyChannelRules,
        # rulestate_helpers); runActions re-creates the rules on every call, so a stop here could only restore a lost value.
        self.actions            = [RULES_ACTION_PLAYER_START]
        self.storedValues       = [[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return DisableOnChange() # madteevee (imports fork, imports.65): was DisableOverlay(), so rule 55 acted as a second rule 50 (upstream's fix)


    def getTitle(self):
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])


    def onAction(self, optionindex):
        self.onActionToggleBool(optionindex)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, player):
        if actionid == RULES_ACTION_PLAYER_START:
            player.infoOnChange = self.optionValues[0]
            self.log("runAction, setting infoOnChange = %s"%(player.infoOnChange))
        return parameter


class ForceRebuild(BaseRule):
    def __init__(self):
        self.myId               = 497
        self.name               = "Force Rebuild"
        self.description        = "Force Rebuild All Channel Content."
        self.optionLabels       = ["Force Rebuild Channel"]
        self.optionValues       = [False]
        self.optionDescriptions = ["Always Force Rebuild Channel"]
        self.actions            = [RULES_ACTION_CHANNEL_CITEM]
        self.storedValues       = []


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return ForceRebuild()


    def getTitle(self):
        return '%s (%s)'%(self.name,self.optionValues)


    def onAction(self, optionindex):
        self.onActionToggleBool(optionindex)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, builder):
        if actionid == RULES_ACTION_CHANNEL_CITEM:
            if self.optionValues[0]: parameter['changed'] = True
            self.log("runAction, setting changed = %s"%(self.optionValues[0]))
        return parameter
            
            
class DurationOptions(BaseRule): #PRE-BUILD RULES [500-599]
    def __init__(self):
        self.myId               = 500
        self.name               = "Duration Options"
        self.description        = "Duration Options"
        self.optionLabels       = [LANGUAGE(30049),LANGUAGE(30052),LANGUAGE(32233)]
        self.optionValues       = [SETTINGS.getSettingInt('Duration_Type'),SETTINGS.getSettingBool('Store_Duration'),SETTINGS.getSettingInt('Seek_Tolerance')]
        # madteevee (imports fork, imports.60): one description per option (a stray
        # leading LANGUAGE(33015), "Pagination Limit", shifted them by one). Option 1
        # (Store_Duration) no longer does anything: lengths are not written to Kodi's
        # library any more, and #30052/#33052 say so. It stays in place so saved rule
        # values keep their positions.
        self.optionDescriptions = [LANGUAGE(33049),LANGUAGE(33052),LANGUAGE(32233)]
        self.actions            = [RULES_ACTION_CHANNEL_START,RULES_ACTION_CHANNEL_STOP]
        self.selectBoxOptions   = [{LANGUAGE(30050):0,LANGUAGE(30051):1},[],list(range(0,900,5))]
        self.storedValues       = [[],[],[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return DurationOptions()


    def getTitle(self):
        return '%s (%s)'%(self.name,self.optionValues)


    def onAction(self, optionindex):
        if optionindex == 0:
            self.onActionSelect(optionindex, LANGUAGE(30049))
            self.validateRange(optionindex, 0, 1, 0)
        else:
            self.onActionToggleBool(optionindex)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, inherited):
        if actionid == RULES_ACTION_CHANNEL_START:
            self.storedValues[0] = inherited.accurateDuration
            self.storedValues[1] = inherited.saveDuration
            self.storedValues[2] = inherited.minDuration
            inherited.accurateDuration = self.optionValues[0]
            inherited.saveDuration     = self.optionValues[1]
            inherited.minDuration      = self.optionValues[2]
            self.log("runAction, setting accurateDuration = %s, saveDuration = %s, minDuration = %s"%(inherited.accurateDuration,inherited.saveDuration,inherited.minDuration))
            
        elif actionid == RULES_ACTION_CHANNEL_STOP:
            inherited.accurateDuration = self.storedValues[0]
            inherited.saveDuration     = self.storedValues[1]
            inherited.minDuration      = self.storedValues[2]
            self.log("runAction, restoring accurateDuration = %s, saveDuration = %s, minDuration = %s"%(inherited.accurateDuration,inherited.saveDuration,inherited.minDuration))
        return parameter


class IncludeOptions(BaseRule):
    def __init__(self):
        self.myId               = 501
        self.name               = "Include Options"
        self.description        = "Include Options"
        self.optionLabels       = [LANGUAGE(30053),LANGUAGE(30054),LANGUAGE(30055),LANGUAGE(30225)]
        self.optionValues       = [SETTINGS.getSettingBool('Enable_Extras'),SETTINGS.getSettingBool('Enable_Strms'),SETTINGS.getSettingBool('Enable_3D'),SETTINGS.getSettingBool('Enable_Details')]
        self.optionDescriptions = [LANGUAGE(33053),LANGUAGE(33054),LANGUAGE(33055),LANGUAGE(33225)]
        self.actions            = [RULES_ACTION_CHANNEL_START,RULES_ACTION_CHANNEL_STOP]
        self.storedValues       = [[],[],[],[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return IncludeOptions()


    def getTitle(self):
        return '%s (%s)'%(self.name,self.optionValues)


    def onAction(self, optionindex):
        self.onActionToggleBool(optionindex)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, builder):
        if actionid == RULES_ACTION_CHANNEL_START:
            self.storedValues[0]   = builder.incExtras
            self.storedValues[1]   = builder.incStrms
            self.storedValues[2]   = builder.inc3D
            self.storedValues[3]   = builder.incStrmDetails
            builder.incExtras      = self.optionValues[0]
            builder.incStrms       = self.optionValues[1]
            builder.inc3D          = self.optionValues[2]
            builder.incStrmDetails = self.optionValues[3]
            self.log("runAction, setting incExtras = %s, incStrms = %s, inc3D = %s"%(builder.incExtras,builder.incStrms,builder.inc3D))
            
        elif actionid == RULES_ACTION_CHANNEL_STOP:
            builder.incExtras      = self.storedValues[0]
            builder.incStrms       = self.storedValues[1]
            builder.inc3D          = self.storedValues[2]
            builder.incStrmDetails = self.storedValues[3]
            self.log("runAction, restoring incExtras = %s, incStrms = %s, inc3D = %s"%(builder.incExtras,builder.incStrms,builder.inc3D))
        return parameter


class PreRoll(BaseRule):
    def __init__(self):
        self.myId               = 502
        self.name               = "Pre-Roll"
        self.description        = "Pre-Roll Options"
        self.optionLabels       = [LANGUAGE(30017),LANGUAGE(30139),LANGUAGE(30028),LANGUAGE(30029),"Ratings Folder","Bumpers Folder"]
        self.optionValues       = [SETTINGS.getSettingInt('Enable_Preroll'),SETTINGS.getSettingInt('Random_Pre_Chance'),SETTINGS.getSetting('Resource_Ratings'),SETTINGS.getSetting('Resource_Bumpers'),[os.path.join(FILLER_LOC,'Ratings','')],[os.path.join(FILLER_LOC,'Bumpers','')]]
        self.optionDescriptions = [LANGUAGE(30018),LANGUAGE(33134),LANGUAGE(33028),LANGUAGE(33029),"",""]
        self.actions            = [RULES_ACTION_CHANNEL_START,RULES_ACTION_CHANNEL_STOP]
        self.selectBoxOptions   = [{LANGUAGE(30022):-1,LANGUAGE(30021):0},list(range(0,101,1)),"","","",""]
        self.storedValues       = [{},{}]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return PreRoll()


    def getTitle(self):
        return self.name
        
        
    def onAction(self, optionindex):
        if   optionindex in [0,1]: self.onActionSelect(optionindex)
        elif optionindex in [2,3]: self.onActionResources(optionindex, ftype={2:"ratings",3:"bumpers"}[optionindex])
        elif optionindex in [4,5]: self.onActionMultiBrowse(optionindex, header="%s for %s"%(LANGUAGE(32080), {4:"Ratings",5:"Bumpers"}[optionindex]), exclude=[12,13,14,15,16,21,22])
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, builder):
        if actionid == RULES_ACTION_CHANNEL_START:
            self.storedValues[0] = builder.bctTypes.get('ratings',{})
            self.storedValues[1] = builder.bctTypes.get('bumpers',{})
            builder.bctTypes['ratings'].update({"max":self.optionValues[0], "auto":self.optionValues[0] == -1, "enabled":bool(self.optionValues[0]), "chance":self.optionValues[1],"sources":{"ids":self.optionValues[2].split('|'),"paths":self.optionValues[4]}})
            builder.bctTypes['bumpers'].update({"max":self.optionValues[0], "auto":self.optionValues[0] == -1, "enabled":bool(self.optionValues[0]), "chance":self.optionValues[1],"sources":{"ids":self.optionValues[3].split('|'),"paths":self.optionValues[5]}})
            self.log("runAction, setting bctTypes = %s"%(builder.bctTypes))

        elif actionid == RULES_ACTION_CHANNEL_STOP:
            builder.bctTypes['ratings'] = self.storedValues[0]
            builder.bctTypes['bumpers'] = self.storedValues[1]
            self.log("runAction, restoring bctTypes = %s"%(builder.bctTypes))
        return parameter
        
                            
class PostRoll(BaseRule):
    def __init__(self):
        self.myId               = 503
        self.name               = "Post-Roll"
        self.description        = "Post-Roll Options"
        self.optionLabels       = [LANGUAGE(30019),LANGUAGE(30134),LANGUAGE(30030),"Adverts Folder",LANGUAGE(30031),"Trailers Folder",LANGUAGE(30126)]
        self.optionValues       = [SETTINGS.getSettingInt('Enable_Postroll'),SETTINGS.getSettingInt('Random_Post_Chance'),SETTINGS.getSetting('Resource_Adverts'),[os.path.join(FILLER_LOC,'Adverts','')],SETTINGS.getSetting('Resource_Trailers'),[os.path.join(FILLER_LOC,'Trailers','')],SETTINGS.getSettingBool('Include_Trailers_KODI')]
        self.optionDescriptions = [LANGUAGE(30020),LANGUAGE(33134),LANGUAGE(33030),"",LANGUAGE(33031),"",LANGUAGE(33126)]
        self.actions            = [RULES_ACTION_CHANNEL_START,RULES_ACTION_CHANNEL_STOP]
        self.selectBoxOptions   = [{LANGUAGE(30022):-1,LANGUAGE(30021):0,LANGUAGE(30026):1,LANGUAGE(30024):2,LANGUAGE(30025):3},list(range(0,101,1)),[]]
        self.storedValues       = [{},{}]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return PostRoll()


    def getTitle(self):
        return self.name


    def onAction(self, optionindex):
        if   optionindex in [0,1]: self.onActionSelect(optionindex)
        elif optionindex in [2,4]: self.onActionResources(optionindex, ftype={2:"adverts",4:"trailers"}[optionindex])
        elif optionindex in [3,5]: self.onActionMultiBrowse(optionindex, header="%s for %s"%(LANGUAGE(32080),{3:"Adverts",5:"Trailers"}[optionindex]), exclude=[12,13,14,15,16,21,22])
        elif optionindex in [6]:   self.onActionToggleBool(optionindex)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, builder):
        if actionid == RULES_ACTION_CHANNEL_START:
            self.storedValues[0] = builder.bctTypes.get('adverts',{})
            self.storedValues[1] = builder.bctTypes.get('trailers',{})
            builder.bctTypes['adverts'].update({"min":self.optionValues[0] , "max":builder.limit, "auto":self.optionValues[0] == -1, "enabled":bool(self.optionValues[0]), "chance":self.optionValues[1],"sources":{"ids":self.optionValues[2].split('|'),"paths":self.optionValues[3]}})
            builder.bctTypes['trailers'].update({"min":self.optionValues[0], "max":builder.limit, "auto":self.optionValues[0] == -1, "enabled":bool(self.optionValues[0]), "chance":self.optionValues[1],"sources":{"ids":self.optionValues[4].split('|'),"paths":self.optionValues[5]},"incKODI":self.optionValues[6]})
            self.log("runAction, setting bctTypes = %s"%(builder.bctTypes))
            
        elif actionid == RULES_ACTION_CHANNEL_STOP:
            builder.bctTypes['adverts'].update(self.storedValues[0])
            builder.bctTypes['trailers'].update(self.storedValues[1])
            self.log("runAction, restoring bctTypes = %s"%(builder.bctTypes))
        return parameter
        

class InterleaveValue(BaseRule):
    def __init__(self):
        self.myId               = 504
        self.name               = LANGUAGE(30192)
        self.description        = LANGUAGE(33215)
        self.optionLabels       = [LANGUAGE(30179),LANGUAGE(30211)]
        self.optionValues       = [SETTINGS.getSettingInt('Interleave_Set'), SETTINGS.getSettingBool('Interleave_Repeat')]
        self.optionDescriptions = [LANGUAGE(33215),LANGUAGE(33211)]
        self.actions            = [RULES_ACTION_CHANNEL_START,RULES_ACTION_CHANNEL_STOP]
        self.selectBoxOptions   = [list(range(0,26,1))]
        self.storedValues       = [[],[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return InterleaveValue()


    def getTitle(self):
        return '%s (%s)'%(self.name,self.optionValues[0])


    def onAction(self, optionindex):
        if optionindex == 0: self.onActionSelect(optionindex)
        else:                self.onActionToggleBool(optionindex)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, builder):
        if actionid == RULES_ACTION_CHANNEL_START:
            self.storedValues[0] = builder.interleaveSet
            self.storedValues[1] = builder.interleaveRepeat
            builder.interleaveSet    = self.optionValues[0]
            builder.interleaveRepeat = self.optionValues[1]
            self.log("runAction, setting interleaveSet = %s, interleaveRepeat = %s"%(builder.interleaveSet, builder.interleaveRepeat))
            
        elif actionid == RULES_ACTION_CHANNEL_STOP:
            builder.interleaveSet    = self.storedValues[0]
            builder.interleaveRepeat = self.storedValues[1]
            self.log("runAction, restoring interleaveSet = %s, interleaveRepeat = %s"%(builder.interleaveSet, builder.interleaveRepeat))
        
        return parameter


class SeasonalRule(BaseRule): #PARSING RULES [800-999]
    """
    SeasonalRule
    """
    def __init__(self):
        self.myId               = 800
        self.name               = "Seasonal"
        self.description        = "Automatically Populate Channels with Seasonal Media."
        self.optionLabels       = ["Holiday"]
        self.optionValues       = [[{"path":"","method":"","enum":"","limits":{},"sort":{},"filter":{},"holiday":{}}]]
        self.optionDescriptions = ["INTERNAL USE ONLY!"]
        self.actions            = [RULES_ACTION_CHANNEL_BUILD_FILEARRAY_PRE]
        self.storedValues       = [[]]
        

    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self): 
        return SeasonalRule()
        
        
    def getTitle(self): 
        return '%s (%s)'%(self.name,self.optionValues[0][0].get('holiday',{}).get('name','None'))
            

    def runAction(self, actionid, citem, parameter, builder):
        if actionid == RULES_ACTION_CHANNEL_BUILD_FILEARRAY_PRE: 
            if self.optionValues[0][0].get('holiday',{}):
                try:
                    if builder.pDialog: builder.pDialog = DIALOG._updateProgress(builder.pDialog, builder.pCount, message=f"{builder.pName}: {LANGUAGE(32209)} {self.name}",header=builder.pHeader)
                    self.log(f"[{citem['id']}] runAction, {self.optionValues[0][0]['holiday']['name']}")
                    for query in self.optionValues[0]:
                        citem['logo'] = (query.get('holiday',{}).get('logo') or LOGO_SEASONAL)
                        if query["key"].startswith(tuple(TV_TYPES)): #filter out extras/specials
                            if not builder.incExtras:
                                query["filter"].setdefault("and",[]).extend([{"field":"season" ,"operator":"greaterthan","value":"0"},
                                                                             {"field":"episode","operator":"greaterthan","value":"0"}])
                            else:
                                query['filter']['and'] = [r for r in params['filter'].get("and", []) if not (('season' in r or 'episode' in r) and r.get("value") == "0")]
                                query['filter']['and'] = Globals._setDictLST(params['filter']['and'])
                        # subfileList, subdirList, limits, errors = builder.buildList(citem, query.get('path',''), 'video', (query.get('limit') or builder.limit), query.get('sort',{}), builder.limits, {'file':query.get('path')}, query) #parse all directories under root. Flattened hierarchies recommended to stream line channel building.
                        self.storedValues[0].append(builder.buildFileList(citem, query.get('path',''), 'video', (query.get('limit') or builder.limit), query.get('sort',{}), builder.limits, query))
                    return [fileList for fileList in self.storedValues[0] if fileList] #fileArray
                except Exception as e: self.log(f"[{citem['id']}] runAction, failed! {e}", xbmc.LOGERROR)
                return []
        return parameter


class HandleMethodOrder(BaseRule):
    def __init__(self):
        self.myId               = 950
        self.name               = LANGUAGE(32232)
        self.description        = LANGUAGE(33232)
        self.optionLabels       = ['Method','Order','Ignore Articles','Ignore Artist Sort Name']
        self.optionValues       = ['random','ascending',True,True]
        self.optionDescriptions = ["","","",""]
        self.actions            = [RULES_ACTION_CHANNEL_START,RULES_ACTION_CHANNEL_STOP]
        self.selectBoxOptions   = [self.getSort(), self.getOrder()]
        self.storedValues       = [[],[],[],[],[]]
        
        
    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return HandleMethodOrder()


    def getTitle(self):
        return '%s (%s)'%(self.name,self.optionValues)


    def getSort(self):
        return JSONRPC().getEnums("List.Sort",type="method")


    def getOrder(self):
        return JSONRPC().getEnums("List.Sort",type="order")


    def onAction(self, optionindex):
        if optionindex in [2,3]: self.onActionToggleBool(optionindex)
        else:                    self.onActionSelect(optionindex, self.optionLabels[optionindex])
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, builder):
        if actionid == RULES_ACTION_CHANNEL_START:
            self.storedValues[0] = builder.sort
            builder.sort.update({"method":self.optionValues[0],"order":self.optionValues[1],"ignorearticle":self.optionValues[2],"useartistsortname":self.optionValues[3]})
            self.log("runAction, setting sort to %s"%(builder.sort))
            
        elif actionid == RULES_ACTION_CHANNEL_STOP:
            builder.sort = self.storedValues[0]
            self.log("runAction, restoring sort to %s"%(builder.sort))
            
        return citem


class HandleLimits(BaseRule):
    def __init__(self):
        self.myId               = 951
        self.name               = LANGUAGE(32263)
        self.description        = LANGUAGE(33015)
        self.optionLabels       = ['Limit','Limits End','Limits Start']
        self.optionValues       = [SETTINGS.getSettingInt('Page_Limit'),-1,0]
        self.optionDescriptions = [f"Force Limit [{SETTINGS.getSettingInt('Page_Limit')}:Default]","Force End [-1:Auto, 0:Unlimited]","Force Start [-1:Unlimited, 0:Auto]"]
        self.actions            = [RULES_ACTION_CHANNEL_START,RULES_ACTION_CHANNEL_STOP]
        self.selectBoxOptions   = [[0,10,25,50,100,250,500,1000]]
        self.storedValues       = [[],{}]
        
        
    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return HandleLimits()


    def getTitle(self):
        return '%s (%s)'%(self.name,self.optionValues)


    def onAction(self, optionindex):
        if optionindex == 0: self.onActionSelect(optionindex)
        else:
            self.onActionDigitBox(optionindex)
            self.validateDigitBox(optionindex,-1,self.selectBoxOptions[0][-1] if self.storedValues[1].get('total',0) == 0 else self.storedValues[1].get('total'),25)
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, builder):
        if actionid == RULES_ACTION_CHANNEL_START:
            self.storedValues[0] = builder.limit
            self.storedValues[1] = builder.limits
            builder.limit = self.optionValues[0]
            builder.limits.update({"end":self.optionValues[1],"start":self.optionValues[2]})
            self.log("runAction, setting limit to %s, limits to %s"%(builder.limit,builder.limits))
            
        elif actionid == RULES_ACTION_CHANNEL_STOP:
            builder.limit = self.storedValues[0]
            builder.limits.update(self.storedValues[1])
            self.log("runAction, restoring limit to %s, limits to %s"%(builder.limit,builder.limits))
            
        return citem


class ForceEpisodeOrder(BaseRule):
    def __init__(self):
        self.myId               = 998
        self.name               = LANGUAGE(30181)
        self.description        = LANGUAGE(33230)
        self.optionLabels       = [LANGUAGE(30181)]
        self.optionValues       = [True]
        self.optionDescriptions = [LANGUAGE(33230)]
        self.actions            = [RULES_ACTION_CHANNEL_BUILD_FILEARRAY_PRE,RULES_ACTION_CHANNEL_BUILD_PATH,RULES_ACTION_CHANNEL_BUILD_FILELIST_PRE]
        self.storedValues       = [[],[],{},[],[],[]]
        self.selectBoxOptions   = []


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return ForceEpisodeOrder()


    def getTitle(self):
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])


    def onAction(self, optionindex):
        return self.optionValues[optionindex]


    def _episodeSort(self, showArray: dict={}):
        try:
            for show, fileItems in list(showArray.items()):
                self.storedValues[4] = []
                for item in fileItems:
                    if (int(item.get("season","0")) + int(item.get("episode","0"))) > 0: #episode
                        self.storedValues[4].append([int(item.get("season","0")), int(item.get("episode","0")), item])
                    else:
                        self.storedValues[3].append(item) #movie
                self.storedValues[4].sort(key=lambda seep: seep[1])
                self.storedValues[4].sort(key=lambda seep: seep[0])
                for seepitem in self.storedValues[4]: self.storedValues[5].append(seepitem[2])
            return self.storedValues[5]
        except Exception as e: self.log("runAction, _episodeSort failed! %s"%(e), xbmc.LOGERROR)
        return []


    def _sortShows(self, fileList: list=[]): #group by type & show; no duplicates. 
        try:
            for fileItem in fileList:
                if fileItem.get('type').startswith(tuple(TV_TYPES)) and fileItem.get('showtitle'):
                    if fileItem not in self.storedValues[2].setdefault(fileItem['showtitle'],[]): 
                        self.storedValues[2].setdefault(fileItem['showtitle'],[]).append(fileItem)
                elif fileItem not in self.storedValues[3]: 
                    self.storedValues[3].append(fileItem) #Movies/Other no duplicates allowed
            return self._episodeSort(self.storedValues[2]), sorted(self.storedValues[3], key=lambda k: k.get('year',0))
        except Exception as e: self.log("runAction, _sortShows failed! %s"%(e), xbmc.LOGERROR)
        return []


    def runAction(self, actionid, citem, parameter, builder):
        if actionid == RULES_ACTION_CHANNEL_BUILD_FILEARRAY_PRE:
            self.storedValues[0] = builder.sort
            
        elif actionid == RULES_ACTION_CHANNEL_BUILD_PATH:
            if   parameter.startswith(tuple(['videodb://%s'%tv for tv in TV_TYPES])): builder.sort.update({"method":"episode"})
            elif parameter:                                                           builder.sort.update({"method":"year"})
            self.log("runAction, setting sort to %s"%(builder.sort))
            
        elif actionid == RULES_ACTION_CHANNEL_BUILD_FILELIST_PRE:
            builder.sort = self.storedValues[0]
            self.log("runAction, restoring sort and forcing episode/year ordering (%s)"%(len(parameter)))
            return interleave(list(self._sortShows(parameter)), builder.interleaveSet, builder.interleaveRepeat)
        return parameter
        
        
class ForceRandom(BaseRule):
    def __init__(self):
        self.myId               = 999
        self.name               = LANGUAGE(30182)
        self.description        = LANGUAGE(33231)
        self.optionLabels       = [LANGUAGE(30182)]
        self.optionValues       = [True]
        self.optionDescriptions = [LANGUAGE(33231)]
        self.actions            = [RULES_ACTION_CHANNEL_BUILD_FILEARRAY_PRE,RULES_ACTION_CHANNEL_BUILD_FILELIST_PRE]
        self.storedValues       = [[]]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self):
        return ForceRandom()


    def getTitle(self):
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])


    def onAction(self, optionindex):
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem,  fileList, builder):
        if actionid == RULES_ACTION_CHANNEL_BUILD_FILEARRAY_PRE:
            self.storedValues[0] = builder.sort
            builder.sort.update({"method":"random"})
            self.log("runAction, setting sort to %s"%(builder.sort))
            
        elif actionid == RULES_ACTION_CHANNEL_BUILD_FILELIST_PRE:
            builder.sort = self.storedValues[0]
            self.log("runAction, restoring sort and forcing random shuffle of %s items"%(len(fileList)))
            return Globals._randomShuffle(fileList)
        return fileList
        

class EvenShowsRule(BaseRule): #BUILD RULES [1000-2999]
    def __init__(self):
        self.myId               = 1000
        self.name               = LANGUAGE(30121)
        self.description        = LANGUAGE(33121)
        self.optionLabels       = [LANGUAGE(30180),LANGUAGE(30181),LANGUAGE(30182)]
        self.optionValues       = [SETTINGS.getSettingInt('Enable_Even'),SETTINGS.getSettingBool('Enable_Even_Force_Episode'),SETTINGS.getSettingBool('Enable_Even_Force_Random')]
        self.optionDescriptions = [LANGUAGE(33121),LANGUAGE(33230),LANGUAGE(30182)]
        self.actions            = [RULES_ACTION_CHANNEL_START,RULES_ACTION_CHANNEL_BUILD_FILELIST_PRE,RULES_ACTION_CHANNEL_STOP]
        self.selectBoxOptions   = [list(range(0,26,1))]
        self.storedValues       = [[],[],[],{},[]]
        

    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self): 
        return EvenShowsRule()
      
      
    def getTitle(self):
        return self.name


    def toggle(self, optionindex):
        if optionindex == 1: 
            if self.optionValues[2]: self.optionValues[2] = not self.optionValues[optionindex]
        elif optionindex == 2: 
            if self.optionValues[1]: self.optionValues[1] = not self.optionValues[optionindex]


    def onAction(self, optionindex):
        if optionindex == 0: self.onActionSelect(optionindex,self.optionLabels[optionindex])
        else:
            self.onActionToggleBool(optionindex)
            self.toggle(optionindex)
        return self.optionValues[optionindex]


    def _chunkEpisodes(self, showArray: dict={}):
        for show, episodes in showArray.items():
            yield show, [episodes[i : i + self.optionValues[0]] for i in range(0, len(episodes), self.optionValues[0])]


    def _sortShows(self, fileItems, episode_order=False, random_order=False):
        try:
            for item in fileItems:
                type  = item.get('type', '')
                title = item.get('showtitle')
                if title and type.startswith(tuple(TV_TYPES)):
                    if episode_order and item not in self.storedValues[3].setdefault(title,[]): 
                        self.storedValues[3].setdefault(title, []).append(item) #no duplicates
                    elif not episode_order:
                        self.storedValues[3].setdefault(title, []).append(item) #duplicates allowed
                else:
                    item_id = item.get('id') or item.get('file')
                    if episode_order and item_id in self.storedValues[4]: continue
                    self.storedValues[4].append(item)
            if random_order:
                self.storedValues[3] = Globals._randomShuffle(self.storedValues[3])
                self.storedValues[4] = Globals._randomShuffle(self.storedValues[4])
            return dict(self._chunkEpisodes(self.storedValues[3])), self.storedValues[4]
        except Exception as e: self.log("runAction, _sortShows failed! %s"%(e), xbmc.LOGERROR)
        return {}, []


    def _mergeShows(self, shows={}, movies=[], inherited=None):
        try:
            movie_queue = deque(movies or [])
            movie_cnt   = (len(movie_queue) // len(shows)) if len(shows) > 0 else 0
            show_keys   = list(shows.keys())
            
            all_chunks  = []
            for show, chunks in shows.items():
                for chunk in chunks:
                    all_chunks.append(chunk)
                    
            total_slots = len(all_chunks)
            if total_slots == 0: return list(movie_queue)
            movies_per_slot = len(movie_queue) / total_slots
            accumulator = 0.0

            nfileList   = []
            while not inherited.monitor.abortRequested() and shows:
                for show in show_keys[:]:  # Iterate over a copy of keys
                    if show not in shows: continue
                    chunks = shows[show]
                    if chunks:
                        accumulator += movies_per_slot
                        try: nfileList.extend(chunks.pop(0) if isinstance(chunks, list) else next(chunks))# If it's a list, pop(0) is still slow; if it's a generator, use next()
                        except (IndexError, StopIteration):
                            del shows[show]
                            show_keys.remove(show)
                            
                        while not inherited.monitor.abortRequested() and accumulator >= 1.0 and movie_queue:
                            nfileList.append(movie_queue.popleft())
                            accumulator -= 1.0
                    else:
                        del shows[show]
                        show_keys.remove(show)
            nfileList.extend(movie_queue)
            return nfileList
        except Exception as e: self.log("runAction, _mergeShows failed! %s"%(e), xbmc.LOGERROR)
        return []


    def runAction(self, actionid, citem, parameter, builder):
        if bool(self.optionValues[0]):
            if actionid == RULES_ACTION_CHANNEL_START:
                self.storedValues[0] = builder.enableEven
                self.storedValues[1] = builder.evenEpisode
                self.storedValues[2] = builder.evenShuffle
                builder.enableEven   = self.optionValues[0]
                builder.evenEpisode  = self.optionValues[1]
                builder.evenShuffle  = self.optionValues[2]
                self.log("runAction, setting enableEven = %s, evenEpisode = %s, evenShuffle = %s"%(builder.enableEven,builder.evenEpisode,builder.evenShuffle))
                
            elif actionid == RULES_ACTION_CHANNEL_BUILD_FILELIST_PRE:
                if len(parameter) > 0:
                    builder.pDialog = DIALOG._updateProgress(builder.pDialog, builder.pCount, message='%s: %s'%(LANGUAGE(32209),self.name), header='%s, %s'%(ADDON_NAME,builder.pMSG))
                    episode_order = False if self.optionValues[2] else self.optionValues[1]
                    random_order  = False if self.optionValues[1] else self.optionValues[2]
                    if episode_order: 
                                       fileItems = list(sorted(parameter, key=lambda k: k.get('year',0)))    #force year ordering
                                       fileItems = list(sorted(fileItems, key=lambda k: k.get('episode',0))) #force episode ordering
                                       fileItems = list(sorted(fileItems, key=lambda k: k.get('season',0)))  #force season ordering
                    elif random_order: fileItems = Globals._randomShuffle(parameter)
                    else:              fileItems = parameter
                    sortShows, sortMovies = self._sortShows(fileItems, episode_order, random_order)
                    self.log('runAction, episode_order %s, random_order %s, tvshows = %s, movies = %s'%(episode_order, random_order, len(list(sortShows.keys())), len(sortMovies)))
                    return self._mergeShows(sortShows,sortMovies,builder)
                    
            elif actionid == RULES_ACTION_CHANNEL_STOP:
                builder.enableEven  = self.storedValues[0]
                builder.evenEpisode = self.storedValues[1]
                builder.evenShuffle = self.storedValues[2]
                self.log("runAction, restoring enableEven = %s, evenEpisode = %s, evenShuffle = %s"%(builder.enableEven,builder.evenEpisode,builder.evenShuffle))
            
        return parameter
        
        
class PadScheduling(BaseRule):
    def __init__(self):
        self.myId               = 2999
        self.name               = "Pad Scheduling"
        self.description        = "Pad EPG with duplicates by cycling the fileList until the configured target duration is reached. Useful for channels whose source pool is smaller than MAX_GUIDEDAYS."
        self.optionLabels       = ["Pad Scheduling", "Target Duration"]
        # madteevee: option 1 added in v.19. Default keeps prior behaviour
        # (MIN_EPG_DURATION = 3h) so existing channels with this rule saved
        # via the old single-bool schema upgrade transparently — loadRules
        # fills the second slot from this default template.
        self.optionValues       = [True, MIN_EPG_DURATION]
        self.optionDescriptions = ["Enable cycling-pad of small fileLists",
                                   "How far forward to pad the EPG (seconds)"]
        self.actions            = [RULES_ACTION_CHANNEL_START, RULES_ACTION_CHANNEL_BUILD_TIME_POST,RULES_ACTION_CHANNEL_STOP]
        self.selectBoxOptions   = [
            [],
            {f"Min EPG ({MIN_EPG_DURATION // 3600}h)" : MIN_EPG_DURATION,
             "1 Day (24h)"                            : 86400,
             f"Max Days ({MAX_GUIDEDAYS}d)"           : MAX_GUIDEDAYS * 86400}
        ]
        self.storedValues       = [None, None]   # [prev padScheduling, prev padTarget]


    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)


    def copy(self):
        return PadScheduling()


    def getTitle(self):
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])


    def onAction(self, optionindex):
        if optionindex == 0:
            self.onActionToggleBool(optionindex)
        elif optionindex == 1:
            self.onActionSelect(optionindex, self.optionLabels[optionindex])
        return self.optionValues[optionindex]


    def runAction(self, actionid, citem, parameter, inherited):
        self.log('[%s] runAction, actionid = %s,'%(citem.get('id'),actionid))
        if actionid == RULES_ACTION_CHANNEL_START:
            self.storedValues[0]    = inherited.padScheduling
            self.storedValues[1]    = getattr(inherited, 'padTarget', MIN_EPG_DURATION)
            inherited.padScheduling = self.optionValues[0]
            inherited.padTarget     = self.optionValues[1]
            self.log("runAction, setting padScheduling=%s, padTarget=%s"%(inherited.padScheduling, inherited.padTarget))

        elif actionid == RULES_ACTION_CHANNEL_BUILD_TIME_POST:
            # madteevee bug fix (v.19): was 'if self.padScheduling' which AttributeError'd
            # on the rule instance and got swallowed by the rules dispatcher — the pad
            # block has effectively never run since the regression. The flag lives on
            # `inherited` (the Builder), set at RULES_ACTION_CHANNEL_START above and
            # defaulted at builder.py:89.
            if inherited.padScheduling and len(parameter) > 0:
                target = inherited.padTarget
                iters  = cycle(parameter)
                totDur = 0
                start  = parameter[-1]['stop']
                idx    = len(parameter)
                now    = clock_helpers.now() # imports.63: the real clock (getUTCstamp was 1-2 h slow)
                while not inherited.monitor.abortRequested() and start <= (now + target):
                    if start >= (now + target): break
                    else:
                        idx += 1
                        item = next(iters).copy()
                        item["idx"]   = idx
                        item['start'] = start
                        item['stop']  = start + item['duration']
                        start = item['stop']
                        totDur += item['duration']
                        parameter.append(item)
                        inherited.pDialog = DIALOG._updateProgress(inherited.pDialog, inherited.pCount, message=f"{inherited.pName}: {LANGUAGE(33085)} {totDur}/{target}",header=inherited.pHeader)
                        self.log("[%s] addScheduling, ADD fileList = %s, totDur = %s/%s, stop = %s"%(citem['id'],len(parameter),totDur,target,parameter[-1].get('stop')))

        elif actionid == RULES_ACTION_CHANNEL_STOP:
            inherited.padScheduling = self.storedValues[0]
            inherited.padTarget     = self.storedValues[1]
            self.log("runAction, restoring padScheduling=%s, padTarget=%s"%(inherited.padScheduling, inherited.padTarget))

        return parameter
        
        
class PauseRule(BaseRule): #POST-BUILD RULES [3000-~]
    def __init__(self):
        self.myId               = 3000
        self.name               = LANGUAGE(32230)
        self.description        = LANGUAGE(33228)
        self.optionLabels       = [LANGUAGE(32231),"FileList"]
        self.optionValues       = [True,""]
        self.optionDescriptions = [LANGUAGE(32231),"Self Generated, Please leave blank!"]
        self.actions            = [RULES_ACTION_PLAYBACK_RESUME, RULES_ACTION_PLAYER_START, RULES_ACTION_PLAYER_CHANGE, RULES_ACTION_PLAYER_STOP, RULES_ACTION_CHANNEL_START, RULES_ACTION_CHANNEL_STOP, RULES_ACTION_CHANNEL_BUILD_FILEARRAY_PRE, RULES_ACTION_CHANNEL_BUILD_FILEARRAY_POST, RULES_ACTION_CHANNEL_BUILD_FILELIST_POST, RULES_ACTION_CHANNEL_BUILD_FILELIST_RETURN, RULES_ACTION_CHANNEL_BUILD_TIME_PRE, RULES_ACTION_CHANNEL_CITEM, RULES_ACTION_CHANNEL_TEMP_CITEM]
        self.storedValues       = [[],[],False]
        

    def log(self, msg, level=xbmc.LOGDEBUG):
        log('%s: %s'%(self.__class__.__name__,msg),level)
                  

    def copy(self): 
        return PauseRule()
        
        
    def getTitle(self): 
        return '%s (%s)'%(self.name,{True:LANGUAGE(30184),False:LANGUAGE(30021)}[self.optionValues[0]])
            
            
    def onAction(self, optionindex):
        return self.optionValues[optionindex]
        
        
    def _getURL(self, id):
        return 'http://%s/filelist/%s.json'%(PROPERTIES.getRemoteHost(),FileAccess._getMD5('%s.%s'%(PROPERTIES.getFriendlyName(),id)))
        
        
    def _getPath(self, id):
        return os.path.join(RESUME_LOC,'%s.json'%(FileAccess._getMD5('%s.%s'%(PROPERTIES.getFriendlyName(),id))))
        
        
    def _getTotDuration(self, id, filelist=[]):
        return JSONRPC().getTotDuration(filelist)
            

    def _buildSchedule(self, citem, filelist, builder):     
        self.log('[%s] _buildSchedule, filelist = %s'%(citem.get('id'),len(filelist)))
        updated = self._getResume(citem.get('id')).get('updated',{})
        try:    viewed = '%s: %s (%s)'%(LANGUAGE(32250),epochTime(updated.get('time')).strftime(BACKUP_TIME_FORMAT),updated.get('instance'))
        except Exception: viewed = LANGUAGE(32251)
        return builder.buildCells(citem, duration=self._getTotDuration(citem.get('id'), filelist), entries=1, 
                                  info={"title":'%s (%s)'%(citem.get('name'),LANGUAGE(32145)), 
                                        "episodetitle":viewed,
                                        "plot":'%s: %s\nSize: %s\nRuntime: ~%s hrs.'%(LANGUAGE(32249),epochTime(time.time()).strftime(BACKUP_TIME_FORMAT),len(filelist),round(self._getTotDuration(citem.get('id'), filelist)//60//60)),
                                        "art":{"thumb":citem.get('logo',LOGO_COLOR),"fanart":FANART,"logo":citem.get('logo',LOGO),"icon":citem.get('logo',LOGO)}})

            
    def _set(self, id, filelist=[], resume={"idx":0,"position":0.0,"total":0.0,"file":"","updated":{"instance":"","time":-1}}):
        self.log("[%s] runAction, _set: filelist = %s, resume = %s, url = %s"%(id,len(filelist),resume,self.optionValues[1]))
        friendly = PROPERTIES.getFriendlyName()
        if resume.get('updated',{}).get('instance') == friendly: #local
            return FileAccess.setJSON(self._getPath(id),{'resume':resume,'filelist':filelist})
        elif self.optionValues[1]:#remote
            return Globals.requestURL(self.optionValues[1],payload={'uuid':SETTINGS.getMYUUID(),'name':friendly,'payload':{'resume':resume,'filelist':filelist}},
                              cache={"cache":SETTINGS.cacheDB, "checksum":ADDON_VERSION, "life": datetime.timedelta(minutes=15)})
            
        
    def _get(self, id):
        self.log("[%s] runAction, _get: url = %s"%(id,self.optionValues[1]))
        if self.optionValues[1]: return Globals.requestURL(self.optionValues[1], cache={"cache":SETTINGS.cacheDB, "checksum":ADDON_VERSION, "life": datetime.timedelta(minutes=15)})
        else:                    return FileAccess.getJSON(self._getPath(id))


    def _getResume(self, id):
        return (self._get(id).get('resume') or {"idx":0,"position":0.0,"total":0.0,"file":"","updated":{"instance":"","time":-1}})
        
        
    def _getFilelist(self, id):
        return (self._get(id).get('filelist') or [])
        

    def _getPlaylist(self, id):
        resume   = self._getResume(id)
        filelist = self._getFilelist(id)
        if len(filelist) > 0:
            for idx, item in enumerate(filelist):
                if item.get('file') == resume.get('file',-1):
                    resume.update({'idx':0})
                    item['resume'] = resume
                    filelist = filelist[idx:]
                    if self._set(id, filelist, resume): break
        self.log('[%s] runAction, _getPlaylist: filelist = %s, resume = %s'%(id,len(filelist),resume))
        return filelist
        
        
    def runAction(self, actionid, citem, parameter, inherited):
        self.log('[%s] runAction, actionid = %s,'%(citem.get('id'),actionid))
        if actionid == RULES_ACTION_CHANNEL_START:
            self.storedValues[0]    = inherited.padScheduling
            self.storedValues[1]    = self._getFilelist(citem.get('id'))
            inherited.padScheduling = False #disable guide padding with duplicates to fill quota.
            self.log("[%s] runAction, setting padScheduling = %s"%(citem.get('id'),inherited.padScheduling))
            
        elif actionid == RULES_ACTION_CHANNEL_CITEM:
            try:
                parameter["rules"][3000]["values"].update({1:self._getURL(parameter.get('id'))})
                self.log("runAction, updated rule values = %s"%( parameter["rules"][3000]["values"]), xbmc.LOGERROR)
            except Exception as e:
                self.log("runAction, updated rule values failed! %s"%(e), xbmc.LOGERROR)

        # elif actionid == RULES_ACTION_CHANNEL_TEMP_CITEM: 
            # parameter['resume'] = True
            
        elif actionid == RULES_ACTION_CHANNEL_BUILD_FILEARRAY_PRE: #load cached filelist if not outdated, else new buildFileList
            if self._getTotDuration(citem.get('id'), self.storedValues[1]) >= (MIN_GUIDEDAYS * 86400): 
                self.log("[%s] runAction, returning valid cached filelist = %s"%(citem.get('id'),len(self.storedValues[1])))
                return [self.storedValues[1]]
            
        elif actionid == RULES_ACTION_CHANNEL_BUILD_FILEARRAY_POST: #check if cached filelist is the same as existing filelist.
            if [self.storedValues[1]] != parameter: self.storedValues[2] = True #finish building new filelist extend filelist.
            elif len(self.storedValues[1]) > 0: return True #use cached filelist

        elif actionid == RULES_ACTION_CHANNEL_BUILD_FILELIST_POST:#update cached filelist
            if self.storedValues[2] and len(parameter) > 0:
                self.log("[%s] runAction, updating fileList (%s) extending by (%s)"%(citem.get('id'),len(self.storedValues[1]),len(parameter)))
                self.storedValues[1].extend(parameter)
                self._set(citem.get('id'), self.storedValues[1], self._getResume(citem.get('id')))
                
        elif actionid == RULES_ACTION_CHANNEL_BUILD_FILELIST_RETURN:
            if parameter: 
                self.log("[%s] runAction, returning fileList (%s)"%(citem.get('id'),len(self.storedValues[1])))
                return self.storedValues[1]
            
        elif actionid == RULES_ACTION_CHANNEL_BUILD_TIME_PRE:
            if len(parameter) > 0: 
                if inherited.xmltv.clrProgrammes(citem): return self._buildSchedule(citem, parameter, inherited)

        elif actionid == RULES_ACTION_CHANNEL_STOP:
            inherited.padScheduling = self.storedValues[0]
            self.storedValues[1] = []
            self.log("[%s] runAction, restoring padScheduling = %s"%(citem.get('id'),inherited.padScheduling))
            
        elif actionid == RULES_ACTION_PLAYBACK_RESUME:
            return self._getPlaylist(citem.get('id'))
                                                        
        elif actionid == RULES_ACTION_PLAYER_START:
            self.storedValues[1] = self._getFilelist(citem.get('id'))
            
        elif actionid in [RULES_ACTION_PLAYER_CHANGE, RULES_ACTION_PLAYER_STOP]:
            if parameter.get('resume').get('updated'):
                self.log("[%s] runAction, updating resume = %s"%(citem.get('id'),parameter.get('resume')))
                self._set(citem.get('id'),self.storedValues[1],parameter.get('resume'))
                
        return parameter
       