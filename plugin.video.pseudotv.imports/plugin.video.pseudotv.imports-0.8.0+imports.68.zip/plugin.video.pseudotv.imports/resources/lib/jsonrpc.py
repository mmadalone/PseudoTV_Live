#   Copyright (C) 2025 Lunatixz
#
#
# This file is part of PseudoTV Live.
#
# PseudoTV Live is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PseudoTV Live is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.
# -*- coding: utf-8 -*-

from globals     import *
from videoparser import VideoParser

class Service(object):
    player  = PLAYER()
    monitor = MONITOR()
    def _shutdown(self, wait=1.0) -> bool:
        return (self.monitor.waitForAbort(wait) | PROPERTIES.isPendingShutdown())
    def _interrupt(self) -> bool:
        return (PROPERTIES.isPendingShutdown() | PROPERTIES.isPendingRestart() | PROPERTIES.isPendingInterrupt())
    def _suspend(self, wait=1.0) -> bool:
        return PROPERTIES.isPendingSuspend()
    def _sleep(self, wait=1.0):
        while not self.monitor.abortRequested() and wait > 0:
            if (self.monitor.waitForAbort(CPU_CYCLE) | self._interrupt()): return True
            else: wait -= CPU_CYCLE
        return False
    
    
class JSONRPC(object):
    cache       = SETTINGS.cacheDB
    videoParser = VideoParser()
    
    def __init__(self, service=None):
        if service is None: service = Service()
        self.service = service


    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s' % (self.__class__.__name__, msg), level)


    def sendJSON(self, param, delay=True):
        command = param
        command["jsonrpc"] = "2.0"
        command["id"] = ADDON_ID
        response = FileAccess.loadJSON(BUILTIN.executeJSONRPC(FileAccess.dumpJSON(command)))
        # madteevee (imports fork, imports.60): delay=False skips the RPC_Delay pause
        # after the reply, for a read whose caller must act on it at once.
        if delay: self.service.monitor.waitForAbort(float(SETTINGS.getSettingInt('RPC_Delay')))
        self.log('sendJSON, response received')
        if response and response.get('error'):
            self.log('sendJSON, failed! error = %s' % FileAccess.dumpJSON(response.get('error')), xbmc.LOGWARNING)
            response.setdefault('result',{})['error'] = response.pop('error')
        return response


    def sendRPC(self, param):
        #slower rpc, with proper timeout (killit) control via socket, internal rpc request requires thread killit which is hit or miss.
        command = param
        command["jsonrpc"] = "2.0"
        command["id"] = ADDON_ID
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(float(SETTINGS.getSettingInt('RPC_Wait'))) # This is the critical line
            sock.connect((SETTINGS.getIP(), 9090))
            sock.sendall(command.encode('utf-8'))
            response = sock.recv(4096)
            self.service.monitor.waitForAbort(float(SETTINGS.getSettingInt('RPC_Delay')))
            return FileAccess.loadJSON(response.decode('utf-8'))
        except socket.timeout:
            self.log("sendRPC, JSONRPC Timed out!", xbmc.LOGERROR)
            return None
        finally:
            sock.close()


    def queueJSON(self, param):
        # imports.49: serialize dict → JSON string before .add() — `jsonQue` is a `set`,
        # and dict params (e.g. {'method':'VideoLibrary.SetEpisodeDetails','params':{...}})
        # are unhashable, raising TypeError pre-imports.49. Mirrors the logoQue pattern at
        # resources.py:120 which has done exactly this serialization for years. Consumer
        # at tasks.py:1135 deserializes via FileAccess.loadJSON on pop. Set dedup is
        # preserved (identical-shape param → identical JSON string → one entry).
        # madteevee (imports fork, imports.60): queDuration, the caller that exposed this
        # (and that queued params without a "method", which Kodi rejected as "JSONRPC:
        # Failed to parse"), was removed. The only producer left is
        # setSettingValue(queue=True). Every queued param must be a full request
        # ({"method":...,"params":...}); test_imports60_rpc_payloads.py checks the call sites.
        if hasattr(self.service,'jsonQue'): self.service.jsonQue.add(FileAccess.dumpJSON(param))
        
        
    def cacheJSON(self, param, life=datetime.timedelta(minutes=5), checksum=ADDON_VERSION):
        cacheName = 'cacheJSON.%s'%(FileAccess._getMD5(FileAccess.dumpJSON(param)))
        cacheResponse = self.cache.get(cacheName, checksum=checksum)
        if not cacheResponse:
            cacheResponse = self.sendJSON(param)
            if cacheResponse.get('result',{}): self.cache.set(cacheName, cacheResponse, checksum=checksum, expiration=life)
        return cacheResponse


    def walkFileDirectory(self, path, media='video', depth=SETTINGS.getSettingInt('Recursive_Depth'), chkDuration=False, retItem=False, checksum=ADDON_VERSION, expiration=datetime.timedelta(minutes=15)):
        def __chkitem(path, f):
            if chkDuration:
                item['duration'] = self.getDuration(item.get('file'),item, accurate=bool(SETTINGS.getSettingInt('Duration_Type')))
            
        walk = {}
        self.log('walkFileDirectory, walking %s, depth = %s'%(path,depth))
        items, limits, errors = self.getDirectory({"directory":path,"media":media},True,checksum,expiration)
        for idx, item in enumerate(items):
            if item.get('filetype') == 'file':
                __chkitem(item)
                if item['duration'] == 0: continue
                walk.setdefault(path,[]).append(item if retItem else item.get('file'))
            elif item.get('filetype') == 'directory' and depth > 0:
                depth -= 1
                walk.update(self.walkFileDirectory(item.get('file'), media, depth, chkDuration, retItem, checksum, expiration))
        return walk
                

    def walkListDirectory(self, path, exts=[], depth=SETTINGS.getSettingInt('Recursive_Depth'), chkDuration=False, appendPath=False, checksum=ADDON_VERSION, expiration=datetime.timedelta(minutes=15)):
        def __chkfile(path, f):
            if exts and f.lower().endswith(tuple(exts)): return
            if chkDuration:
                if self.getDuration(os.path.join(path,f), accurate=bool(SETTINGS.getSettingInt('Duration_Type'))) == 0: return
            return {True:os.path.join(path,f).replace('\\','/'),False:f}[appendPath]
            
        walk = {}
        path = path.replace('\\','/')
        subs, files = self.getListDirectory(path,checksum,expiration)
        self.log(f'walkListDirectory, walking {path}, found = ({len(subs)},{len(files)}), appended = {appendPath}, depth = {depth}, exts = {exts}')
        walk.setdefault(path,[]).extend([_f for _f in [__chkfile(path, file) for file in files] if _f])
        for sub in subs:
            if depth == 0: break
            depth -= 1
            walk.update(self.walkListDirectory(os.path.join(path,sub), exts, depth, chkDuration, appendPath, checksum, expiration))
        return walk
                
                
    def getListDirectory(self, path, checksum=ADDON_VERSION, expiration=datetime.timedelta(minutes=15)):
        cacheName = 'getListDirectory.%s'%(FileAccess._getMD5(path))
        results   = self.cache.get(cacheName, checksum)
        if results is None:
            try:
                results  = self.cache.set(cacheName, FileAccess.listdir(path), checksum, expiration)
                self.log('getListDirectory path = %s, checksum = %s'%(path, checksum))
            except Exception as e:
                self.log("getListDirectory, failed! %s\npath = %s"%(e,path), xbmc.LOGERROR)
                results = [],[]
        return results


    def getIntrospect(self, id):
        param = {"method":"JSONRPC.Introspect","params":{"filter":{"id":id,"type":"method"}}}
        return self.cacheJSON(param,datetime.timedelta(days=28),BUILTIN.getInfoLabel('BuildVersion','System')).get('result',{})


    def getEnums(self, id, type='', key='enums'):
        self.log('getEnums id = %s, type = %s, key = %s' % (id, type, key))
        param = {"method":"JSONRPC.Introspect","params":{"getmetadata":True,"filterbytransport":True,"filter":{"getreferences":False,"id":id,"type":"type"}}}
        json_response = self.cacheJSON(param,datetime.timedelta(days=28),BUILTIN.getInfoLabel('BuildVersion','System')).get('result',{}).get('types',{}).get(id,{})
        return (json_response.get('properties',{}).get(type,{}).get(key) or json_response.get(type,{}).get(key) or json_response.get(key,[]))


    def notifyAll(self, message, data, sender=ADDON_ID):
        param = {"method":"JSONRPC.NotifyAll","params":{"sender":sender,"message":message,"data":[data]}}
        return self.sendJSON(param).get('result') == 'OK'


    def playerOpen(self, params={}):
        param = {"method":"Player.Open","params":params}
        return self.sendJSON(param).get('result') == 'OK'


    # madteevee (imports fork, imports.62): narrow reads for the restart action
    # (restart_helpers). They never ask for 'file' or all fields (Movistar+ stream
    # links carry tokens, and debug logging writes whole replies), and they skip
    # the RPC_Delay pause (delay=False) because their caller acts on the answer.
    def getPlayerItemRef(self):
        param = {"method":"Player.GetItem","params":{"playerid":1,"properties":[]}}
        return ((self.sendJSON(param, delay=False) or {}).get('result') or {}).get('item') or {}


    def getPVRChannelInfo(self, channelid, properties=('hasarchive',)):
        param = {"method":"PVR.GetChannelDetails","params":{"channelid":channelid,"properties":list(properties)}}
        return ((self.sendJSON(param, delay=False) or {}).get('result') or {}).get('channeldetails') or {}


    def getPVRChannelsNow(self):
        param = {"method":"PVR.GetChannels","params":{"channelgroupid":"alltv","properties":["broadcastnow","hasarchive"]}}
        return ((self.sendJSON(param, delay=False) or {}).get('result') or {}).get('channels') or []


    def isBroadcastPlayable(self, broadcastid):
        param = {"method":"PVR.GetBroadcastIsPlayable","params":{"broadcastid":broadcastid}}
        return (self.sendJSON(param, delay=False) or {}).get('result') is True


    def getSetting(self, category, section, cache=False):
        param = {"method":"Settings.GetSettings","params":{"filter":{"category":category,"section":section}}}
        if cache: return self.cacheJSON(param).get('result',{}).get('settings',[])
        else:     return self.sendJSON(param).get('result',{}).get('settings',[])


    def getSettingValue(self, key, default='', cache=False):
        param = {"method":"Settings.GetSettingValue","params":{"setting":key}}
        if cache: return (self.cacheJSON(param).get('result',{}).get('value') or default)
        else:     return (self.sendJSON(param).get('result',{}).get('value')  or default)


    def setSettingValue(self, key, value, queue=False):
        param = {"method":"Settings.SetSettingValue","params":{"setting":key,"value":value}}
        if queue: self.queueJSON(param)
        else:     self.sendJSON(param)


    def getSources(self, media='video', cache=True):
        param = {"method":"Files.GetSources","params":{"media":media}}
        if cache: return self.cacheJSON(param).get('result',{}).get('sources', [])
        else:     return self.sendJSON(param).get('result',{}).get('sources', [])


    def getAddonDetails(self, addonid=ADDON_ID, cache=True):
        param = {"method":"Addons.GetAddonDetails","params":{"addonid":addonid,"properties":self.getEnums("Addon.Fields", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('addon', {})
        else:     return self.sendJSON(param).get('result',{}).get('addon', {})


    def getAddons(self, param={"content":"video","enabled":True,"installed":True}, cache=True):
        param["properties"] = self.getEnums("Addon.Fields", type='items')
        param = {"method":"Addons.GetAddons","params":param}
        if cache: return self.cacheJSON(param).get('result',{}).get('addons', [])
        else:     return self.sendJSON(param).get('result',{}).get('addons', [])


    def getSongs(self, cache=True):
        param = {"method":"AudioLibrary.GetSongs","params":{"properties":self.getEnums("Audio.Fields.Song", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('songs', [])
        else:     return self.sendJSON(param).get('result',{}).get('songs', [])


    def getArtists(self, cache=True):
        param = {"method":"AudioLibrary.GetArtists","params":{"properties":self.getEnums("Audio.Fields.Artist", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('artists', [])
        else:     return self.sendJSON(param).get('result',{}).get('artists', [])


    def getAlbums(self, cache=True):
        param = {"method":"AudioLibrary.GetAlbums","params":{"properties":self.getEnums("Audio.Fields.Album", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('albums', [])
        else:     return self.sendJSON(param).get('result',{}).get('albums', [])

     
    def getEpisode(self, tvshowid, season, episode, cache=True):
        param = {"method":"VideoLibrary.GetEpisodes","params":{"tvshowid":tvshowid,"season":season,"properties":self.getEnums("Video.Fields.Episode", type='items'),"filter":{"field":"episode","operator":"is","value":str(episode)}}}
        if cache: return self.cacheJSON(param).get('result',{}).get('episodes', [])
        else:     return self.sendJSON(param).get('result',{}).get('episodes', [])
  
  
    def getEpisodes(self, cache=True):
        param = {"method":"VideoLibrary.GetEpisodes","params":{"properties":self.getEnums("Video.Fields.Episode", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('episodes', [])
        else:     return self.sendJSON(param).get('result',{}).get('episodes', [])


    def getTVshows(self, cache=True):
        param = {"method":"VideoLibrary.GetTVShows","params":{"properties":self.getEnums("Video.Fields.TVShow", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('tvshows', [])
        else:     return self.sendJSON(param).get('result',{}).get('tvshows', [])


    def getMovie(self, uniqueid, title, year, cache=True):
        param = {"method":"VideoLibrary.GetMovies","params":{"properties":self.getEnums("Video.Fields.Movie", type='items'),"filter":{"and":[{"field":"title","operator":"is","value":title},{"field":"year","operator":"is","value":str(year)}]}}}
        if cache: return self.cacheJSON(param).get('result',{}).get('movies', [])
        else:     return self.sendJSON(param).get('result',{}).get('movies', [])


    def getMovies(self, cache=True):
        param = {"method":"VideoLibrary.GetMovies","params":{"properties":self.getEnums("Video.Fields.Movie", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('movies', [])
        else:     return self.sendJSON(param).get('result',{}).get('movies', [])


    def getVideoGenres(self, type="movie", cache=True): #type = "movie"/"tvshow"
        param = {"method":"VideoLibrary.GetGenres","params":{"type":type,"properties":self.getEnums("Library.Fields.Genre", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('genres', [])
        else:     return self.sendJSON(param).get('result',{}).get('genres', [])


    def getMusicGenres(self, cache=True):
        param = {"method":"AudioLibrary.GetGenres","params":{"properties":self.getEnums("Library.Fields.Genre", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('genres', [])
        else:     return self.sendJSON(param).get('result',{}).get('genres', [])


    def getDirectory(self, param={}, cache=True, checksum=ADDON_VERSION, expiration=datetime.timedelta(minutes=15)):
        param["properties"] = self.getEnums("List.Fields.Files", type='items') #todo change enums from files to media specific? 
        param = {"method":"Files.GetDirectory","params":param}
        if cache: results = self.cacheJSON(param, expiration, checksum).get('result',{})
        else:     results = self.sendJSON(param).get('result',{})
        if 'filedetails' in results: return results.get('filedetails',[]), results.get('limits',{}), results.get('error',{})
        else:                        return results.get('files',[]), results.get('limits',{}), results.get('error',{})


    def getLibrary(self, method, param={}, key=None, cache=True):
        param = {"method":method,"params":param}
        if cache: results = self.cacheJSON(param).get('result',{})
        else:     results = self.sendJSON(param).get('result',{})
        return results.get((key or list(results.keys())[0]),[]), results.get('limits',{}), results.get('error',{})
        

    def getStreamDetails(self, path, media='video'):
        if isStack(path): path = splitStacks(path)[0]
        param = {"method":"Files.GetFileDetails","params":{"file":path,"media":media,"properties":["streamdetails"]}}
        # Cache TTL is user-configurable via 'Streamdetails_Cache_Days' (default 30, range 1-90).
        # Master-fork tunable: replaces the hardcoded MAX_GUIDEDAYS (3 days) so HDD-backed
        # libraries don't re-spin the disk for unchanged files every few days.
        ttl_days = max(1, SETTINGS.getSettingInt('Streamdetails_Cache_Days') or 30)
        return self.cacheJSON(param, life=datetime.timedelta(days=ttl_days), checksum=FileAccess._getMD5(path)).get('result',{}).get('filedetails',{}).get('streamdetails',{})


    def getFileDetails(self, file, media='video', properties=["duration","runtime"], cache=True, delay=True):
        # madteevee (imports fork, imports.60): cache=False reads Kodi directly (the
        # Rollback_Watched snapshot/restore must see the current values, not a 5-minute
        # cached copy); with it, delay=False skips sendJSON's RPC_Delay pause. The
        # defaults keep VFSParser's cached lookup unchanged.
        param = {"method":"Files.GetFileDetails","params":{"file":file,"media":media,"properties":properties}}
        if cache: return self.cacheJSON(param)
        else:     return self.sendJSON(param, delay)


    def getViewMode(self):
        default = {"nonlinearstretch":False,"pixelratio":1,"verticalshift":0,"viewmode":"custom","zoom": 1.0}
        return self.cacheJSON({"method":"Player.GetViewMode","params":{}},datetime.timedelta(seconds=15)).get('result',default)
        

    def setViewMode(self, params={}):
        return self.sendJSON({"method":"Player.SetViewMode","params":params})


    def getPlayerItem(self, playlist=False):
        self.log('getPlayerItem, playlist = %s' % (playlist))
        if playlist: param = {"method":"Playlist.GetItems","params":{"playlistid":self.getActivePlaylist(),"properties":self.getEnums("List.Fields.All", type='items')}}
        else:        param = {"method":"Player.GetItem"   ,"params":{"playerid":self.getActivePlayer()    ,"properties":self.getEnums("List.Fields.All", type='items')}}
        result = self.sendJSON(param).get('result',{})
        return (result.get('item', {}) or result.get('items', []))


    def getPVRClients(self):
        param = {"method":"PVR.GetClients","params":{}}
        return self.sendJSON(param).get('result',{}).get('clients',[])


    def getPVRClient(self, id=PVR_CLIENT_ID):
        results = self.getPVRClients()
        return next((result for result in results if result.get('addonid','').lower() == id.lower()),None)


    def getPVRChannelGroups(self, match=ADDON_NAME, radio=False):
        param   = {"method":"PVR.GetChannelGroups","params":{"channeltype":{True:'radio',False:'tv'}[radio]}}
        results = self.sendJSON(param).get('result',{}).get('channelgroups', [])
        if match is None: return results
        return next((result for result in results if result.get('label').lower() == match.lower()), None)

        
    def getPVRChannelGroupDetails(self, id):
        param = {"method":"PVR.GetChannelGroupDetails","params":{"channelgroupid":1,"channels":{"limits":{"end":0,"start":0},"properties":self.getEnums("PVR.Fields.Channel", type='items')}}}
        return self.sendJSON(param).get('result',{}).get('channelgroupdetails', {}).get('channels',[])
        

    def PVRScan(self, id):
        param = {"method":"PVR.Scan","params":{"clientid":id}}
        return self.sendJSON(param).get('result',{})
        
        
    def getPVRChannels(self, radio=False):
        param = {"method":"PVR.GetChannels","params":{"channelgroupid":{True:'allradio',False:'alltv'}[radio],"properties":self.getEnums("PVR.Fields.Channel", type='items')}}
        return self.sendJSON(param).get('result',{}).get('channels', [])


    def getPVRChannelsDetails(self, id):
        param = {"method":"PVR.GetChannelDetails","params":{"channelid":id,"properties":self.getEnums("PVR.Fields.Channel", type='items')}}
        return self.sendJSON(param).get('result',{}).get('channels', [])


    def getPVRBroadcasts(self, id):
        param = {"method":"PVR.GetBroadcasts","params":{"channelid":id,"properties":self.getEnums("PVR.Fields.Broadcast", type='items')}}
        return self.sendJSON(param).get('result',{}).get('broadcasts', [])


    def getPVRBroadcastDetails(self, id):
        param = {"method":"PVR.GetBroadcastDetails","params":{"broadcastid":id,"properties":self.getEnums("PVR.Fields.Broadcast", type='items')}}
        return self.sendJSON(param).get('result',{}).get('broadcastdetails', [])


    def getPVRRecordings(self, media='video', cache=True):
        param = {"method":"Files.GetDirectory","params":{"directory":"pvr://recordings/tv/active/","media":media,"properties":self.getEnums("List.Fields.Files", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('files', [])
        else:     return self.sendJSON(param).get('result',{}).get('files', [])

    
    def getPVRSearches(self, media='video', cache=True):
        param = {"method":"Files.GetDirectory","params":{"directory":"pvr://search/tv/savedsearches/","media":media,"properties":self.getEnums("List.Fields.Files", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('files', [])
        else:     return self.sendJSON(param).get('result',{}).get('files', [])
        
        
    def getPVRSearchItems(self, id, media='video', cache=True):
        param = {"method":"Files.GetDirectory","params":{"directory":f"pvr://search/tv/savedsearches/{id}/","media":media,"properties":self.getEnums("List.Fields.Files", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('files', [])
        else:     return self.sendJSON(param).get('result',{}).get('files', [])
    
    
    def getSmartPlaylists(self, type='video', cache=True):
        param = {"method":"Files.GetDirectory","params":{"directory":f"special://profile/playlists/{type}/","media":"video","properties":self.getEnums("List.Fields.Files", type='items')}}
        if cache: return self.cacheJSON(param).get('result',{}).get('files', [])
        else:     return self.sendJSON(param).get('result',{}).get('files', [])
        
        
    def getInfoLabel(self, key, cache=False):
        param = {"method":"XBMC.GetInfoLabels","params":{"labels":[key]}}
        if cache: return self.cacheJSON(param).get('result',{}).get(key)
        else:     return self.sendJSON(param).get('result',{}).get(key)


    def getInfoLabels(self, keys, cache=False):
        # Consolidation perf (madteevee): batched form of getInfoLabel.
        # XBMC.GetInfoLabels accepts a list of labels in one call. Used by the
        # System Info endpoint to collapse 2 sequential roundtrips into 1.
        if not keys: return {}
        param = {"method":"XBMC.GetInfoLabels","params":{"labels":list(keys)}}
        if cache: return self.cacheJSON(param).get('result',{}) or {}
        else:     return self.sendJSON(param).get('result',{}) or {}


    def getInfoBool(self, key, cache=False):
        param = {"method":"XBMC.GetInfoBooleans","params":{"booleans":[key]}}
        if cache: return self.cacheJSON(param).get('result',{}).get(key)
        else:     return self.sendJSON(param).get('result',{}).get(key)


    def getInfoBooleans(self, keys, cache=False):
        # Step 6 Phase 2 perf (madteevee): batched form of getInfoBool. Kodi's
        # XBMC.GetInfoBooleans accepts a list of keys in one call. We were
        # spending ~10s on cold settings-schema fetches doing 10 single-key
        # calls; batching collapses that to a single roundtrip.
        if not keys: return {}
        param = {"method":"XBMC.GetInfoBooleans","params":{"booleans":list(keys)}}
        if cache: return self.cacheJSON(param).get('result',{}) or {}
        else:     return self.sendJSON(param).get('result',{}) or {}


    def DBIDtoLabel(self, path):
        self.log('DBIDtoLabel, IN = %s'%(path))
        match = re.search(r"(.*?)/(\d+)/", path)
        if match:
            items = self.getDirectory({"directory":match.group(1),"media":"video"})[0]
            for item in items:
                if int(match.group(2)) == item.get('id'):
                    self.log('DBIDtoLabel, path = %s, id = %s, label = %s'%(match.group(1),match.group(2),item['label']))
                    path = item['label']
                    break
        self.log('DBIDtoLabel, OUT = %s'%(path))
        return path
        
        
    # madteevee (imports fork, imports.60): durations are no longer written to Kodi's
    # library. The removed queDuration queued params without a "method" (every one was
    # rejected by Kodi as "JSONRPC: Failed to parse"), and a well-formed version would
    # have sent resume {position 0, total N}, which CLEARS the item's resume point
    # (Kodi 21 VideoLibrary.cpp UpdateResumePoint). Lengths stay in the add-on's own
    # caches (getRuntime.* / getDuration.*) exactly as before. The `save` arguments
    # below are kept so existing callers still work; they are accepted and ignored.
    # Duration_Type is now read when called (the old defaults froze it at service start).
    def _setRuntime(self, item=None, runtime=0, save=None): #set runtime collected by player, accurate meta. (save: ignored, imports.60)
        if item is None: item = {}
        runtime = round(runtime)
        self.cache.set('getRuntime.%s'%(FileAccess._getMD5(item.get('file'))), runtime, checksum=FileAccess._getMD5(item.get('file')), expiration=datetime.timedelta(days=28))


    def _getRuntime(self, item=None): #get runtime collected by player, else less accurate provider meta
        if item is None: item = {}
        runtime = self.cache.get('getRuntime.%s'%(FileAccess._getMD5(item.get('file'))), checksum=FileAccess._getMD5(item.get('file')))
        return round(runtime or item.get('resume',{}).get('total') or item.get('runtime') or item.get('duration') or (item.get('streamdetails',{}).get('video',[]) or [{}])[0].get('duration') or 0)


    def _setDuration(self, path, item=None, duration=0, save=None):#set VideoParser cache (item, save: ignored, imports.60)
        duration = round(duration)
        self.cache.set('getDuration.%s'%(FileAccess._getMD5(path)), duration, checksum=FileAccess._getMD5(path), expiration=datetime.timedelta(days=28))
        return duration


    def _getDuration(self, path): #get VideoParser cache
        return round(self.cache.get('getDuration.%s'%(FileAccess._getMD5(path)), checksum=FileAccess._getMD5(path)) or self._getRuntime({'file':path}))


    def getDuration(self, path, item=None, accurate=None, save=None): # save: ignored, imports.60
        if accurate is None: accurate = bool(SETTINGS.getSettingInt('Duration_Type'))
        if not item: item = {'file':path}
        runtime = self._getRuntime(item) #player runtime, fallback meta provider runtime
        if runtime == 0 or accurate:
            duration = 0
            if isStack(path):# handle "stacked" videos
                for file in splitStacks(path): duration += self.__parseDuration(runtime, file)
            else: duration = self.__parseDuration(runtime, path, item, accurate=accurate)
            if duration > 0: runtime = duration
        self.log(f"getDuration [{runtime}] {path}, accurate = {accurate}")
        return runtime


    def getTotDuration(self, items=None, accurate=None):
        if items is None: items = []
        if accurate is None: accurate = bool(SETTINGS.getSettingInt('Duration_Type'))
        total = sum((self.getDuration(item.get('file'),item,accurate) for item in items))
        self.log("getTotDuration, items = %s, total = %s" % (len(items), total))
        return total


    def __parseDuration(self, runtime, path, item=None, accurate=False):
        if item is None: item = {}
        self.log("__parseDuration, runtime = %s, path = %s, accurate = %s" % (runtime, path, accurate))
        duration = self.videoParser.getVideoLength(path.replace("\\\\", "\\"), item, self)
        # imports.48: 25% sanity-check fallback retained ONLY when accurate=False (the
        # runtime==0 code path that falls into ffprobe). When the operator opted into
        # accurate mode via Duration_Type=1 or DurationOptions rule 500, they explicitly
        # want the ffprobe value — the library `runtime` field is often the lie we're
        # trying to correct (scraped "official" runtime including credits/commercials
        # the file does not contain — e.g. movie scraped at 105 min but the file is 79
        # min, or a TV cartoon scraped at 60 min slot but the file is 44 min). The
        # ffprobe-failure case (duration == 0) is still handled by getDuration's
        # `if duration > 0:` guard at the caller. Stack handling (line 461) passes no
        # `accurate` so it keeps the default False — preserves exact prior behaviour.
        if not accurate and round(percentDiff(runtime, duration)) > 25: duration = runtime
        self.log(f"__parseDuration [{runtime}] {path}, accurate = {accurate}")
        return duration


    # madteevee (imports fork, imports.60): quePlaycount was removed. Its library rows
    # sent the guide-build playcount plus resume {0,0} on every PseudoTV programme
    # change and stop (which erased resume points), and its 'video'/'song' rows were
    # always rejected by Kodi. Rollback_Watched is now a snapshot/restore of the played
    # file's own state: playstate_helpers.PlaystateTracker, driven by services.Player.


    def requestList(self, citem, path, media='video', page=SETTINGS.getSettingInt('Page_Limit'), sort={}, filter={}, limits={}, query={}):
         # Query
         # {"method": "VideoLibrary.GetEpisodes",
         # "params": {
         # "properties": ["title"],
         # "sort": {"ignorearticle": true,
                  # "method": "label",
                  # "order": "ascending",
                  # "useartistsortname": true},
         # "limits": {"end": 0, "start": 0},
         # "filter": {"and": [{"field": "title", "operator": "contains", "value": "Star Wars"}]}}}

         ##################################
         # VFS Path
         # {"method": "Files.GetDirectory",
         # "params": {
         # "directory": "videodb://tvshows/studios/-1/-1/-1/",
         # "media": "video",
         # "properties": ["title"],
         # "sort": {"ignorearticle": true,
                  # "method": "label",
                  # "order": "ascending",
                  # "useartistsortname": true},
         # "limits": {"end": 25, "start": 0}}}
         
        param = {}
        if query: #library query
            getDirectory = False
            param['filter']     = query.get('filter',{})
            param["properties"] = self.getEnums(query['enum'], type='items')
        else: #vfs path
            getDirectory = True
            param["media"]      = media
            param["directory"]  = escapeDirJSON(path)
            param["properties"] = self.getEnums("List.Fields.Files", type='items')
        self.log("requestList, id: %s, getDirectory = %s, media = %s, limit = %s, sort = %s, query = %s, limits = %s\npath = %s"%(citem['id'],getDirectory,media,page,sort,query,limits,path))
        
        if limits.get('end',-1) == -1: #-1 unlimited, replace with autoPagination.
            limits = self.autoPagination(citem['id'], path, query) #get
            self.log('[%s] requestList, autoPagination limits = %s'%(citem['id'],limits))
            if limits.get('total',0) > page and sort.get("method","") == "random":
                limits = self.randomPagination(page,limits)
                self.log('[%s] requestList, generating random limits = %s'%(citem['id'],limits))

        if limits.get('start',0) >= 0: #-1 unlimited, ignore autoPagination.
            param["limits"] = {}
            param["limits"]["start"] = 0 if limits.get('end', 0) == -1 else limits.get('end', 0)
            param["limits"]["end"]   = abs(limits.get('end', 0) + page)
        
        param["sort"] = sort
        self.log('[%s] requestList, page = %s\nparam = %s'%(citem['id'], page, param))
        
        with self.detectRPCCrash(citem):
            if getDirectory: items, limits, errors = self.getDirectory(param)
            else:            items, limits, errors = self.getLibrary(query['method'],param,query.get('key'),cache=False)

        if (limits.get('end',0) >= limits.get('total',0) or limits.get('start',0) >= limits.get('total',0)):
            # restart page to 0, exceeding boundaries.
            self.log('[%s] requestList, resetting limits to 0'%(citem['id']))
            limits = {"end": 0, "start": 0, "total": limits.get('total',0)}
          
        if len(items) == 0 and limits.get('total',0) > 0:
            # retry last request with fresh limits when no items are returned.
            self.log("[%s] requestList, trying again with start limits at 0"%(citem['id']))
            return self.requestList(citem, path, media, page, sort, filter, {"end": 0, "start": 0, "total": limits.get('total',0)}, query)
        else:          
            self.autoPagination(citem['id'], path, query, limits) #set 
            self.log("[%s] requestList, return items = %s" % (citem['id'], len(items)))
            return items, limits, errors


    def resetPagination(self, id, path, query={}, limits={"end": 0, "start": 0, "total":0}):
        return self.autoPagination(id, path, query, limits)
            
            
    def autoPagination(self, id, path, query={}, limits={}):
        # madteevee (imports fork, imports.61): the playlist position survives add-on
        # updates (versioned=False; the key already names the channel). Before, an
        # update reset every channel's playlist to its first episode.
        if not limits: return (self.cache.get('autoPagination.%s.%s.%s'%(id,FileAccess._getMD5(path),FileAccess._getMD5(FileAccess.dumpJSON(query))), versioned=False) or {"end": 0, "start": 0, "total":0})
        else:          return  self.cache.set('autoPagination.%s.%s.%s'%(id,FileAccess._getMD5(path),FileAccess._getMD5(FileAccess.dumpJSON(query))), limits, expiration=datetime.timedelta(days=28), versioned=False)
            
             
    def randomPagination(self, page=SETTINGS.getSettingInt('Page_Limit'), limits={}, start=0):
        if limits.get('total',0) > page: start = random.randrange(0, (limits.get('total',0)-page), page)
        return {"end": start, "start": start, "total":limits.get('total',0)}
        

    @contextmanager
    def detectRPCCrash(self, citem):
        SETTINGS.setCacheSetting('KODI.CRASH.JSONRPC.CITEM',citem)
        try: yield
        except Exception:pass
        finally:
            SETTINGS.setCacheSetting('KODI.CRASH.JSONRPC.CITEM',None)


    def getLocalHost(self, local=False):
        port     = 80
        username = 'kodi'
        password = ''
        secure   = False
        enabled  = True
        settings = self.getSetting('control','services',cache=True)
        for setting in settings:
            if setting.get('id','').lower() == 'services.webserver' and not setting.get('value'):
                enabled = False
                DIALOG.notificationDialog(LANGUAGE(32131))
                break
            if   setting.get('id','').lower() == 'services.webserverusername': username = setting.get('value')
            elif setting.get('id','').lower() == 'services.webserverport':     port     = setting.get('value')
            elif setting.get('id','').lower() == 'services.webserverpassword': password = setting.get('value')
            elif setting.get('id','').lower() == 'services.webserverssl' and setting.get('value'): secure = True
        username = '{0}:{1}@'.format(username, password) if username and password else ''
        protocol = 'https' if secure else 'http'
        if local: ip = 'localhost'
        else:     ip = SETTINGS.getIP()
        webURL =  '{0}://{1}{2}:{3}'.format(protocol,username,ip,port)
        PROPERTIES.setEXTProperty('%s.Local_Host'%(ADDON_ID),webURL)
        self.log("getLocalHost; returning %s"%(webURL))
        return webURL
            
            
    def padItems(self, files, page=SETTINGS.getSettingInt('Page_Limit')):
        # Balance media limits, by filling with duplicates to meet min. pagination.
        self.log("padItems; files In = %s"%(len(files)))
        if len(files) < page:
            iters = cycle(files)
            while not self.service.monitor.abortRequested() and (len(files) < page and len(files) > 0):
                item = next(iters).copy()
                if   self.service._interrupt(): break
                elif self.getDuration(item.get('file'),item) == 0:
                    try: files.pop(files.index(item))
                    except Exception: break
                else: files.append(item)
        self.log("padItems; files Out = %s"%(len(files)))
        return files


    def inputFriendlyName(self):
        friendly = self.getSettingValue("services.devicename")
        self.log("inputFriendlyName, name = %s"%(friendly))
        if not friendly or friendly.lower() == 'kodi':
            if DIALOG.okDialog(LANGUAGE(32132)%(friendly)):
                with PROPERTIES.interruptActivity():
                    friendly = DIALOG.inputDialog(LANGUAGE(30122), friendly)
                if not friendly or friendly.lower() == 'kodi':
                    return self.inputFriendlyName()
                else:
                    self.setSettingValue("services.devicename",friendly,queue=False)
                    self.log('inputFriendlyName, setting device name = %s'%(friendly))
        return friendly
           
           
    def getCallback(self, sysInfo={}):
        self.log('[%s] getCallback, mode = %s, radio = %s, isPlaylist = %s'%(sysInfo.get('chid'),sysInfo.get('mode'),sysInfo.get('radio',False),sysInfo.get('isPlaylist',False)))
        def _matchJSON():#requires 'pvr://' json whitelisting
            results, limits, errors = self.getDirectory(param={"directory":"pvr://channels/{dir}/".format(dir={'True':'radio','False':'tv'}[str(sysInfo.get('radio',False))])}, cache=False)
            for dir in [ADDON_NAME,'All channels']: #todo "All channels" may not work with non-English translations!
                for result in results:
                    if result.get('label','').lower().startswith(dir.lower()):
                        self.log('getCallback: _matchJSON, found dir = %s'%(result.get('file')))
                        channels, limits, errors = self.getDirectory(param={"directory":result.get('file')},checksum=PROPERTIES.getInstanceID(),expiration=datetime.timedelta(minutes=15))
                        for item in channels:
                            if item.get('label','').lower() == sysInfo.get('name','').lower() and Globals._decodePlot(item.get('plot','')).get('citem',{}).get('id') == sysInfo.get('chid'):
                                self.log('[%s] getCallback: _matchJSON, found file = %s'%(sysInfo.get('chid'),item.get('file')))
                                return item.get('file')
   
        if sysInfo.get('mode','').lower() == 'live' and sysInfo.get('chpath'):
            callback = sysInfo.get('chpath')
        elif sysInfo.get('isPlaylist'):
            callback = sysInfo.get('citem',{}).get('url')
        elif sysInfo.get('mode','').lower() in ['vod','broadcast'] and sysInfo.get('nitem',{}).get('file'):
            callback = sysInfo.get('nitem',{}).get('file')
        else:
            callback = sysInfo.get('callback','')
        if not callback: callback = _matchJSON()
        self.log('getCallback: returning callback = %s'%(callback))
        return callback# or (('%s%s'%(self.sysARG[0],self.sysARG[2])).split('%s&'%(PSEUDOTV_SLUG)))[0])
        
        
    def matchChannel(self, chname: str, id: str, radio: bool=False, extend=True):
        self.log('[%s] matchChannel, chname = %s, radio = %s'%(id,chname,radio))
        def __match():
            channels = self.getPVRChannels(radio)
            for channel in channels:
                if channel.get('label','').lower() == chname.lower():
                    for key in ['broadcastnow', 'broadcastnext']:
                        if Globals._decodePlot(channel.get(key,{}).get('plot','')).get('citem',{}).get('id') == id:
                            channel['broadcastnext'] = [channel.get('broadcastnext',{})]
                            self.log('[%s] matchChannel: __match, found pvritem = %s'%(id,channel))
                            return channel
                            
        def __extend(pvritem: dict={}) -> dict:
            channelItem = {}
            def _parseBroadcast(broadcast={}):
                if broadcast.get('progresspercentage',0) == 100:
                    channelItem.setdefault('broadcastpast',[]).append(broadcast)
                elif broadcast.get('progresspercentage',0) > 0 and broadcast.get('progresspercentage',100) < 100:
                    channelItem['broadcastnow'] = broadcast
                elif broadcast.get('progresspercentage',0) == 0 and broadcast.get('progresspercentage',100) < 100:
                    channelItem.setdefault('broadcastnext',[]).append(broadcast)
                    
            broadcasts = self.getPVRBroadcasts(pvritem.get('channelid',{}))
            [_parseBroadcast(broadcast) for broadcast in broadcasts]
            try:    pvritem['broadcastpast'] = sorted(channelItem.get('broadcastpast',[]), key=itemgetter('starttime'))
            except Exception: pvritem['broadcastpast'] = channelItem.get('broadcastpast',[])
            try:    pvritem['broadcastnext'] = sorted(channelItem.get('broadcastnext',pvritem['broadcastnext']), key=itemgetter('starttime'))
            except Exception: pvritem['broadcastnext'] = channelItem.get('broadcastnext',pvritem['broadcastnext'])
            self.log('matchChannel: __extend, broadcastnext = %s entries'%(len(pvritem['broadcastnext'])))
            return pvritem
            
        cacheName     = 'matchChannel.%s'%(FileAccess._getMD5('%s.%s.%s.%s'%(chname,id,radio,extend)))
        cacheResponse = (self.cache.get(cacheName, checksum=PROPERTIES.getInstanceID()) or {})
        if not cacheResponse:
            pvrItem = __match()
            if pvrItem and extend: pvrItem = __extend(pvrItem)
            cacheResponse = self.cache.set(cacheName, pvrItem, checksum=PROPERTIES.getInstanceID(), expiration=datetime.timedelta(seconds=15))
        return cacheResponse
        
        
    def getNextItem(self, citem={}, nitem={}): #return next broadcast ignoring fillers
        if (citem.get('name','') and citem.get('id','')):
            nextitems = self.matchChannel(citem.get('name',''), citem.get('id',''), citem.get('radio',False)).get('broadcastnext',[])
            for idx, nextitem in enumerate(nextitems):
                item = Globals._decodePlot(nextitem.get('plot',''))
                if item.get('start') == nitem.get('start',str(random.random())) and item.get('id') == nitem.get('id',random.random()):
                    for next in nextitems[idx:]:
                        if not isFiller(next): return Globals._decodePlot(next.get('plot',''))
        return nitem
        

    def toggleShowLog(self, state=False):
        self.log('toggleShowLog, state = %s'%(state))
        if self.getSettingValue("debug.showloginfo") != state:
            self.setSettingValue("debug.showloginfo",state,queue=False)
